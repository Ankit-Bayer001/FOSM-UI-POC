import { IntegrationSource } from '@/types/cmdb';
import { getIntegrationStatusColor, formatRelativeTime } from '@/lib/cmdb-utils';
import { RefreshCw, AlertCircle, Cloud, Server } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface IntegrationCardProps {
  integration: IntegrationSource;
  onSync?: () => void;
}

export function IntegrationCard({ integration, onSync }: IntegrationCardProps) {
  const statusColor = getIntegrationStatusColor(integration.status);

  const getIntegrationIcon = (type: IntegrationSource['type']) => {
    switch (type) {
      case 'azure':
        return Cloud;
      case 'aws':
        return Cloud;
      case 'servicenow':
        return Server;
      default:
        return Server;
    }
  };

  const Icon = getIntegrationIcon(integration.type);

  return (
    <div className="card-elevated p-4 animate-fade-in">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-lg bg-secondary">
            <Icon className="h-5 w-5 text-muted-foreground" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-medium text-sm">{integration.name}</h3>
              <span className={cn('status-badge', statusColor)}>
                {integration.status === 'syncing' && (
                  <RefreshCw className="h-3 w-3 animate-spin mr-1" />
                )}
                {integration.status}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-0.5 font-mono">
              {integration.endpoint}
            </p>
          </div>
        </div>

        <Button
          variant="ghost"
          size="sm"
          onClick={onSync}
          disabled={integration.status === 'syncing'}
          className="shrink-0"
        >
          <RefreshCw className={cn('h-4 w-4', integration.status === 'syncing' && 'animate-spin')} />
        </Button>
      </div>

      <div className="mt-4 pt-3 border-t flex items-center justify-between text-xs text-muted-foreground">
        <div className="flex items-center gap-4">
          <span>
            <strong className="text-foreground">{integration.ciCount}</strong> CIs
          </span>
          {integration.lastSyncAt && (
            <span>Last sync: {formatRelativeTime(integration.lastSyncAt)}</span>
          )}
        </div>
        {integration.nextSyncAt && (
          <span>Next: {formatRelativeTime(integration.nextSyncAt)}</span>
        )}
      </div>

      {integration.status === 'error' && integration.errorMessage && (
        <div className="mt-3 p-2 bg-red-50 rounded-lg flex items-start gap-2">
          <AlertCircle className="h-4 w-4 text-status-critical shrink-0 mt-0.5" />
          <p className="text-xs text-status-critical">{integration.errorMessage}</p>
        </div>
      )}
    </div>
  );
}
