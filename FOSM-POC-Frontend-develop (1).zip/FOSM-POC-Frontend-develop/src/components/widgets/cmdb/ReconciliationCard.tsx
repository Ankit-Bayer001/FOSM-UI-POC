import { DuplicateCandidate } from '@/types/cmdb';
import { CIClassBadge } from './CIClassBadge';
import { GitMerge, X, Check, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface ReconciliationCardProps {
  candidate: DuplicateCandidate;
  onMerge?: () => void;
  onDismiss?: () => void;
}

export function ReconciliationCard({
  candidate,
  onMerge,
  onDismiss,
}: ReconciliationCardProps) {
  const matchPercentage = Math.round(candidate.matchScore * 100);

  return (
    <div className="card-elevated p-4 animate-fade-in">
      <div className="flex items-start justify-between gap-4 mb-4">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-purple-100">
            <GitMerge className="h-4 w-4 text-purple-600" />
          </div>
          <div>
            <h4 className="font-medium text-sm">Potential Duplicate</h4>
            <p className="text-xs text-muted-foreground">
              {matchPercentage}% match on {candidate.matchedFields.join(', ')}
            </p>
          </div>
        </div>
        <div
          className={cn(
            'px-2 py-1 rounded-full text-xs font-medium',
            matchPercentage >= 90
              ? 'bg-green-100 text-green-700'
              : matchPercentage >= 75
              ? 'bg-amber-100 text-amber-700'
              : 'bg-gray-100 text-gray-600'
          )}
        >
          {matchPercentage}%
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {/* CI A */}
        <div className="p-3 rounded-lg bg-muted/50 border">
          <div className="flex items-center gap-2 mb-2">
            <CIClassBadge ciClass={candidate.ciA.class} showLabel={false} />
            <span className="text-sm font-medium truncate">{candidate.ciA.name}</span>
          </div>
          <div className="text-xs text-muted-foreground space-y-1">
            <p>Source: {candidate.ciA.source}</p>
            <p className="font-mono text-[10px]">{candidate.ciA.id}</p>
          </div>
        </div>

        {/* CI B */}
        <div className="p-3 rounded-lg bg-muted/50 border">
          <div className="flex items-center gap-2 mb-2">
            <CIClassBadge ciClass={candidate.ciB.class} showLabel={false} />
            <span className="text-sm font-medium truncate">{candidate.ciB.name}</span>
          </div>
          <div className="text-xs text-muted-foreground space-y-1">
            <p>Source: {candidate.ciB.source}</p>
            <p className="font-mono text-[10px]">{candidate.ciB.id}</p>
          </div>
        </div>
      </div>

      {candidate.suggestedAction && (
        <div className="mt-3 p-2 bg-blue-50 rounded-lg flex items-start gap-2">
          <Sparkles className="h-4 w-4 text-status-info shrink-0 mt-0.5" />
          <p className="text-xs text-blue-700">{candidate.suggestedAction}</p>
        </div>
      )}

      {candidate.status === 'pending' && (
        <div className="mt-4 flex items-center gap-2 pt-3 border-t">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={onDismiss}
          >
            <X className="h-3.5 w-3.5 mr-1" />
            Dismiss
          </Button>
          <Button size="sm" className="flex-1" onClick={onMerge}>
            <Check className="h-3.5 w-3.5 mr-1" />
            Merge
          </Button>
        </div>
      )}
    </div>
  );
}
