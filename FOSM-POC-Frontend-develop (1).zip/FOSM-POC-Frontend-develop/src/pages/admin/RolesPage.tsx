import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { mockRoles, mockPermissions } from '@/data/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { Plus, Search, Shield, Edit, Trash2 } from 'lucide-react';
import { Permission } from '@/types';

const resourceLabels: Record<string, string> = {
  change_tickets: 'Change Tickets',
  users: 'Users',
  roles: 'Roles',
  groups: 'Groups',
};

const actionLabels: Record<string, string> = {
  create: 'Create',
  read: 'Read',
  update: 'Update',
  delete: 'Delete',
  approve: 'Approve',
};

export const RolesPage = () => {
  const { hasPermission } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState<string | null>(null);

  const filteredRoles = mockRoles.filter(role =>
    role.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    role.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Group permissions by resource
  const groupedPermissions = mockPermissions.reduce((acc, perm) => {
    if (!acc[perm.resource]) {
      acc[perm.resource] = [];
    }
    acc[perm.resource].push(perm);
    return acc;
  }, {} as Record<string, Permission[]>);

  const hasRolePermission = (roleId: string, permId: string) => {
    const role = mockRoles.find(r => r.id === roleId);
    return role?.permissions.some(p => p.id === permId) || false;
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="page-header flex items-center justify-between">
        <div>
          <h1 className="page-title">Roles & Permissions</h1>
          <p className="page-description">Define roles and manage access permissions</p>
        </div>
        {hasPermission('roles', 'create') && (
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Create Role
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Roles List */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Roles</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search roles..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="space-y-2">
                {filteredRoles.map((role) => (
                  <button
                    key={role.id}
                    onClick={() => setSelectedRole(role.id)}
                    className={`w-full text-left p-3 rounded-lg border transition-colors ${
                      selectedRole === role.id
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:bg-muted/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        selectedRole === role.id ? 'bg-primary/20' : 'bg-muted'
                      }`}>
                        <Shield className={`w-5 h-5 ${
                          selectedRole === role.id ? 'text-primary' : 'text-muted-foreground'
                        }`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{role.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {role.permissions.length} permissions
                        </p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Permissions Matrix */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Permissions Matrix</CardTitle>
              <CardDescription>
                {selectedRole 
                  ? `Viewing permissions for ${mockRoles.find(r => r.id === selectedRole)?.name}`
                  : 'Select a role to view its permissions'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {selectedRole ? (
                <div className="space-y-6">
                  {Object.entries(groupedPermissions).map(([resource, permissions]) => (
                    <div key={resource}>
                      <h4 className="text-sm font-semibold text-foreground mb-3">
                        {resourceLabels[resource] || resource}
                      </h4>
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                        {permissions.map((perm) => {
                          const hasAccess = hasRolePermission(selectedRole, perm.id);
                          return (
                            <div
                              key={perm.id}
                              className={`flex items-center gap-2 p-2 rounded border ${
                                hasAccess 
                                  ? 'bg-success/10 border-success/30' 
                                  : 'bg-muted/30 border-border'
                              }`}
                            >
                              <Checkbox 
                                checked={hasAccess} 
                                disabled
                                className="data-[state=checked]:bg-success data-[state=checked]:border-success"
                              />
                              <span className={`text-sm ${hasAccess ? 'text-foreground' : 'text-muted-foreground'}`}>
                                {actionLabels[perm.action] || perm.action}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex items-center justify-center h-48 text-muted-foreground">
                  <div className="text-center">
                    <Shield className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>Select a role to view its permissions</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Role Details */}
          {selectedRole && (
            <Card className="mt-6">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>{mockRoles.find(r => r.id === selectedRole)?.name}</CardTitle>
                  <CardDescription>
                    {mockRoles.find(r => r.id === selectedRole)?.description}
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  {hasPermission('roles', 'update') && (
                    <Button variant="outline" size="sm">
                      <Edit className="w-4 h-4 mr-2" />
                      Edit
                    </Button>
                  )}
                  {hasPermission('roles', 'delete') && (
                    <Button variant="outline" size="sm" className="text-destructive hover:text-destructive">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </Button>
                  )}
                </div>
              </CardHeader>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};
