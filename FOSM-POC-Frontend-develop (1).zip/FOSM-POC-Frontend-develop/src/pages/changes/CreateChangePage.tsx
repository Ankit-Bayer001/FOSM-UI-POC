import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Save, Send } from 'lucide-react';
import { ChangeType, ChangeCategory, ChangePriority } from '@/types';

export const CreateChangePage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: '' as ChangeType | '',
    category: '' as ChangeCategory | '',
    priority: '' as ChangePriority | '',
    impactAssessment: '',
    riskLevel: '' as 'low' | 'medium' | 'high' | '',
    rollbackPlan: '',
    affectedSystems: '',
    scheduledStartDate: '',
    scheduledEndDate: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (action: 'draft' | 'submit') => {
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    toast({
      title: action === 'draft' ? 'Draft Saved' : 'Change Submitted',
      description: action === 'draft' 
        ? 'Your change request has been saved as a draft.'
        : 'Your change request has been submitted for approval.',
    });

    navigate('/changes');
    setIsSubmitting(false);
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="page-header flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="page-title">Create Change Request</h1>
          <p className="page-description">Submit a new change request for review and approval</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Form */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Change Details</CardTitle>
              <CardDescription>Provide information about the change you want to implement</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  placeholder="Brief description of the change"
                  value={formData.title}
                  onChange={(e) => handleChange('title', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Detailed description of the change, including objectives and scope"
                  rows={4}
                  value={formData.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Change Type *</Label>
                  <Select value={formData.type} onValueChange={(v) => handleChange('type', v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">Standard</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="emergency">Emergency</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Category *</Label>
                  <Select value={formData.category} onValueChange={(v) => handleChange('category', v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="infrastructure">Infrastructure</SelectItem>
                      <SelectItem value="application">Application</SelectItem>
                      <SelectItem value="database">Database</SelectItem>
                      <SelectItem value="network">Network</SelectItem>
                      <SelectItem value="security">Security</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Priority *</Label>
                  <Select value={formData.priority} onValueChange={(v) => handleChange('priority', v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="affectedSystems">Affected Systems</Label>
                <Input
                  id="affectedSystems"
                  placeholder="Comma-separated list of affected systems"
                  value={formData.affectedSystems}
                  onChange={(e) => handleChange('affectedSystems', e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Risk & Impact Assessment</CardTitle>
              <CardDescription>Evaluate the potential risks and impact of this change</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="impactAssessment">Impact Assessment *</Label>
                <Textarea
                  id="impactAssessment"
                  placeholder="Describe the expected impact on services and users"
                  rows={3}
                  value={formData.impactAssessment}
                  onChange={(e) => handleChange('impactAssessment', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>Risk Level *</Label>
                <Select value={formData.riskLevel} onValueChange={(v) => handleChange('riskLevel', v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select risk level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low - Minimal risk, standard procedures</SelectItem>
                    <SelectItem value="medium">Medium - Some risk, requires monitoring</SelectItem>
                    <SelectItem value="high">High - Significant risk, requires CAB approval</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="rollbackPlan">Rollback Plan *</Label>
                <Textarea
                  id="rollbackPlan"
                  placeholder="Describe the steps to revert the change if issues occur"
                  rows={3}
                  value={formData.rollbackPlan}
                  onChange={(e) => handleChange('rollbackPlan', e.target.value)}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Schedule</CardTitle>
              <CardDescription>When should this change be implemented?</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="scheduledStartDate">Scheduled Start</Label>
                <Input
                  id="scheduledStartDate"
                  type="datetime-local"
                  value={formData.scheduledStartDate}
                  onChange={(e) => handleChange('scheduledStartDate', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="scheduledEndDate">Scheduled End</Label>
                <Input
                  id="scheduledEndDate"
                  type="datetime-local"
                  value={formData.scheduledEndDate}
                  onChange={(e) => handleChange('scheduledEndDate', e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Requester</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                  <span className="text-sm font-medium">
                    {user?.firstName?.[0]}{user?.lastName?.[0]}
                  </span>
                </div>
                <div>
                  <p className="font-medium">{user?.displayName}</p>
                  <p className="text-sm text-muted-foreground">{user?.email}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6 space-y-3">
              <Button 
                className="w-full" 
                onClick={() => handleSubmit('submit')}
                disabled={isSubmitting}
              >
                <Send className="w-4 h-4 mr-2" />
                Submit for Approval
              </Button>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => handleSubmit('draft')}
                disabled={isSubmitting}
              >
                <Save className="w-4 h-4 mr-2" />
                Save as Draft
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
