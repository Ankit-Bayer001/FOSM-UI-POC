import { useParams, useNavigate, Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { mockChangeTickets, getUserById } from '@/data/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { ChangeStatus, ChangePriority } from '@/types';
import { 
  ArrowLeft, 
  Edit, 
  CheckCircle2, 
  XCircle, 
  Clock,
  User,
  Calendar,
  AlertTriangle,
  MessageSquare,
  History,
  FileText
} from 'lucide-react';
import { useState } from 'react';

const statusConfig: Record<ChangeStatus, { label: string; className: string; icon: React.ElementType }> = {
  draft: { label: 'Draft', className: 'bg-muted text-muted-foreground', icon: FileText },
  pending_approval: { label: 'Pending Approval', className: 'bg-warning/20 text-warning', icon: Clock },
  approved: { label: 'Approved', className: 'bg-info/20 text-info', icon: CheckCircle2 },
  in_progress: { label: 'In Progress', className: 'bg-accent/20 text-accent', icon: Clock },
  completed: { label: 'Completed', className: 'bg-success/20 text-success', icon: CheckCircle2 },
  rejected: { label: 'Rejected', className: 'bg-destructive/20 text-destructive', icon: XCircle },
  cancelled: { label: 'Cancelled', className: 'bg-muted text-muted-foreground', icon: XCircle },
};

const priorityConfig: Record<ChangePriority, { label: string; className: string }> = {
  low: { label: 'Low', className: 'bg-success/20 text-success' },
  medium: { label: 'Medium', className: 'bg-warning/20 text-warning' },
  high: { label: 'High', className: 'bg-destructive/20 text-destructive' },
  critical: { label: 'Critical', className: 'bg-destructive text-destructive-foreground' },
};

export const ChangeDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { hasPermission } = useAuth();
  const { toast } = useToast();
  const [comment, setComment] = useState('');

  const ticket = mockChangeTickets.find(t => t.id === id);

  if (!ticket) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-muted-foreground">Change ticket not found</p>
      </div>
    );
  }

  const requester = getUserById(ticket.requesterId);
  const assignee = ticket.assigneeId ? getUserById(ticket.assigneeId) : null;
  const status = statusConfig[ticket.status];
  const priority = priorityConfig[ticket.priority];
  const StatusIcon = status.icon;

  const handleApprove = () => {
    toast({
      title: 'Change Approved',
      description: 'The change request has been approved.',
    });
  };

  const handleReject = () => {
    toast({
      title: 'Change Rejected',
      description: 'The change request has been rejected.',
      variant: 'destructive',
    });
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="page-header">
        <div className="flex items-center gap-4 mb-4">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-1">
              <h1 className="page-title">{ticket.ticketNumber}</h1>
              <Badge className={status.className}>
                <StatusIcon className="w-3 h-3 mr-1" />
                {status.label}
              </Badge>
              <Badge className={priority.className}>{priority.label}</Badge>
            </div>
            <p className="text-lg text-foreground">{ticket.title}</p>
          </div>
          <div className="flex items-center gap-2">
            {hasPermission('change_tickets', 'approve') && ticket.status === 'pending_approval' && (
              <>
                <Button onClick={handleApprove}>
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Approve
                </Button>
                <Button variant="destructive" onClick={handleReject}>
                  <XCircle className="w-4 h-4 mr-2" />
                  Reject
                </Button>
              </>
            )}
            {hasPermission('change_tickets', 'update') && (
              <Button variant="outline" asChild>
                <Link to={`/changes/${ticket.id}/edit`}>
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </Link>
              </Button>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Description</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-foreground whitespace-pre-wrap">{ticket.description}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Impact & Risk Assessment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">Impact Assessment</h4>
                <p className="text-foreground">{ticket.impactAssessment}</p>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Risk Level</h4>
                  <Badge variant={ticket.riskLevel === 'high' ? 'destructive' : 'secondary'} className="capitalize">
                    {ticket.riskLevel}
                  </Badge>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Affected Systems</h4>
                  <div className="flex flex-wrap gap-1">
                    {ticket.affectedSystems.map((system, i) => (
                      <Badge key={i} variant="outline">{system}</Badge>
                    ))}
                  </div>
                </div>
              </div>
              <Separator />
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">Rollback Plan</h4>
                <p className="text-foreground">{ticket.rollbackPlan}</p>
              </div>
            </CardContent>
          </Card>

          {/* Comments */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Comments
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 mb-4">
                {ticket.comments.length === 0 ? (
                  <p className="text-muted-foreground text-sm">No comments yet</p>
                ) : (
                  ticket.comments.map((c) => {
                    const author = getUserById(c.authorId);
                    return (
                      <div key={c.id} className="flex gap-3">
                        <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                          <span className="text-xs font-medium">
                            {author?.firstName?.[0]}{author?.lastName?.[0]}
                          </span>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-sm">{author?.displayName}</span>
                            <span className="text-xs text-muted-foreground">
                              {new Date(c.createdAt).toLocaleString()}
                            </span>
                          </div>
                          <p className="text-sm text-foreground">{c.content}</p>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
              <div className="flex gap-2">
                <Textarea 
                  placeholder="Add a comment..."
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  rows={2}
                />
                <Button className="self-end">Post</Button>
              </div>
            </CardContent>
          </Card>

          {/* Audit Log */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="w-5 h-5" />
                Activity Log
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {ticket.auditLog.map((entry) => {
                  const performer = getUserById(entry.performedBy);
                  return (
                    <div key={entry.id} className="flex items-start gap-3 text-sm">
                      <div className="w-2 h-2 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                      <div>
                        <span className="font-medium">{performer?.displayName}</span>
                        <span className="text-muted-foreground"> {entry.action}</span>
                        {entry.field && (
                          <span className="text-muted-foreground">
                            : {entry.oldValue} → {entry.newValue}
                          </span>
                        )}
                        <p className="text-xs text-muted-foreground">
                          {new Date(entry.performedAt).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <User className="w-4 h-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Requester</p>
                  <p className="text-sm font-medium">{requester?.displayName}</p>
                </div>
              </div>
              <Separator />
              <div className="flex items-center gap-3">
                <User className="w-4 h-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Assignee</p>
                  <p className="text-sm font-medium">{assignee?.displayName || 'Unassigned'}</p>
                </div>
              </div>
              <Separator />
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-4 h-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Type / Category</p>
                  <p className="text-sm font-medium capitalize">{ticket.type} / {ticket.category}</p>
                </div>
              </div>
              <Separator />
              <div className="flex items-center gap-3">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Created</p>
                  <p className="text-sm font-medium">{new Date(ticket.createdAt).toLocaleDateString()}</p>
                </div>
              </div>
              {ticket.scheduledStartDate && (
                <>
                  <Separator />
                  <div className="flex items-center gap-3">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">Scheduled</p>
                      <p className="text-sm font-medium">
                        {new Date(ticket.scheduledStartDate).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Approvers */}
          <Card>
            <CardHeader>
              <CardTitle>Approvals</CardTitle>
            </CardHeader>
            <CardContent>
              {ticket.approvers.length === 0 ? (
                <p className="text-sm text-muted-foreground">No approvers assigned</p>
              ) : (
                <div className="space-y-3">
                  {ticket.approvers.map((approval, i) => {
                    const approver = getUserById(approval.approverId);
                    return (
                      <div key={i} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                            <span className="text-xs font-medium">
                              {approver?.firstName?.[0]}{approver?.lastName?.[0]}
                            </span>
                          </div>
                          <span className="text-sm">{approver?.displayName}</span>
                        </div>
                        <Badge 
                          variant={
                            approval.status === 'approved' ? 'default' : 
                            approval.status === 'rejected' ? 'destructive' : 'secondary'
                          }
                          className="capitalize"
                        >
                          {approval.status}
                        </Badge>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
