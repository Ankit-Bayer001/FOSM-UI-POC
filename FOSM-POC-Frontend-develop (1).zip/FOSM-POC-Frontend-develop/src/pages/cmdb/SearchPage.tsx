import { useState, useMemo } from 'react';
import { CMDBLayout } from '@/components/widgets/cmdb/CMDBLayout';
import { CITable } from '@/components/widgets/cmdb/CITable';
import { CIDetailPanel } from '@/components/widgets/cmdb/CIDetailPanel';
import { configurationItems, ciRelationships } from '@/data/mockCmdbData';
import { ConfigurationItem } from '@/types/cmdb';
import { Search, SlidersHorizontal } from 'lucide-react';
import { Input } from '@/components/ui/input';

export default function SearchPage() {
  const [query, setQuery] = useState('');
  const [selectedCI, setSelectedCI] = useState<ConfigurationItem | null>(null);

  const searchResults = useMemo(() => {
    if (!query.trim()) return [];
    
    const lowerQuery = query.toLowerCase();
    return configurationItems.filter(ci => {
      const searchableText = [
        ci.name,
        ci.description,
        ci.owner,
        ci.team,
        ci.source,
        ci.class,
        ci.environment,
        ...Object.values(ci.attributes).map(String),
      ].join(' ').toLowerCase();
      
      return searchableText.includes(lowerQuery);
    });
  }, [query]);

  return (
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Search className="h-6 w-6" />
            CI Search & Lookup
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Search across all CI attributes, names, and metadata
          </p>
        </div>

        {/* Search Bar */}
        <div className="relative max-w-2xl">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search by name, IP, hostname, owner, or any attribute..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-12 h-12 text-base"
            autoFocus
          />
        </div>

        {/* Search Tips */}
        {!query && (
          <div className="card-elevated p-6">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <SlidersHorizontal className="h-4 w-4" />
              Search Tips
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="font-medium">By Name</p>
                <p className="text-muted-foreground text-xs mt-1">
                  Search for CI names like "PROD-WEB-01" or "CRM"
                </p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="font-medium">By IP Address</p>
                <p className="text-muted-foreground text-xs mt-1">
                  Find CIs by IP like "10.0.1.10"
                </p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="font-medium">By Owner</p>
                <p className="text-muted-foreground text-xs mt-1">
                  Search by owner name like "John Smith"
                </p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="font-medium">By Attribute</p>
                <p className="text-muted-foreground text-xs mt-1">
                  Search any attribute value like "PostgreSQL" or "Ubuntu"
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Results */}
        {query && (
          <div>
            <p className="text-sm text-muted-foreground mb-4">
              {searchResults.length} result{searchResults.length !== 1 ? 's' : ''} for "{query}"
            </p>
            <CITable
              items={searchResults}
              onViewDetails={setSelectedCI}
              onViewRelationships={setSelectedCI}
            />
          </div>
        )}

        {/* Detail Panel */}
        {selectedCI && (
          <CIDetailPanel
            ci={selectedCI}
            relationships={ciRelationships}
            allCIs={configurationItems}
            onClose={() => setSelectedCI(null)}
            onViewRelated={setSelectedCI}
          />
        )}
      </div>
  );
}
