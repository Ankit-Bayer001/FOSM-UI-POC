import { User, Group, Role, Permission, UserRole, GroupRole, ChangeTicket } from '@/types';

// Permissions
export const mockPermissions: Permission[] = [
  { id: 'p1', resource: 'change_tickets', action: 'create' },
  { id: 'p2', resource: 'change_tickets', action: 'read' },
  { id: 'p3', resource: 'change_tickets', action: 'update' },
  { id: 'p4', resource: 'change_tickets', action: 'delete' },
  { id: 'p5', resource: 'change_tickets', action: 'approve' },
  { id: 'p6', resource: 'users', action: 'create' },
  { id: 'p7', resource: 'users', action: 'read' },
  { id: 'p8', resource: 'users', action: 'update' },
  { id: 'p9', resource: 'users', action: 'delete' },
  { id: 'p10', resource: 'roles', action: 'create' },
  { id: 'p11', resource: 'roles', action: 'read' },
  { id: 'p12', resource: 'roles', action: 'update' },
  { id: 'p13', resource: 'roles', action: 'delete' },
  { id: 'p14', resource: 'groups', action: 'create' },
  { id: 'p15', resource: 'groups', action: 'read' },
  { id: 'p16', resource: 'groups', action: 'update' },
  { id: 'p17', resource: 'groups', action: 'delete' },
];

// Roles
export const mockRoles: Role[] = [
  {
    id: 'role1',
    name: 'Administrator',
    description: 'Full system access with all permissions',
    permissions: mockPermissions,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'role2',
    name: 'Change Manager',
    description: 'Can create, update, and approve change tickets',
    permissions: mockPermissions.filter(p => 
      p.resource === 'change_tickets' || (p.resource === 'users' && p.action === 'read')
    ),
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'role3',
    name: 'Change Requester',
    description: 'Can create and view change tickets',
    permissions: mockPermissions.filter(p => 
      p.resource === 'change_tickets' && ['create', 'read'].includes(p.action)
    ),
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'role4',
    name: 'Approver',
    description: 'Can view and approve change tickets',
    permissions: mockPermissions.filter(p => 
      p.resource === 'change_tickets' && ['read', 'approve'].includes(p.action)
    ),
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'role5',
    name: 'Viewer',
    description: 'Read-only access to change tickets',
    permissions: mockPermissions.filter(p => 
      p.resource === 'change_tickets' && p.action === 'read'
    ),
    createdAt: '2024-01-01T00:00:00Z',
  },
];

// Users
export const mockUsers: User[] = [
  {
    id: 'user1',
    email: 'admin@company.com',
    displayName: ' Admin',
    firstName: '',
    lastName: 'Admin',
    department: 'IT Operations',
    jobTitle: 'System Administrator',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    lastLoginAt: '2024-01-20T10:30:00Z',
  },
  {
    id: 'user2',
    email: 'sarah.manager@company.com',
    displayName: 'Sarah Manager',
    firstName: 'Sarah',
    lastName: 'Manager',
    department: 'IT Change Management',
    jobTitle: 'Change Manager',
    isActive: true,
    createdAt: '2024-01-05T00:00:00Z',
    lastLoginAt: '2024-01-20T09:15:00Z',
  },
  {
    id: 'user3',
    email: 'mike.developer@company.com',
    displayName: 'Mike Developer',
    firstName: 'Mike',
    lastName: 'Developer',
    department: 'Engineering',
    jobTitle: 'Senior Developer',
    isActive: true,
    createdAt: '2024-01-10T00:00:00Z',
    lastLoginAt: '2024-01-19T16:45:00Z',
  },
  {
    id: 'user4',
    email: 'lisa.approver@company.com',
    displayName: 'Lisa Approver',
    firstName: 'Lisa',
    lastName: 'Approver',
    department: 'IT Management',
    jobTitle: 'IT Director',
    isActive: true,
    createdAt: '2024-01-02T00:00:00Z',
    lastLoginAt: '2024-01-20T08:00:00Z',
  },
  {
    id: 'user5',
    email: 'tom.viewer@company.com',
    displayName: 'Tom Viewer',
    firstName: 'Tom',
    lastName: 'Viewer',
    department: 'Operations',
    jobTitle: 'Operations Analyst',
    isActive: true,
    createdAt: '2024-01-15T00:00:00Z',
    lastLoginAt: '2024-01-18T14:20:00Z',
  },
];

// Groups
export const mockGroups: Group[] = [
  {
    id: 'group1',
    name: 'IT Administrators',
    description: 'System administrators with full access',
    members: ['user1'],
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'group2',
    name: 'Change Advisory Board',
    description: 'CAB members who review and approve changes',
    members: ['user2', 'user4'],
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-05T00:00:00Z',
  },
  {
    id: 'group3',
    name: 'Development Team',
    description: 'Software developers who submit change requests',
    members: ['user3'],
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-10T00:00:00Z',
  },
  {
    id: 'group4',
    name: 'Stakeholders',
    description: 'Business stakeholders with view access',
    members: ['user5'],
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-15T00:00:00Z',
  },
];

// User-Role Assignments
export const mockUserRoles: UserRole[] = [
  { userId: 'user1', roleId: 'role1', assignedAt: '2024-01-01T00:00:00Z', assignedBy: 'system' },
  { userId: 'user2', roleId: 'role2', assignedAt: '2024-01-05T00:00:00Z', assignedBy: 'user1' },
  { userId: 'user3', roleId: 'role3', assignedAt: '2024-01-10T00:00:00Z', assignedBy: 'user1' },
  { userId: 'user4', roleId: 'role4', assignedAt: '2024-01-02T00:00:00Z', assignedBy: 'user1' },
  { userId: 'user5', roleId: 'role5', assignedAt: '2024-01-15T00:00:00Z', assignedBy: 'user2' },
];

// Group-Role Assignments
export const mockGroupRoles: GroupRole[] = [
  { groupId: 'group1', roleId: 'role1', assignedAt: '2024-01-01T00:00:00Z', assignedBy: 'system' },
  { groupId: 'group2', roleId: 'role4', assignedAt: '2024-01-01T00:00:00Z', assignedBy: 'user1' },
  { groupId: 'group3', roleId: 'role3', assignedAt: '2024-01-01T00:00:00Z', assignedBy: 'user1' },
  { groupId: 'group4', roleId: 'role5', assignedAt: '2024-01-01T00:00:00Z', assignedBy: 'user1' },
];

// Change Tickets
export const mockChangeTickets: ChangeTicket[] = [
  {
    id: 'chg1',
    ticketNumber: 'CHG-2024-0001',
    title: 'Database Server Upgrade',
    description: 'Upgrade production database server from PostgreSQL 14 to PostgreSQL 16 to improve performance and security.',
    type: 'normal',
    category: 'database',
    priority: 'high',
    status: 'approved',
    requesterId: 'user3',
    assigneeId: 'user2',
    approvers: [
      { approverId: 'user4', status: 'approved', comments: 'Approved with rollback plan', decidedAt: '2024-01-18T10:00:00Z' },
    ],
    impactAssessment: 'Brief downtime expected (15-30 minutes). All dependent applications will be temporarily unavailable.',
    riskLevel: 'medium',
    rollbackPlan: 'Restore from pre-upgrade backup if issues occur. Rollback time: ~20 minutes.',
    scheduledStartDate: '2024-01-25T02:00:00Z',
    scheduledEndDate: '2024-01-25T04:00:00Z',
    affectedSystems: ['Production Database', 'User Portal', 'API Gateway'],
    attachments: [],
    comments: [
      { id: 'c1', content: 'Backup verified and ready.', authorId: 'user2', createdAt: '2024-01-19T09:00:00Z' },
    ],
    auditLog: [
      { id: 'a1', action: 'Created', performedBy: 'user3', performedAt: '2024-01-15T10:00:00Z' },
      { id: 'a2', action: 'Status changed', field: 'status', oldValue: 'draft', newValue: 'pending_approval', performedBy: 'user3', performedAt: '2024-01-16T09:00:00Z' },
      { id: 'a3', action: 'Approved', performedBy: 'user4', performedAt: '2024-01-18T10:00:00Z' },
    ],
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-19T09:00:00Z',
  },
  {
    id: 'chg2',
    ticketNumber: 'CHG-2024-0002',
    title: 'Firewall Rule Update',
    description: 'Add new firewall rules to allow traffic from partner network for integration testing.',
    type: 'standard',
    category: 'network',
    priority: 'medium',
    status: 'in_progress',
    requesterId: 'user3',
    assigneeId: 'user1',
    approvers: [
      { approverId: 'user4', status: 'approved', decidedAt: '2024-01-17T14:00:00Z' },
    ],
    impactAssessment: 'No downtime expected. Change can be applied without service interruption.',
    riskLevel: 'low',
    rollbackPlan: 'Remove added firewall rules if connectivity issues arise.',
    scheduledStartDate: '2024-01-20T10:00:00Z',
    scheduledEndDate: '2024-01-20T11:00:00Z',
    actualStartDate: '2024-01-20T10:05:00Z',
    affectedSystems: ['Perimeter Firewall', 'Partner Gateway'],
    attachments: [],
    comments: [],
    auditLog: [
      { id: 'a4', action: 'Created', performedBy: 'user3', performedAt: '2024-01-14T11:00:00Z' },
      { id: 'a5', action: 'Status changed', field: 'status', oldValue: 'approved', newValue: 'in_progress', performedBy: 'user1', performedAt: '2024-01-20T10:05:00Z' },
    ],
    createdAt: '2024-01-14T11:00:00Z',
    updatedAt: '2024-01-20T10:05:00Z',
  },
  {
    id: 'chg3',
    ticketNumber: 'CHG-2024-0003',
    title: 'Security Patch Deployment',
    description: 'Deploy critical security patches to all production servers to address CVE-2024-1234.',
    type: 'emergency',
    category: 'security',
    priority: 'critical',
    status: 'pending_approval',
    requesterId: 'user1',
    assigneeId: 'user1',
    approvers: [
      { approverId: 'user4', status: 'pending' },
    ],
    impactAssessment: 'Rolling restart of services. Each server will experience 2-3 minutes downtime during patch.',
    riskLevel: 'high',
    rollbackPlan: 'Uninstall patch and restore previous package versions from backup repository.',
    scheduledStartDate: '2024-01-21T00:00:00Z',
    scheduledEndDate: '2024-01-21T04:00:00Z',
    affectedSystems: ['All Production Servers', 'Web Cluster', 'API Servers'],
    attachments: [],
    comments: [
      { id: 'c2', content: 'Urgent: This CVE is being actively exploited.', authorId: 'user1', createdAt: '2024-01-20T15:00:00Z' },
    ],
    auditLog: [
      { id: 'a6', action: 'Created', performedBy: 'user1', performedAt: '2024-01-20T14:30:00Z' },
    ],
    createdAt: '2024-01-20T14:30:00Z',
    updatedAt: '2024-01-20T15:00:00Z',
  },
  {
    id: 'chg4',
    ticketNumber: 'CHG-2024-0004',
    title: 'Application Feature Deployment',
    description: 'Deploy new customer dashboard feature to production environment.',
    type: 'normal',
    category: 'application',
    priority: 'low',
    status: 'draft',
    requesterId: 'user3',
    approvers: [],
    impactAssessment: 'No downtime. Feature toggle will control rollout.',
    riskLevel: 'low',
    rollbackPlan: 'Disable feature toggle to hide new feature.',
    affectedSystems: ['Customer Portal', 'User Dashboard'],
    attachments: [],
    comments: [],
    auditLog: [
      { id: 'a7', action: 'Created', performedBy: 'user3', performedAt: '2024-01-19T16:00:00Z' },
    ],
    createdAt: '2024-01-19T16:00:00Z',
    updatedAt: '2024-01-19T16:00:00Z',
  },
  {
    id: 'chg5',
    ticketNumber: 'CHG-2024-0005',
    title: 'Load Balancer Configuration',
    description: 'Update load balancer health check intervals and add new backend servers.',
    type: 'standard',
    category: 'infrastructure',
    priority: 'medium',
    status: 'completed',
    requesterId: 'user2',
    assigneeId: 'user1',
    approvers: [
      { approverId: 'user4', status: 'approved', decidedAt: '2024-01-10T09:00:00Z' },
    ],
    impactAssessment: 'No downtime. Changes will be applied gracefully.',
    riskLevel: 'low',
    rollbackPlan: 'Revert to previous configuration file.',
    scheduledStartDate: '2024-01-12T09:00:00Z',
    scheduledEndDate: '2024-01-12T10:00:00Z',
    actualStartDate: '2024-01-12T09:15:00Z',
    actualEndDate: '2024-01-12T09:45:00Z',
    affectedSystems: ['Load Balancer', 'Web Servers'],
    attachments: [],
    comments: [
      { id: 'c3', content: 'Change completed successfully. All health checks passing.', authorId: 'user1', createdAt: '2024-01-12T09:45:00Z' },
    ],
    auditLog: [
      { id: 'a8', action: 'Created', performedBy: 'user2', performedAt: '2024-01-08T10:00:00Z' },
      { id: 'a9', action: 'Status changed', field: 'status', oldValue: 'in_progress', newValue: 'completed', performedBy: 'user1', performedAt: '2024-01-12T09:45:00Z' },
    ],
    createdAt: '2024-01-08T10:00:00Z',
    updatedAt: '2024-01-12T09:45:00Z',
  },
];

// Helper function to get user by ID
export const getUserById = (id: string): User | undefined => {
  return mockUsers.find(u => u.id === id);
};

// Helper function to get role by ID
export const getRoleById = (id: string): Role | undefined => {
  return mockRoles.find(r => r.id === id);
};

// Helper function to get group by ID
export const getGroupById = (id: string): Group | undefined => {
  return mockGroups.find(g => g.id === id);
};
