# FOSM Platform Frontend

A comprehensive IT Service Management (ITSM) system frontend for managing changes, incidents, and configuration management databases (CMDB) with enterprise-grade features, role-based access control, and real-time workflows.

---

## Project Overview

FOSM (Flexible Operations Service Management) Platform is an enterprise IT Service Management solution designed to streamline:

- **Change Management**: Full lifecycle management of changes with approval workflows, impact assessment, and rollback planning
- **Incident Management**: Comprehensive incident tracking with priority management, assignment workflows, and resolution tracking
- **CMDB**: Configuration Item management with relationships, drift detection, integration management, and governance
- **User & Access Management**: Role-based access control (RBAC) with granular permission management

The platform integrates with **Azure Entra ID** for authentication and provides both development and testing capabilities with Mock Service Worker (MSW).

---

## Tech Stack

### Core Framework & Build
- **React** `18.3.1` - UI library
- **TypeScript** `5.8.3` - Type-safe development
- **Vite** `5.x` - Lightning-fast build tool
- **TailwindCSS** `3.4.17` - Utility-first CSS framework

### UI Components & Styling
- **shadcn/ui** - High-quality React components
- **Radix UI** - Unstyled, accessible component primitives
- **Lucide React** `0.462.0` - Beautiful SVG icons
- **Recharts** `2.15.4` - Composable charting library
- **Sonner** `1.7.4` - Toast notifications
- **next-themes** `0.3.0` - Dark/light theme support

### State Management & Data Fetching
- **TanStack React Query** `5.83.0` - Server state management
- **TanStack React Table** `8.21.3` - Headless UI for tables
- **React Router** `7.12.0` - Client-side routing

### Forms & Validation
- **React Hook Form** `7.61.1` - Performant form state management
- **Zod** `3.25.76` - TypeScript-first schema validation

### Authentication
- **Azure MSAL** (`@azure/msal-browser@4.28.1`, `@azure/msal-react@3.0.15`) - Microsoft Entra ID integration

### API & Testing
- **Mock Service Worker (MSW)** `2.12.9` - API mocking for development & testing
- **Vitest** `3.2.4` - Fast unit test framework
- **@testing-library/react** `16.0.0` - React component testing
- **@testing-library/user-event** `14.6.1` - User interaction simulation
- **JSDOM** `20.0.3` - DOM environment for tests

---

## Core Modules

### 1. **Change Management** (`src/modules/change_management/`)
Manages the complete change ticket lifecycle:
- Create, read, update, delete change tickets
- Status tracking: draft → pending_approval → approved → in_progress → completed
- Priority levels: low, medium, high, critical
- Approval workflows with CAB (Change Advisory Board) reviews
- Impact assessment and risk analysis
- Rollback planning
- Comments, attachments, and audit trails

### 2. **Incident Management** (`src/modules/incident_management/`)
Comprehensive incident handling:
- Create and track incidents
- Multiple view types: All Incidents, My Incidents
- Filtering by priority, status, assigned group, assignee
- Impact and urgency assessment
- Assignment to groups and individuals
- Resolution and closure tracking

### 3. **CMDB (Configuration Management Database)** (`src/pages/cmdb/`)
Configuration Item management:
- CI creation and lifecycle management
- CI Classes and categorization
- Relationship mapping between CIs
- Drift detection and reconciliation
- Integration management
- Governance and compliance tracking
- Audit logging

### 4. **User Management** (`src/pages/admin/`)
Administrative user operations:
- User CRUD with pagination
- Group management and assignment
- Role management and assignment
- Permission-based access control
- User status management

### 5. **Authentication & Authorization** (`src/contexts/AuthContext.tsx`)
Secure access control:
- Azure Entra ID integration with MSAL
- JWT token management
- Role-based access control (RBAC)
- Permission-based resource protection
- Protected routes with permission checking

---

## Architecture Highlights

### Directory Structure

```
src/
├── api/
├── components/
│   ├── auth/
│   ├── layout/
│   ├── shared/
│   │   ├── dropdowns/
│   │   └── paginated-table/
│   ├── widgets/
│   │   └── cmdb/
│   └── ui/
├── config/
├── contexts/
├── lib/
├── modules/
│   ├── change_management/
│   │   ├── pages/
│   │   ├── components/
│   │   └── services/
│   └── incident_management/
│       ├── pages/
│       ├── components/
│       ├── services/
│       ├── hooks/
│       ├── constants/
│       └── data/
├── pages/
│   ├── admin/
│   ├── changes/
│   ├── cmdb/
│   └── __tests__/
├── mockData/
├── mocks/
├── test/
└── types/
```

### Key Design Patterns

- **Context API**: Authentication state management with `AuthContext`
- **Custom Hooks**: Reusable logic extraction (`useAuth`, `useInitialLoadError`, `useCISearch`)
- **Protected Routes**: Permission-based route guarding with `ProtectedRoute`
- **MSW**: Request interception for consistent API mocking
- **Barrel Exports**: Simplified imports via `index.ts` files
- **Type Safety**: Comprehensive TypeScript types for all data models

---

## Testing Infrastructure

The project includes **48 passing tests** with comprehensive coverage for APIs, components, and user workflows.

### Test Files

**API Integration Tests** - `src/test/api.test.ts` (18 tests)
- Authentication workflows (login, token handling)
- User CRUD operations with pagination
- Group management
- Role management
- Change ticket lifecycle
- Error handling and edge cases

**Component Tests** - `src/pages/__tests__/LoginPage.test.tsx` (29+ tests)
- Component rendering
- User interactions
- Form validation
- Navigation and routing
- Accessibility compliance

**Test Example** - `src/test/example.test.ts`
- Basic Vitest setup verification

### Running Tests

```bash
# Run all tests once
npm test

# Run tests in watch mode (auto-rerun on changes)
npm run test:watch

# Run specific test file
npm test -- src/pages/__tests__/LoginPage.test.tsx

# Run tests matching a pattern
npm test -- --grep "LoginPage"

# Generate coverage report
npm run test:coverage
```

### Test Configuration

- **Environment**: JSDOM (browser-like DOM)
- **Framework**: Vitest with globals enabled
- **Setup**: Automatic MSW initialization via `src/test/setup.ts`
- **Coverage**: 70% threshold for lines, functions, branches, and statements
- **Reporter**: HTML and LCOV formats available

---

## Developer Guide

### Prerequisites

- **Node.js** 18+ or 20+ (recommended)
- **npm** 8+ or **yarn** 3+
- **Git** for version control

### Quick Start

#### 1. Clone the Repository

```bash
git clone <YOUR_GIT_URL>
cd FOSM-Platform-Frontend
```

#### 2. Install Dependencies

```bash
npm install --legacy-peer-deps
```

Alternatively, if issues persist, use:

```bash
npm install --force
```

#### 3. Environment Configuration

Create a `.env.local` file in the project root:

```env
# Azure Entra ID Configuration
VITE_ENTRA_CLIENT_ID=your_client_id_here
VITE_ENTRA_TENANT_ID=your_tenant_id_here
VITE_REDIRECT_URI=http://localhost:3000

# API Configuration (optional)
VITE_API_BASE_URL=/api
```

#### 4. Start Development Server

```bash
npm run dev
```

The application will start at `http://localhost:3000`. The development server includes:
- Hot Module Replacement (HMR) for instant updates
- Mock Service Worker (MSW) for API mocking
- Automatic browser reload on code changes

#### 5. Run Tests

```bash
# Run all tests
npm test

# Watch mode (recommended during development)
npm run test:watch

# With coverage report
npm run test:coverage
```

#### 6. Build for Production

```bash
npm run build
```

Creates an optimized production build in the `dist/` directory.

### Common Development Tasks

#### Linting & Code Quality

```bash
npm run lint
```

Checks code against ESLint rules. Uses TypeScript for type checking.

#### Preview Production Build

```bash
npm run build
npm run preview
```

Serves the production build locally to verify the final output.

#### Adding a New Feature

1. Create feature branch: `git checkout -b feature/your-feature`
2. Implement feature following project structure
3. Add corresponding tests in `src/**/__tests__/` or `src/test/`
4. Run tests: `npm run test:watch`
5. Commit and push: `git push origin feature/your-feature`
6. Create Pull Request

#### Adding New Types

1. Add type definition to `types/` folder
2. Export from `types/index.ts`
3. Use via `import type { YourType } from '@/types'`

#### Working with API Mocking

1. Update mock data in `src/mockData/` JSON files
2. Update handlers in `src/mocks/handlers.ts`
3. Tests automatically pick up changes
4. Development environment reloads MSW handlers

---

## Development Notes

### Library Consolidation

All utilities have been consolidated into a single `src/lib/` folder:

**Old Pattern** (Scattered):
```typescript
import { cn } from '@/lib/utils'
import { fetchWithAuth } from '@/api/httpClient'
import { getCIClassIcon } from '@/lib/cmdb-utils'
```

**New Pattern** (Consolidated):
```typescript
import { cn, fetchWithAuth, getCIClassIcon } from '@/lib'
```

All libraries are categorized:
- `lib/ui.ts` - UI utilities (cn, badge classes)
- `lib/api.ts` - API utilities (fetchWithAuth, request helpers)
- `lib/form.ts` - Form utilities and validators
- `lib/data.ts` - Data manipulation helpers
- `lib/cmdb.ts` - CMDB-specific utilities
- `lib/hooks.ts` - Custom React hooks

### State Management Strategy

- **Auth State**: React Context (`AuthContext`)
- **Server State**: TanStack React Query for API data
- **Local UI State**: React `useState` for component-level state
- **Theme State**: `next-themes` for dark/light mode

### Type Safety

All data models have TypeScript definitions in `types/`:
- **API Types**: Request/response schemas
- **Domain Types**: Change, Incident, User, etc.
- **Form Types**: Form-specific schemas
- **Auth Types**: Authentication context types

### Authentication Flow

1. User logs in via LoginPage
2. Credentials sent to `/api/auth/login`
3. Token stored in localStorage
4. `AuthContext` loads user roles and permissions
5. `ProtectedRoute` validates access per route
6. Routes render with permission checks

### Permission Model

```typescript
Permission = { resource: string, action: 'create' | 'read' | 'update' | 'delete' | 'approve' }
```

Example protection:
```typescript
<ProtectedRoute requiredPermission={{ resource: "change_tickets", action: "approve" }}>
  <ApprovalPage />
</ProtectedRoute>
```

### Performance Optimizations

- **Code Splitting**: React Router handles lazy-loaded routes
- **Component Memoization**: shadcn/ui components are optimized
- **Query Caching**: TanStack React Query caches API responses
- **CSS Modules**: TailwindCSS purges unused styles in production
- **Image Optimization**: SVG icons via Lucide React

### Browser Support

- Chrome (latest 2 versions)
- Firefox (latest 2 versions)
- Safari (latest 2 versions)
- Edge (latest 2 versions)

### Troubleshooting

**MSW not intercepting requests?**
- Check browser console for MSW activation messages
- Ensure handlers are defined in `src/mocks/handlers.ts`
- Try clearing browser cache and restarting dev server

**Tests failing?**
- Run `npm install` to ensure all dependencies are up-to-date
- Delete `node_modules/` and reinstall if issues persist
- Check MSW server is started in `src/test/setup.ts`

**Authentication issues?**
- Verify Entra ID config in `src/config/authConfig.ts`
- Check environment variables are set correctly
- Ensure redirect URI matches Entra ID application settings

---

## Additional Resources

- [Mock Service Worker Documentation](src/mocks/README.md)
- [Testing Guide](TESTING.md)
- [TanStack Query Setup](TANSTACK_QUERY_SETUP.md)
- [Library Consolidation Details](LIBRARY_CONSOLIDATION_COMPLETE.md)

---

**Built with Vite, React, TypeScript, and shadcn/ui**