import { User, Group, Role, Permission, UserRole, GroupRole, ChangeTicket } from '@/types';
import incidentsData from './incidents.json';
import usersData from './users.json';
import changesData from './changes.json';
import categoriesData from './categories.json';
import userGroupData from './user.group.json';
import { loadIncidentsFromStorage } from './storage';

// Incidents Mock Data - Initialize from localStorage or fallback to JSON
const storedIncidents = loadIncidentsFromStorage();
export let mockAllIncidentsData = storedIncidents || incidentsData.incidents;

// Categories Mock Data
export const mockCategories = categoriesData;

// Users Mock Data
export const mockUsers = usersData.users as User[];

// Groups Mock Data - Transform from user.group.json to Group interface
export const mockGroups: Group[] = (userGroupData.usergroups || []).map((group: any) => ({
  id: group.id,
  name: group.groupName,
  description: `${group.groupName} team`,
  members: [],
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
}));

// Changes Mock Data
export const mockChangeTickets = changesData.changes as ChangeTicket[];

// Permissions
export const mockPermissions: Permission[] = [
  { id: 'p1', resource: 'change_tickets', action: 'create' },
  { id: 'p2', resource: 'change_tickets', action: 'read' },
  { id: 'p3', resource: 'change_tickets', action: 'update' },
  { id: 'p4', resource: 'change_tickets', action: 'delete' },
  { id: 'p5', resource: 'change_tickets', action: 'approve' },
  { id: 'p6', resource: 'users', action: 'create' },
  { id: 'p7', resource: 'users', action: 'read' },
  { id: 'p8', resource: 'users', action: 'update' },
  { id: 'p9', resource: 'users', action: 'delete' },
  { id: 'p10', resource: 'roles', action: 'create' },
  { id: 'p11', resource: 'roles', action: 'read' },
  { id: 'p12', resource: 'roles', action: 'update' },
  { id: 'p13', resource: 'roles', action: 'delete' },
  { id: 'p14', resource: 'groups', action: 'create' },
  { id: 'p15', resource: 'groups', action: 'read' },
  { id: 'p16', resource: 'groups', action: 'update' },
  { id: 'p17', resource: 'groups', action: 'delete' },
];

// Roles
export const mockRoles: Role[] = [
  {
    id: 'role1',
    name: 'Administrator',
    description: 'Full system access with all permissions',
    permissions: mockPermissions,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'role2',
    name: 'Change Manager',
    description: 'Can create, update, and approve change tickets',
    permissions: mockPermissions.filter(p =>
      p.resource === 'change_tickets' || (p.resource === 'users' && p.action === 'read')
    ),
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'role3',
    name: 'Change Requester',
    description: 'Can create and view change tickets',
    permissions: mockPermissions.filter(p =>
      p.resource === 'change_tickets' && ['create', 'read'].includes(p.action)
    ),
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'role4',
    name: 'Approver',
    description: 'Can view and approve change tickets',
    permissions: mockPermissions.filter(p =>
      p.resource === 'change_tickets' && ['read', 'approve'].includes(p.action)
    ),
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'role5',
    name: 'Viewer',
    description: 'Read-only access to change tickets',
    permissions: mockPermissions.filter(p =>
      p.resource === 'change_tickets' && p.action === 'read'
    ),
    createdAt: '2024-01-01T00:00:00Z',
  },
];

// User-Role Assignments
export const mockUserRoles: UserRole[] = [
  { userId: 'user1', roleId: 'role1', assignedAt: '2024-01-01T00:00:00Z', assignedBy: 'system' },
  { userId: 'user2', roleId: 'role2', assignedAt: '2024-01-05T00:00:00Z', assignedBy: 'user1' },
  { userId: 'user3', roleId: 'role3', assignedAt: '2024-01-10T00:00:00Z', assignedBy: 'user1' },
  { userId: 'user4', roleId: 'role4', assignedAt: '2024-01-02T00:00:00Z', assignedBy: 'user1' },
  { userId: 'user5', roleId: 'role5', assignedAt: '2024-01-15T00:00:00Z', assignedBy: 'user2' },
];

// Group-Role Assignments
export const mockGroupRoles: GroupRole[] = [
  { groupId: 'group1', roleId: 'role1', assignedAt: '2024-01-01T00:00:00Z', assignedBy: 'system' },
  { groupId: 'group2', roleId: 'role4', assignedAt: '2024-01-01T00:00:00Z', assignedBy: 'user1' },
  { groupId: 'group3', roleId: 'role3', assignedAt: '2024-01-01T00:00:00Z', assignedBy: 'user1' },
  { groupId: 'group4', roleId: 'role5', assignedAt: '2024-01-01T00:00:00Z', assignedBy: 'user1' },
];

// Helper function to get user by ID
export const getUserById = (id: string): User | undefined => {
  return mockUsers.find(u => u.id === id);
};

// Helper function to get role by ID
export const getRoleById = (id: string): Role | undefined => {
  return mockRoles.find(r => r.id === id);
};

// Helper function to get group by ID
export const getGroupById = (id: string): Group | undefined => {
  return mockGroups.find(g => g.id === id);
};

// Helper function to get category name by ID
export const getCategoryName = (categoryId: number): string => {
  const category = mockCategories.find(c => c.id === categoryId);
  return category ? category.name : 'Unknown';
};
