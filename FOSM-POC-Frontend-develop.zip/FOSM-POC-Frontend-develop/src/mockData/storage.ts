/**
 * Mock Data Storage Utility
 * Persists mock data to localStorage for development/testing
 */

import { Incident } from '@/types';

const INCIDENTS_STORAGE_KEY = 'mock_incidents_data';

/**
 * Load incidents from localStorage
 * Returns null if not found in storage
 */
export const loadIncidentsFromStorage = (): Incident[] | null => {
  if (typeof window === 'undefined') return null;

  try {
    const stored = localStorage.getItem(INCIDENTS_STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      return Array.isArray(parsed) ? parsed : null;
    }
  } catch (error) {
    console.error('Failed to load incidents from localStorage:', error);
  }

  return null;
};

/**
 * Save incidents to localStorage
 */
export const saveIncidentsToStorage = (incidents: Incident[]): void => {
  if (typeof window === 'undefined') return;

  try {
    localStorage.setItem(INCIDENTS_STORAGE_KEY, JSON.stringify(incidents));
  } catch (error) {
    console.error('Failed to save incidents to localStorage:', error);
  }
};

/**
 * Clear incidents from localStorage
 */
export const clearIncidentsFromStorage = (): void => {
  if (typeof window === 'undefined') return;

  try {
    localStorage.removeItem(INCIDENTS_STORAGE_KEY);
  } catch (error) {
    console.error('Failed to clear incidents from localStorage:', error);
  }
};
