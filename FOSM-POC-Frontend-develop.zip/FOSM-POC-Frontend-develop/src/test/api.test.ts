/**
 * Example test file showing how to use MSW for intercepting API calls
 * 
 * This demonstrates common testing patterns with Mock Service Worker
 */

import { describe, it, expect, afterEach } from 'vitest';
import { server } from '@/mocks/server';
import { HttpResponse, http } from 'msw';
import { authApi, usersApi, changesApi } from '@/api';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api';

describe('API with MSW', () => {
  describe('Authentication API', () => {
    it('should fail login with invalid credentials', async () => {
      try {
        await authApi.login('wrong@example.com', 'wrongpassword');
        expect.fail('Should have thrown an error');
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe('Users API', () => {
    it('should fetch paginated users', async () => {
      const response = await usersApi.getAll(1, 10);
      
      expect(response.data).toBeInstanceOf(Array);
      expect(response.page).toBe(1);
      expect(response.pageSize).toBe(10);
      expect(response.totalCount).toBeGreaterThan(0);
    });

    it('should create a new user', async () => {
      const newUser = {
        email: 'newuser@example.com',
        firstName: 'New',
        lastName: 'User',
      };
      
      const created = await usersApi.create(newUser);
      expect(created.id).toBeDefined();
      expect(created.email).toBe('newuser@example.com');
      expect(created.status).toBe('active');
    });
  });

  describe('Change Tickets API', () => {
    it('should fetch paginated change tickets', async () => {
      const response = await changesApi.getAll(1, 20);
      
      expect(response.data).toBeInstanceOf(Array);
      expect(response.page).toBe(1);
      expect(response.totalCount).toBeGreaterThan(0);
    });

    it('should filter tickets by status', async () => {
      const response = await changesApi.getAll(1, 20, { status: 'approved' });
      
      expect(response.data.every(t => t.status === 'approved')).toBe(true);
    });

    it('should filter tickets by priority', async () => {
      const response = await changesApi.getAll(1, 20, { priority: 'high' });
      
      expect(response.data.every(t => t.priority === 'high')).toBe(true);
    });

    it('should get a specific ticket', async () => {
      const ticket = await changesApi.getById('chg1');
      expect(ticket.id).toBe('chg1');
      expect(ticket.title).toBeDefined();
    });

    it('should create a new ticket', async () => {
      const newTicket = {
        title: 'New Change',
        description: 'Test change ticket',
        category: 'Software',
        requestedBy: 'user@example.com',
      };
      
      const created = await changesApi.create(newTicket);
      expect(created.id).toBeDefined();
      expect(created.status).toBe('pending');
    });

    it('should approve a ticket', async () => {
      const approved = await changesApi.approve('chg2', 'Looks good');
      expect(approved.status).toBe('approved');
      expect(approved.approvalComments).toBe('Looks good');
    });

    it('should reject a ticket', async () => {
      const rejected = await changesApi.reject('chg3', 'Need more testing');
      expect(rejected.status).toBe('rejected');
      expect(rejected.approvalComments).toBe('Need more testing');
    });

    it('should add a comment to a ticket', async () => {
      await changesApi.addComment('chg1', 'This is a test comment');
      // The response is void, so just verify no error is thrown
    });
  });

  describe('Override handlers in tests', () => {
    it('should override default handler for specific test', async () => {
      // Override the handler for this specific test
      server.use(
        http.get(`${API_BASE_URL}/users/user1`, () => {
          return HttpResponse.json(
            {
              id: 'user1',
              email: 'customuser@example.com',
              firstName: 'Custom',
              lastName: 'User',
              role: 'Admin',
              status: 'inactive',
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            },
            { status: 200 }
          );
        })
      );

      const user = await usersApi.getById('user1');
      expect(user.email).toBe('customuser@example.com');
      expect(user.status).toBe('inactive');
    });

    it('should simulate error responses', async () => {
      server.use(
        http.get(`${API_BASE_URL}/users/999`, () => {
          return HttpResponse.json(
            { error: 'User not found' },
            { status: 404 }
          );
        })
      );

      try {
        await usersApi.getById('999');
        expect.fail('Should have thrown an error');
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });
});
