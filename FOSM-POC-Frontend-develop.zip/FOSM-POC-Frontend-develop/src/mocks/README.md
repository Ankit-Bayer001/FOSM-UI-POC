# Mock Service Worker (MSW) Setup

This project uses Mock Service Worker (MSW) to intercept and mock API calls during development and testing. This allows you to:

- Develop features without a running backend server
- Write tests without making real API calls
- Ensure consistent API responses across tests
- Simulate error scenarios and edge cases

## Files Overview

### `src/mocks/handlers.ts`
Contains all request handlers that intercept API calls. Handlers define what mock data is returned for each endpoint.

**Covered Endpoints:**
- **Authentication**: Login, logout, get current user
- **User Management**: CRUD operations with pagination
- **Group Management**: CRUD operations  
- **Role Management**: CRUD operations
- **Change Tickets**: CRUD, filtering, approval workflows, comments

**Mock Data:**
- 3 mock users with different roles
- 2 mock groups
- 3 mock roles
- 3 mock change tickets with various statuses

### `src/mocks/server.ts`
Sets up the MSW server for Node.js environment (tests). This is automatically integrated into the test setup.

### `src/mocks/browser.ts`
Sets up the MSW worker for the browser environment (development). Can be optionally started in your app.

### `src/test/setup.ts`
Configures vitest to use MSW for all tests. Automatically starts/stops the server before/after tests.

### `src/test/api.test.ts`
Example test file demonstrating how to use MSW for testing API calls.

## Running Tests

Tests automatically use MSW without any additional configuration:

```bash
npm run test           # Run tests once
npm run test:watch    # Run tests in watch mode
```

## Using MSW in Development

To use MSW during browser development (optional):

1. Update `src/main.tsx`:
```tsx
import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Enable MSW in development
if (import.meta.env.DEV) {
  import('@/mocks/browser').then(({ worker }) => {
    worker.start({
      onUnhandledRequest: 'warn', // or 'bypass' to allow unhandled requests
    });
  });
}

createRoot(document.getElementById("root")!).render(<App />);
```

2. Check browser console - you should see MSW activation messages

3. All API requests will now be intercepted and return mock data

## Adding New API Handlers

When you add new API endpoints:

1. Open `src/mocks/handlers.ts`
2. Add a new `http.get`, `http.post`, `http.put`, or `http.delete` handler:

```typescript
http.get(`${API_BASE_URL}/your-endpoint`, ({ params }) => {
  // Implement your handler
  return HttpResponse.json({ data: 'mock response' });
}),
```

3. For POST/PUT requests that receive a body:
```typescript
http.post(`${API_BASE_URL}/your-endpoint`, async ({ request }) => {
  const body = await request.json();
  // Process and return response
  return HttpResponse.json(newData, { status: 201 });
}),
```

## Testing Patterns

### Basic API Test
```typescript
import { usersApi } from '@/services/api';

it('should fetch users', async () => {
  const response = await usersApi.getAll();
  expect(response.data).toBeDefined();
});
```

### Testing with Filters
```typescript
it('should filter by status', async () => {
  const response = await changeTicketsApi.getAll(1, 20, { 
    status: 'approved' 
  });
  
  expect(response.data.every(t => t.status === 'approved')).toBe(true);
});
```

### Overriding Handlers in Tests
Sometimes you need different mock responses for specific tests:

```typescript
import { server } from '@/mocks/server';
import { http, HttpResponse } from 'msw';

it('should handle custom response', async () => {
  server.use(
    http.get(`${API_BASE_URL}/users/1`, () => {
      return HttpResponse.json({ 
        id: '1', 
        email: 'custom@example.com' 
      });
    })
  );

  const user = await usersApi.getById('1');
  expect(user.email).toBe('custom@example.com');
});
```

### Simulating Errors
```typescript
it('should handle 404 errors', async () => {
  server.use(
    http.get(`${API_BASE_URL}/users/999`, () => {
      return HttpResponse.json(
        { error: 'Not found' },
        { status: 404 }
      );
    })
  );

  expect(() => usersApi.getById('999')).rejects.toThrow();
});
```

### Testing Network Failures
```typescript
it('should handle network errors', async () => {
  server.use(
    http.get(`${API_BASE_URL}/users`, () => {
      return HttpResponse.error();
    })
  );

  expect(() => usersApi.getAll()).rejects.toThrow();
});
```

## Mock Data Structure

### User
```typescript
{
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  status: 'active' | 'inactive';
  createdAt: string;
  updatedAt: string;
}
```

### Change Ticket
```typescript
{
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'pending_approval' | 'approved' | 'rejected';
  priority: 'low' | 'medium' | 'high';
  category: string;
  requestedBy: string;
  assignedTo: string | null;
  plannedStartDate: string;
  plannedEndDate: string;
  actualStartDate: string | null;
  actualEndDate: string | null;
  riskLevel: 'low' | 'medium' | 'high';
  createdAt: string;
  updatedAt: string;
  comments: any[];
  approvalComments: string | null;
}
```

## Disabling MSW for Specific Tests

If you need to test real API calls (not recommended):

```typescript
describe('Real API tests', () => {
  beforeAll(() => server.close());
  afterAll(() => server.listen());

  it('should make real API call', async () => {
    // This will make a real API call
  });
});
```

## Troubleshooting

### "Failed to register Service Worker"
- Make sure MSW is running in the right environment
- Check browser console for specific errors
- Verify `public/mockServiceWorker.js` exists (MSW should create this)

### Undefined Mock Data
- Check that handlers are properly exporting from `src/mocks/handlers.ts`
- Verify the API URL matches `API_BASE_URL` in handlers
- Use `server.printHandlers()` to debug registered handlers

### Handlers Not Being Called
- Check that the request URL exactly matches the handler pattern
- Verify HTTP method (GET, POST, etc.) is correct
- Use MSW devtools to inspect requests

## Resources

- [MSW Documentation](https://mswjs.io/)
- [MSW Testing Guide](https://mswjs.io/docs/getting-started/integrate/node)
- [HTTP Handler API](https://mswjs.io/docs/api/http)
