/**
 * Optional: Enable MSW in development
 * 
 * This file shows how to integrate MSW into your development environment
 * so you can work without a backend server.
 * 
 * To use this, uncomment the MSW initialization in src/main.tsx
 */

// In src/main.tsx, add this at the top:
/*
import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Enable MSW in development for API mocking
if (import.meta.env.DEV) {
  import('@/mocks/browser').then(({ worker }) => {
    worker.start({
      // 'warn' will log unhandled requests to console
      // 'bypass' will let unhandled requests through
      // 'error' will throw an error for unhandled requests
      onUnhandledRequest: 'warn',
    });
  });
}

createRoot(document.getElementById("root")!).render(<App />);
*/

// When running with MSW enabled:
// 1. Open browser DevTools (F12)
// 2. Go to Console tab
// 3. You should see: "[MSW] Mocking enabled."
// 4. All API calls will now return mock data instead of making real requests

// To disable MSW temporarily:
// - Go to Application > Service Workers in DevTools and unregister
// - Or comment out the MSW initialization in main.tsx
