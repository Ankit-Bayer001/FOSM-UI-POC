import { setupWorker } from 'msw/browser';
import { handlers } from './handlers';

/**
 * Browser-based MSW worker for development.
 * This allows intercepting API calls during development without needing tests.
 * 
 * Start the worker in your development setup:
 * if (import.meta.env.DEV) {
 *   import('@/mocks/browser').then(({ worker }) => {
 *     worker.start();
 *   });
 * }
 */
export const worker = setupWorker(...handlers);
