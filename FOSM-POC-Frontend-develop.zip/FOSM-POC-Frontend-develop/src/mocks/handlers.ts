import { http, HttpResponse } from 'msw';
import { PaginatedResponse } from '@/types';
import { mockUsers, mockGroups, mockRoles, mockChangeTickets, mockAllIncidentsData } from '@/mockData';
import { saveIncidentsToStorage } from '@/mockData/storage';

export const handlers = [
  // Authentication endpoints
  http.post(`/api/auth/login`, async ({ request }) => {
    const body = (await request.json()) as { email: string; password: string };
    
    if (body.email === 'admin@company.com' && body.password === 'password') {
      const user = mockUsers[0];
      return HttpResponse.json({
        user,
        token: 'mock-jwt-token-' + Date.now(),
      });
    }
    
    return HttpResponse.json(
      { error: 'Invalid credentials' },
      { status: 401 }
    );
  }),

  http.post(`/api/auth/logout`, () => {
    return HttpResponse.json({ success: true });
  }),

  http.get(`/api/auth/me`, () => {
    return HttpResponse.json(mockUsers[0]);
  }),

  // User Management endpoints
  http.get(`/api/users`, ({ request }) => {
    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get('page') || '1', 10);
    const pageSize = parseInt(url.searchParams.get('pageSize') || '20', 10);
    const assignedGroups = url.searchParams.get('assignedGroups');
    
    // Filter users by assignedGroups if provided
    let filteredUsers = mockUsers;
    if (assignedGroups) {
      filteredUsers = mockUsers.filter(u => u.assignedGroups === assignedGroups);
    }
    
    const startIdx = (page - 1) * pageSize;
    const endIdx = startIdx + pageSize;
    const paginatedUsers = filteredUsers.slice(startIdx, endIdx);
    
    return HttpResponse.json({
      data: paginatedUsers,
      page,
      pageSize,
      totalCount: filteredUsers.length,
      totalPages: Math.ceil(filteredUsers.length / pageSize),
    } as PaginatedResponse<User>);
  }),

  http.get(`/api/users/:id`, ({ params }) => {
    const user = mockUsers.find(u => u.id === params.id);
    if (!user) {
      return HttpResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }
    return HttpResponse.json(user);
  }),

  http.post(`/api/users`, async ({ request }) => {
    const body = (await request.json()) as Partial<User>;
    const newUser: User = {
      id: String(mockUsers.length + 1),
      email: body.email || '',
      firstName: body.firstName || '',
      lastName: body.lastName || '',
      role: body.role || 'User',
      status: 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    mockUsers.push(newUser);
    return HttpResponse.json(newUser, { status: 201 });
  }),

  http.put(`/api/users/:id`, async ({ params, request }) => {
    const body = (await request.json()) as Partial<User>;
    const userIdx = mockUsers.findIndex(u => u.id === params.id);
    
    if (userIdx === -1) {
      return HttpResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }
    
    const updatedUser = { ...mockUsers[userIdx], ...body, updatedAt: new Date().toISOString() };
    mockUsers[userIdx] = updatedUser;
    return HttpResponse.json(updatedUser);
  }),

  http.delete(`/api/users/:id`, ({ params }) => {
    const userIdx = mockUsers.findIndex(u => u.id === params.id);
    
    if (userIdx === -1) {
      return HttpResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }
    
    mockUsers.splice(userIdx, 1);
    return HttpResponse.json(undefined, { status: 204 });
  }),

  http.get(`/api/users/:userId/roles`, ({ params }) => {
    const userRoles = mockRoles.filter(role => mockUsers.find(u => u.id === params.userId)?.role === role.name);
    return HttpResponse.json(userRoles);
  }),

  http.post(`/api/users/:userId/roles/:roleId`, () => {
    return HttpResponse.json({ success: true }, { status: 201 });
  }),

  http.delete(`/api/users/:userId/roles/:roleId`, () => {
    return HttpResponse.json(undefined, { status: 204 });
  }),

  // Group Management endpoints
  http.get(`/api/groups`, () => {
    const sortedGroups = [...mockGroups].sort((a, b) => a.name.localeCompare(b.name));
    return HttpResponse.json(sortedGroups);
  }),

  http.get(`/api/groups/:id`, ({ params }) => {
    const group = mockGroups.find(g => g.id === params.id);
    if (!group) {
      return HttpResponse.json(
        { error: 'Group not found' },
        { status: 404 }
      );
    }
    return HttpResponse.json(group);
  }),

  http.post(`/api/groups`, async ({ request }) => {
    const body = (await request.json()) as Partial<Group>;
    const newGroup: Group = {
      id: String(mockGroups.length + 1),
      name: body.name || '',
      description: body.description || '',
      members: body.members || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    mockGroups.push(newGroup);
    return HttpResponse.json(newGroup, { status: 201 });
  }),

  http.put(`/api/groups/:id`, async ({ params, request }) => {
    const body = (await request.json()) as Partial<Group>;
    const groupIdx = mockGroups.findIndex(g => g.id === params.id);
    
    if (groupIdx === -1) {
      return HttpResponse.json(
        { error: 'Group not found' },
        { status: 404 }
      );
    }
    
    const updatedGroup = { ...mockGroups[groupIdx], ...body, updatedAt: new Date().toISOString() };
    mockGroups[groupIdx] = updatedGroup;
    return HttpResponse.json(updatedGroup);
  }),

  http.delete(`/api/groups/:id`, ({ params }) => {
    const groupIdx = mockGroups.findIndex(g => g.id === params.id);
    
    if (groupIdx === -1) {
      return HttpResponse.json(
        { error: 'Group not found' },
        { status: 404 }
      );
    }
    
    mockGroups.splice(groupIdx, 1);
    return HttpResponse.json(undefined, { status: 204 });
  }),

  http.post(`/api/groups/:groupId/members/:userId`, () => {
    return HttpResponse.json({ success: true }, { status: 201 });
  }),

  http.delete(`/api/groups/:groupId/members/:userId`, () => {
    return HttpResponse.json(undefined, { status: 204 });
  }),

  // Role Management endpoints
  http.get(`/api/roles`, () => {
    return HttpResponse.json(mockRoles);
  }),

  http.get(`/api/roles/:id`, ({ params }) => {
    const role = mockRoles.find(r => r.id === params.id);
    if (!role) {
      return HttpResponse.json(
        { error: 'Role not found' },
        { status: 404 }
      );
    }
    return HttpResponse.json(role);
  }),

  http.post(`/api/roles`, async ({ request }) => {
    const body = (await request.json()) as Partial<Role>;
    const newRole: Role = {
      id: String(mockRoles.length + 1),
      name: body.name || '',
      description: body.description || '',
      permissions: body.permissions || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    mockRoles.push(newRole);
    return HttpResponse.json(newRole, { status: 201 });
  }),

  http.put(`/api/roles/:id`, async ({ params, request }) => {
    const body = (await request.json()) as Partial<Role>;
    const roleIdx = mockRoles.findIndex(r => r.id === params.id);
    
    if (roleIdx === -1) {
      return HttpResponse.json(
        { error: 'Role not found' },
        { status: 404 }
      );
    }
    
    const updatedRole = { ...mockRoles[roleIdx], ...body, updatedAt: new Date().toISOString() };
    mockRoles[roleIdx] = updatedRole;
    return HttpResponse.json(updatedRole);
  }),

  http.delete(`/api/roles/:id`, ({ params }) => {
    const roleIdx = mockRoles.findIndex(r => r.id === params.id);
    
    if (roleIdx === -1) {
      return HttpResponse.json(
        { error: 'Role not found' },
        { status: 404 }
      );
    }
    
    mockRoles.splice(roleIdx, 1);
    return HttpResponse.json(undefined, { status: 204 });
  }),

  // Change Ticket endpoints
  http.get(`/api/changes`, ({ request }) => {
    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get('page') || '1', 10);
    const pageSize = parseInt(url.searchParams.get('pageSize') || '20', 10);
    const status = url.searchParams.get('status');
    const priority = url.searchParams.get('priority');
    
    let filteredTickets = mockChangeTickets;
    
    if (status) {
      filteredTickets = filteredTickets.filter(t => t.status === status);
    }
    
    if (priority) {
      filteredTickets = filteredTickets.filter(t => t.priority === priority);
    }
    
    const startIdx = (page - 1) * pageSize;
    const endIdx = startIdx + pageSize;
    const paginatedTickets = filteredTickets.slice(startIdx, endIdx);
    
    return HttpResponse.json({
      data: paginatedTickets,
      page,
      pageSize,
      totalCount: filteredTickets.length,
      totalPages: Math.ceil(filteredTickets.length / pageSize),
    } as PaginatedResponse<ChangeTicket>);
  }),

  http.get(`/api/changes/:id`, ({ params }) => {
    const ticket = mockChangeTickets.find(t => t.id === params.id);
    if (!ticket) {
      return HttpResponse.json(
        { error: 'Change ticket not found' },
        { status: 404 }
      );
    }
    return HttpResponse.json(ticket);
  }),

  http.post(`/api/changes`, async ({ request }) => {
    const body = (await request.json()) as Partial<ChangeTicket>;
    const newTicket: ChangeTicket = {
      id: `CHG-${String(mockChangeTickets.length + 1).padStart(3, '0')}`,
      title: body.title || '',
      description: body.description || '',
      status: 'pending',
      priority: body.priority || 'medium',
      category: body.category || '',
      requestedBy: body.requestedBy || '',
      assignedTo: body.assignedTo || null,
      plannedStartDate: body.plannedStartDate || new Date().toISOString(),
      plannedEndDate: body.plannedEndDate || new Date().toISOString(),
      actualStartDate: null,
      actualEndDate: null,
      riskLevel: body.riskLevel || 'low',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      comments: [],
      approvalComments: null,
    };
    mockChangeTickets.push(newTicket);
    return HttpResponse.json(newTicket, { status: 201 });
  }),

  http.put(`/api/changes/:id`, async ({ params, request }) => {
    const body = (await request.json()) as Partial<ChangeTicket>;
    const ticketIdx = mockChangeTickets.findIndex(t => t.id === params.id);
    
    if (ticketIdx === -1) {
      return HttpResponse.json(
        { error: 'Change ticket not found' },
        { status: 404 }
      );
    }
    
    const updatedTicket = { ...mockChangeTickets[ticketIdx], ...body, updatedAt: new Date().toISOString() };
    mockChangeTickets[ticketIdx] = updatedTicket;
    return HttpResponse.json(updatedTicket);
  }),

  http.post(`/api/changes/:id/submit`, ({ params }) => {
    const ticketIdx = mockChangeTickets.findIndex(t => t.id === params.id);
    
    if (ticketIdx === -1) {
      return HttpResponse.json(
        { error: 'Change ticket not found' },
        { status: 404 }
      );
    }
    
    mockChangeTickets[ticketIdx].status = 'pending_approval';
    mockChangeTickets[ticketIdx].updatedAt = new Date().toISOString();
    return HttpResponse.json(mockChangeTickets[ticketIdx]);
  }),

  http.post(`/api/changes/:id/approve`, async ({ params, request }) => {
    const body = (await request.json()) as { comments?: string };
    const ticketIdx = mockChangeTickets.findIndex(t => t.id === params.id);
    
    if (ticketIdx === -1) {
      return HttpResponse.json(
        { error: 'Change ticket not found' },
        { status: 404 }
      );
    }
    
    mockChangeTickets[ticketIdx].status = 'approved';
    mockChangeTickets[ticketIdx].approvalComments = body.comments || '';
    mockChangeTickets[ticketIdx].updatedAt = new Date().toISOString();
    return HttpResponse.json(mockChangeTickets[ticketIdx]);
  }),

  http.post(`/api/changes/:id/reject`, async ({ params, request }) => {
    const body = (await request.json()) as { comments: string };
    const ticketIdx = mockChangeTickets.findIndex(t => t.id === params.id);
    
    if (ticketIdx === -1) {
      return HttpResponse.json(
        { error: 'Change ticket not found' },
        { status: 404 }
      );
    }
    
    mockChangeTickets[ticketIdx].status = 'rejected';
    mockChangeTickets[ticketIdx].approvalComments = body.comments;
    mockChangeTickets[ticketIdx].updatedAt = new Date().toISOString();
    return HttpResponse.json(mockChangeTickets[ticketIdx]);
  }),

  http.post(`/api/changes/:id/comments`, async ({ params, request }) => {
    const body = (await request.json()) as { content: string };
    const ticket = mockChangeTickets.find(t => t.id === params.id);
    
    if (!ticket) {
      return HttpResponse.json(
        { error: 'Change ticket not found' },
        { status: 404 }
      );
    }
    
    ticket.comments.push({
      id: String(ticket.comments.length + 1),
      author: 'user@example.com',
      content: body.content,
      createdAt: new Date().toISOString(),
    } as any);
    
    return HttpResponse.json({ success: true }, { status: 201 });
  }),

  // Incident Management endpoints
  http.get(`/api/incidents`, ({ request }) => {
    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get('page') || '1', 10);
    const pageSize = parseInt(url.searchParams.get('pageSize') || '20', 10);
    const status = url.searchParams.get('status');
    const priority = url.searchParams.get('priority');
    const search = url.searchParams.get('search');
    const reportedBy = url.searchParams.get('reportedBy');
    const assignedGroup = url.searchParams.get('assignedGroup');
    const assignedTo = url.searchParams.get('assignedTo');
    const userId = url.searchParams.get('userId');
    const sortBy = url.searchParams.get('sortBy') || 'createdAt';
    const sortOrder = url.searchParams.get('sortOrder') || 'desc';
    
    let filteredIncidents = mockAllIncidentsData;
    
    if (status) {
      filteredIncidents = filteredIncidents.filter(i => String(i.status) === status);
    }
    
    if (priority) {
      filteredIncidents = filteredIncidents.filter(i => i.priority === priority);
    }
    
    if (search) {
      const q = search.toLowerCase();
      filteredIncidents = filteredIncidents.filter(i =>
        i.incidentNumber.toLowerCase().includes(q) ||
        i.title.toLowerCase().includes(q) ||
        i.description.toLowerCase().includes(q)
      );
    }
    
    if (reportedBy) {
      filteredIncidents = filteredIncidents.filter(i =>
        i.reportedBy === reportedBy
      );
    }
    
    if (assignedGroup) {
      filteredIncidents = filteredIncidents.filter(i =>
        i.assignedGroups === assignedGroup
      );
    }
    
    if (assignedTo) {
      filteredIncidents = filteredIncidents.filter(i =>
        i.assignedTo === assignedTo
      );
    }

    // Filter by userId if provided (for myIncidentsOnly)
    if (userId) {
      filteredIncidents = filteredIncidents.filter(i =>
        i.assignedTo === userId || i.reportedBy === userId
      );
    }

    // Sort the results
    filteredIncidents = filteredIncidents.sort((a, b) => {
      let aValue = a[sortBy as keyof typeof a];
      let bValue = b[sortBy as keyof typeof b];

      // Handle date strings
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        aValue = new Date(aValue).getTime();
        bValue = new Date(bValue).getTime();
      }

      if (aValue < bValue) {
        return sortOrder === 'asc' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortOrder === 'asc' ? 1 : -1;
      }
      return 0;
    });
    
    const startIdx = (page - 1) * pageSize;
    const endIdx = startIdx + pageSize;
    const paginatedIncidents = filteredIncidents.slice(startIdx, endIdx);
    
    return HttpResponse.json({
      data: paginatedIncidents,
      page,
      pageSize,
      total: filteredIncidents.length,
      totalPages: Math.ceil(filteredIncidents.length / pageSize),
    } as PaginatedResponse<any>);
  }),

  http.get(`/api/incidents/my`, ({ request }) => {
    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get('page') || '1', 10);
    const pageSize = parseInt(url.searchParams.get('pageSize') || '20', 10);
    const sortBy = url.searchParams.get('sortBy') || 'createdAt';
    const sortOrder = url.searchParams.get('sortOrder') || 'desc';
    const currentUserId = 'current-user-id'; // In real app, get from auth context
    
    let myIncidents = mockAllIncidentsData.filter(i => i.assignedTo === currentUserId);

    // Sort the results
    myIncidents = myIncidents.sort((a, b) => {
      let aValue = a[sortBy as keyof typeof a];
      let bValue = b[sortBy as keyof typeof b];

      // Handle date strings
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        aValue = new Date(aValue).getTime();
        bValue = new Date(bValue).getTime();
      }

      if (aValue < bValue) {
        return sortOrder === 'asc' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortOrder === 'asc' ? 1 : -1;
      }
      return 0;
    });
    
    const startIdx = (page - 1) * pageSize;
    const endIdx = startIdx + pageSize;
    const paginatedIncidents = myIncidents.slice(startIdx, endIdx);
    
    return HttpResponse.json({
      data: paginatedIncidents,
      page,
      pageSize,
      total: myIncidents.length,
      totalPages: Math.ceil(myIncidents.length / pageSize),
    } as PaginatedResponse<any>);
  }),

  http.get(`/api/incidents/:id`, ({ params }) => {
    const incident = mockAllIncidentsData.find(i => i.id === params.id);
    if (!incident) {
      return HttpResponse.json(
        { error: 'Incident not found' },
        { status: 404 }
      );
    }
    return HttpResponse.json(incident);
  }),

  http.post(`/api/incidents`, async ({ request }) => {
    const body = (await request.json()) as any;
    const newIncident = {
      id: crypto.randomUUID(),
      incidentNumber: `INC-${Date.now()}`,
      ...body,
      createdDate: new Date().toISOString(),
      resolvedDate: null,
      closedDate: null,
      resolution: null,
    };
    mockAllIncidentsData.push(newIncident);
    saveIncidentsToStorage(mockAllIncidentsData);
    return HttpResponse.json(newIncident, { status: 201 });
  }),

  http.put(`/api/incidents/:id`, async ({ params, request }) => {
    const body = (await request.json()) as any;
    const incidentIdx = mockAllIncidentsData.findIndex(i => i.id === params.id);
    
    if (incidentIdx === -1) {
      return HttpResponse.json(
        { error: 'Incident not found' },
        { status: 404 }
      );
    }
    
    const updatedIncident = { ...mockAllIncidentsData[incidentIdx], ...body };
    mockAllIncidentsData[incidentIdx] = updatedIncident;
    saveIncidentsToStorage(mockAllIncidentsData);
    return HttpResponse.json(updatedIncident);
  }),
];
