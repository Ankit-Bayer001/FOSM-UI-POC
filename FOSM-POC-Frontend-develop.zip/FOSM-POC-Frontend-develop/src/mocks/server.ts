import { setupServer } from 'msw/node';
import { handlers } from './handlers';

/**
 * This configures a request mocking server with the given request handlers.
 * Server will be started and stopped before and after each test suite.
 */
export const server = setupServer(...handlers);
