import { useEffect, useRef } from 'react'
import { useToast } from '@/components/ui/use-toast'

/**
 * Custom hook for handling initial load errors in data fetching
 * Shows error toast only once and calls onError callback
 */
export function useInitialLoadError(
  isError: boolean,
  errorMessage: string,
  onError?: () => void
) {
  const { toast } = useToast()
  const hasShownErrorRef = useRef(false)

  useEffect(() => {
    if (isError && !hasShownErrorRef.current) {
      hasShownErrorRef.current = true
      console.error(errorMessage)
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      })
      onError?.()
    }
  }, [isError, errorMessage, toast, onError])
}
