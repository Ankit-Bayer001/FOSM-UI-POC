/**
 * TanStack Query Hooks - Usage Examples
 * 
 * This file demonstrates how to use the modular API structure with TanStack Query
 * in your React components.
 */

// ============================================================================
// EXAMPLE 1: Fetching User Data
// ============================================================================

import { useUsers, useUser } from '@/hooks/queries';

export function UserListExample() {
  const { data, isLoading, error } = useUsers(1, 20);

  if (isLoading) return <div>Loading users...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <ul>
      {data?.data.map(user => (
        <li key={user.id}>{user.displayName}</li>
      ))}
    </ul>
  );
}

export function UserDetailExample({ userId }: { userId: string }) {
  const { data, isLoading, error } = useUser(userId);

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error</div>;
  if (!data) return <div>User not found</div>;

  return <div>{data.displayName} ({data.email})</div>;
}

// ============================================================================
// EXAMPLE 2: Creating/Updating Data
// ============================================================================

import { useCreateUser, useUpdateUser } from '@/hooks/queries';
import { useState } from 'react';
import { User } from '@/types';

export function CreateUserExample() {
  const [formData, setFormData] = useState<Partial<User>>({});
  const { mutate, isPending, isError, error } = useCreateUser();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    mutate(formData, {
      onSuccess: () => {
        setFormData({});
        // User list will automatically refetch due to query invalidation
      },
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        placeholder="Email"
        value={formData.email || ''}
        onChange={e => setFormData({ ...formData, email: e.target.value })}
      />
      <button disabled={isPending}>
        {isPending ? 'Creating...' : 'Create User'}
      </button>
      {isError && <p style={{ color: 'red' }}>{error?.message}</p>}
    </form>
  );
}

export function UpdateUserExample({ userId }: { userId: string }) {
  const [formData, setFormData] = useState<Partial<User>>({});
  const { mutate, isPending } = useUpdateUser();

  const handleUpdate = () => {
    mutate({ id: userId, user: formData });
  };

  return (
    <>
      <input
        value={formData.displayName || ''}
        onChange={e => setFormData({ ...formData, displayName: e.target.value })}
      />
      <button onClick={handleUpdate} disabled={isPending}>
        {isPending ? 'Updating...' : 'Update'}
      </button>
    </>
  );
}

// ============================================================================
// EXAMPLE 3: Change Management with Workflow
// ============================================================================

import { 
  useChange, 
  useApproveChange, 
  useRejectChange,
  useAddChangeComment 
} from '@/hooks/queries';

export function ChangeApprovalExample({ changeId }: { changeId: string }) {
  const { data: change, isLoading } = useChange(changeId);
  const approveMutation = useApproveChange();
  const rejectMutation = useRejectChange();
  const commentMutation = useAddChangeComment();

  if (isLoading) return <div>Loading change...</div>;
  if (!change) return <div>Change not found</div>;

  return (
    <div>
      <h2>{change.title}</h2>
      <p>Status: {change.status}</p>
      
      <button
        onClick={() => approveMutation.mutate({ id: changeId })}
        disabled={approveMutation.isPending}
      >
        Approve
      </button>

      <button
        onClick={() => rejectMutation.mutate({ 
          id: changeId, 
          comments: 'Need more info' 
        })}
        disabled={rejectMutation.isPending}
      >
        Reject
      </button>

      <input
        type="text"
        placeholder="Add a comment..."
        onBlur={e => {
          if (e.currentTarget.value) {
            commentMutation.mutate({
              id: changeId,
              content: e.currentTarget.value,
            });
            e.currentTarget.value = '';
          }
        }}
      />
    </div>
  );
}

// ============================================================================
// EXAMPLE 4: Incident Management with Filtering
// ============================================================================

import { useIncidents, useResolveIncident } from '@/hooks/queries';
import { useState } from 'react';

export function IncidentListExample() {
  const [filters, setFilters] = useState({
    status: '',
    priority: 'high',
  });

  const { data, isLoading } = useIncidents(1, 20, filters);

  return (
    <>
      <select
        value={filters.priority}
        onChange={e => setFilters({ ...filters, priority: e.target.value })}
      >
        <option value="">All</option>
        <option value="low">Low</option>
        <option value="medium">Medium</option>
        <option value="high">High</option>
      </select>

      {isLoading ? <div>Loading...</div> : (
        <ul>
          {data?.data.map(incident => (
            <li key={incident.id}>{incident.issueDescription}</li>
          ))}
        </ul>
      )}
    </>
  );
}

export function ResolveIncidentExample({ incidentId }: { incidentId: string }) {
  const resolveMutation = useResolveIncident();
  const [notes, setNotes] = useState('');

  return (
    <>
      <textarea
        placeholder="Resolution notes..."
        value={notes}
        onChange={e => setNotes(e.target.value)}
      />
      <button
        onClick={() => resolveMutation.mutate({
          id: incidentId,
          resolutionNotes: notes,
        })}
        disabled={resolveMutation.isPending}
      >
        {resolveMutation.isPending ? 'Resolving...' : 'Resolve'}
      </button>
      {resolveMutation.isError && <p>{resolveMutation.error?.message}</p>}
    </>
  );
}

// ============================================================================
// EXAMPLE 5: Groups and Roles Management
// ============================================================================

import { useGroups, useAddGroupMember, useRoles } from '@/hooks/queries';

export function GroupManagementExample() {
  const { data: groups } = useGroups();
  const { data: roles } = useRoles();
  const addMemberMutation = useAddGroupMember();

  const handleAddMember = (groupId: string, userId: string) => {
    addMemberMutation.mutate({ groupId, userId });
  };

  return (
    <div>
      <h2>Groups</h2>
      {groups?.map(group => (
        <div key={group.id}>
          <h3>{group.name}</h3>
          <p>Members: {group.members.length}</p>
        </div>
      ))}

      <h2>Roles ({roles?.length})</h2>
      <ul>
        {roles?.map(role => (
          <li key={role.id}>{role.name}</li>
        ))}
      </ul>
    </div>
  );
}

// ============================================================================
// EXAMPLE 6: Advanced - Optimistic Updates
// ============================================================================

import { useUpdateIncident } from '@/hooks/queries';
import { useQueryClient } from '@tanstack/react-query';

export function OptimisticUpdateExample({ incidentId }: { incidentId: string }) {
  const queryClient = useQueryClient();
  const updateMutation = useUpdateIncident();

  const handleQuickStatusChange = (newStatus: string) => {
    // Optimistic update - update local cache immediately
    queryClient.setQueryData(['incidents', incidentId], (oldData: any) => ({
      ...oldData,
      state: newStatus,
    }));

    // Then update on server
    updateMutation.mutate(
      { id: incidentId, incident: { state: newStatus } },
      {
        onError: () => {
          // If error, refetch to revert optimistic update
          queryClient.invalidateQueries({ queryKey: ['incidents', incidentId] });
        },
      }
    );
  };

  return (
    <div>
      <button onClick={() => handleQuickStatusChange('open')}>
        Mark as Open
      </button>
      <button onClick={() => handleQuickStatusChange('in_progress')}>
        In Progress
      </button>
    </div>
  );
}

// ============================================================================
// EXAMPLE 7: Using in Context with Multiple Hooks
// ============================================================================

import { useUsers, useCreateUser, useDeleteUser } from '@/hooks/queries';

export function UserManagementDashboard() {
  const { data, isLoading, refetch } = useUsers(1, 50);
  const createUserMutation = useCreateUser();
  const deleteUserMutation = useDeleteUser();

  return (
    <div>
      <h1>User Management</h1>

      {isLoading ? (
        <div>Loading...</div>
      ) : (
        <>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {data?.data.map(user => (
                <tr key={user.id}>
                  <td>{user.displayName}</td>
                  <td>{user.email}</td>
                  <td>
                    <button
                      onClick={() => deleteUserMutation.mutate(user.id)}
                      disabled={deleteUserMutation.isPending}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <form
            onSubmit={e => {
              e.preventDefault();
              // Create user logic
            }}
          >
            {/* Form fields */}
            <button type="submit" disabled={createUserMutation.isPending}>
              Create User
            </button>
          </form>
        </>
      )}
    </div>
  );
}

// ============================================================================
// NOTES
// ============================================================================

/**
 * KEY PATTERNS:
 * 
 * 1. Query (Read):
 *    const { data, isLoading, error } = useUsers();
 *    - Automatically caches and refetches data
 *    - Handle loading and error states
 * 
 * 2. Mutation (Create/Update/Delete):
 *    const { mutate, isPending, isError } = useCreateUser();
 *    - Call mutate() with data
 *    - Automatically invalidates related queries on success
 *    - Handle loading and error states
 * 
 * 3. Query Invalidation:
 *    - Automatically handled by mutations
 *    - Or manually: queryClient.invalidateQueries({ queryKey: ['users'] })
 * 
 * 4. Conditional Queries:
 *    - Use `enabled: !!id` to prevent queries running unnecessarily
 *    - Useful for dependent data fetching
 * 
 * 5. Error Handling:
 *    - Always check isError and error fields
 *    - Show user-friendly error messages
 *    - Consider retry strategies
 * 
 * 6. Performance:
 *    - Leverage query caching (5 minute stale time by default)
 *    - Use pagination for large datasets
 *    - Implement optimistic updates for better UX
 * 
 * @see TANSTACK_QUERY_SETUP.md for complete documentation
 */
