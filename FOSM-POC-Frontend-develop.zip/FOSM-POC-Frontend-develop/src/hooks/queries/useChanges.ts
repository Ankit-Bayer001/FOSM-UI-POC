/**
 * Changes (Change Tickets) Query Hooks
 */

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { changesApi } from '@/api';
import { ChangeTicket } from '@/types';

export const useChanges = (
  page = 1,
  pageSize = 20,
  filters?: { status?: string; priority?: string; search?: string }
) => {
  return useQuery({
    queryKey: ['changes', page, pageSize, filters],
    queryFn: () => changesApi.getAll(page, pageSize, filters),
  });
};

export const useChange = (id: string | undefined) => {
  return useQuery({
    queryKey: ['changes', id],
    queryFn: () => changesApi.getById(id!),
    enabled: !!id,
  });
};

export const useCreateChange = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (change: Partial<ChangeTicket>) => changesApi.create(change),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['changes'] });
    },
  });
};

export const useUpdateChange = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, change }: { id: string; change: Partial<ChangeTicket> }) =>
      changesApi.update(id, change),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['changes'] });
      queryClient.setQueryData(['changes', data.id], data);
    },
  });
};

export const useSubmitChangeForApproval = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) => changesApi.submitForApproval(id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['changes'] });
      queryClient.setQueryData(['changes', data.id], data);
    },
  });
};

export const useApproveChange = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, comments }: { id: string; comments?: string }) =>
      changesApi.approve(id, comments),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['changes'] });
      queryClient.setQueryData(['changes', data.id], data);
    },
  });
};

export const useRejectChange = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, comments }: { id: string; comments: string }) =>
      changesApi.reject(id, comments),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['changes'] });
      queryClient.setQueryData(['changes', data.id], data);
    },
  });
};

export const useAddChangeComment = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, content }: { id: string; content: string }) =>
      changesApi.addComment(id, content),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['changes', variables.id] });
    },
  });
};
