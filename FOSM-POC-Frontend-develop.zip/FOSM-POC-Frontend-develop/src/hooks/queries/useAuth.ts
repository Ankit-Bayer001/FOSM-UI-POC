/**
 * Authentication Query Hooks
 */

import { useMutation, useQuery } from '@tanstack/react-query';
import { authApi } from '@/api';
import { User } from '@/types';

export const useCurrentUser = () => {
  return useQuery({
    queryKey: ['auth', 'currentUser'],
    queryFn: () => authApi.getCurrentUser(),
    retry: false,
  });
};

export const useLogin = () => {
  return useMutation({
    mutationFn: ({ email, password }: { email: string; password: string }) =>
      authApi.login(email, password),
  });
};

export const useLogout = () => {
  return useMutation({
    mutationFn: () => authApi.logout(),
  });
};

export const useEntraCallback = () => {
  return useMutation({
    mutationFn: ({ code }: { code: string }) =>
      authApi.handleEntraCallback(code),
  });
};
