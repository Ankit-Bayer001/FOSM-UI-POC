/**
 * API Service Layer
 * 
 * This file provides the interface layer for connecting to your .NET backend.
 * Replace the mock implementations with actual API calls to your .NET endpoints.
 */

import { 
  User, 
  Group, 
  Role, 
  ChangeTicket, 
  ApiResponse, 
  PaginatedResponse 
} from '@/types';

// Base configuration - update with your .NET API URL
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://your-api.azurewebsites.net/api';

// Helper for making authenticated requests
async function fetchWithAuth<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = localStorage.getItem('itsm_access_token');
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
    ...options.headers,
  };

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    if (response.status === 401) {
      // Handle token expiration - redirect to login
      localStorage.removeItem('itsm_access_token');
      localStorage.removeItem('itsm_user');
      window.location.href = '/login';
    }
    throw new Error(`API Error: ${response.status}`);
  }

  return response.json();
}

// Authentication APIs
export const authApi = {
  /**
   * Login with email/password
   * In production, this should call your .NET Identity endpoint
   */
  async login(email: string, password: string): Promise<{ user: User; token: string }> {
    return fetchWithAuth('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },

  /**
   * Initiate Entra ID (Azure AD) login
   * This should redirect to your .NET backend which handles OAuth
   */
  initiateEntraLogin(): void {
    // Replace with your actual Entra login endpoint
    window.location.href = `${API_BASE_URL}/auth/entra/login?redirectUrl=${encodeURIComponent(window.location.origin)}`;
  },

  /**
   * Handle Entra ID callback
   */
  async handleEntraCallback(code: string): Promise<{ user: User; token: string }> {
    return fetchWithAuth('/auth/entra/callback', {
      method: 'POST',
      body: JSON.stringify({ code }),
    });
  },

  /**
   * Get current user from token
   */
  async getCurrentUser(): Promise<User> {
    return fetchWithAuth('/auth/me');
  },

  /**
   * Logout
   */
  async logout(): Promise<void> {
    await fetchWithAuth('/auth/logout', { method: 'POST' });
    localStorage.removeItem('itsm_access_token');
    localStorage.removeItem('itsm_user');
  },
};

// User Management APIs
export const usersApi = {
  async getAll(page = 1, pageSize = 20): Promise<PaginatedResponse<User>> {
    return fetchWithAuth(`/users?page=${page}&pageSize=${pageSize}`);
  },

  async getById(id: string): Promise<User> {
    return fetchWithAuth(`/users/${id}`);
  },

  async create(user: Partial<User>): Promise<User> {
    return fetchWithAuth('/users', {
      method: 'POST',
      body: JSON.stringify(user),
    });
  },

  async update(id: string, user: Partial<User>): Promise<User> {
    return fetchWithAuth(`/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(user),
    });
  },

  async delete(id: string): Promise<void> {
    return fetchWithAuth(`/users/${id}`, { method: 'DELETE' });
  },

  async getUserRoles(userId: string): Promise<Role[]> {
    return fetchWithAuth(`/users/${userId}/roles`);
  },

  async assignRole(userId: string, roleId: string): Promise<void> {
    return fetchWithAuth(`/users/${userId}/roles/${roleId}`, { method: 'POST' });
  },

  async removeRole(userId: string, roleId: string): Promise<void> {
    return fetchWithAuth(`/users/${userId}/roles/${roleId}`, { method: 'DELETE' });
  },
};

// Group Management APIs
export const groupsApi = {
  async getAll(): Promise<Group[]> {
    return fetchWithAuth('/groups');
  },

  async getById(id: string): Promise<Group> {
    return fetchWithAuth(`/groups/${id}`);
  },

  async create(group: Partial<Group>): Promise<Group> {
    return fetchWithAuth('/groups', {
      method: 'POST',
      body: JSON.stringify(group),
    });
  },

  async update(id: string, group: Partial<Group>): Promise<Group> {
    return fetchWithAuth(`/groups/${id}`, {
      method: 'PUT',
      body: JSON.stringify(group),
    });
  },

  async delete(id: string): Promise<void> {
    return fetchWithAuth(`/groups/${id}`, { method: 'DELETE' });
  },

  async addMember(groupId: string, userId: string): Promise<void> {
    return fetchWithAuth(`/groups/${groupId}/members/${userId}`, { method: 'POST' });
  },

  async removeMember(groupId: string, userId: string): Promise<void> {
    return fetchWithAuth(`/groups/${groupId}/members/${userId}`, { method: 'DELETE' });
  },
};

// Role Management APIs
export const rolesApi = {
  async getAll(): Promise<Role[]> {
    return fetchWithAuth('/roles');
  },

  async getById(id: string): Promise<Role> {
    return fetchWithAuth(`/roles/${id}`);
  },

  async create(role: Partial<Role>): Promise<Role> {
    return fetchWithAuth('/roles', {
      method: 'POST',
      body: JSON.stringify(role),
    });
  },

  async update(id: string, role: Partial<Role>): Promise<Role> {
    return fetchWithAuth(`/roles/${id}`, {
      method: 'PUT',
      body: JSON.stringify(role),
    });
  },

  async delete(id: string): Promise<void> {
    return fetchWithAuth(`/roles/${id}`, { method: 'DELETE' });
  },
};

// Change Ticket APIs
export const changeTicketsApi = {
  async getAll(
    page = 1, 
    pageSize = 20,
    filters?: { status?: string; priority?: string; search?: string }
  ): Promise<PaginatedResponse<ChangeTicket>> {
    const params = new URLSearchParams({
      page: page.toString(),
      pageSize: pageSize.toString(),
      ...(filters?.status && { status: filters.status }),
      ...(filters?.priority && { priority: filters.priority }),
      ...(filters?.search && { search: filters.search }),
    });
    return fetchWithAuth(`/changes?${params}`);
  },

  async getById(id: string): Promise<ChangeTicket> {
    return fetchWithAuth(`/changes/${id}`);
  },

  async create(ticket: Partial<ChangeTicket>): Promise<ChangeTicket> {
    return fetchWithAuth('/changes', {
      method: 'POST',
      body: JSON.stringify(ticket),
    });
  },

  async update(id: string, ticket: Partial<ChangeTicket>): Promise<ChangeTicket> {
    return fetchWithAuth(`/changes/${id}`, {
      method: 'PUT',
      body: JSON.stringify(ticket),
    });
  },

  async submitForApproval(id: string): Promise<ChangeTicket> {
    return fetchWithAuth(`/changes/${id}/submit`, { method: 'POST' });
  },

  async approve(id: string, comments?: string): Promise<ChangeTicket> {
    return fetchWithAuth(`/changes/${id}/approve`, {
      method: 'POST',
      body: JSON.stringify({ comments }),
    });
  },

  async reject(id: string, comments: string): Promise<ChangeTicket> {
    return fetchWithAuth(`/changes/${id}/reject`, {
      method: 'POST',
      body: JSON.stringify({ comments }),
    });
  },

  async addComment(id: string, content: string): Promise<void> {
    return fetchWithAuth(`/changes/${id}/comments`, {
      method: 'POST',
      body: JSON.stringify({ content }),
    });
  },
};
