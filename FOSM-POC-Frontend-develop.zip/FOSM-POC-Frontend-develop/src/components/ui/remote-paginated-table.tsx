import * as React from "react"
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable,
} from "@tanstack/react-table"

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"

/* ----------------------------------
   Types
---------------------------------- */

interface FetchParams<TFilters> {
  page: number
  pageSize: number
  filters: TFilters
}

interface RemotePaginatedTableProps<TData, TFilters> {
  columns: ColumnDef<TData, any>[]
  fetchData: (params: FetchParams<TFilters>) => Promise<{
    data: TData[]
    total: number
  }>
  pageSize?: number
  filters: TFilters

  /** 🔔 NEW: notify parent about total count */
  onTotalChange?: (total: number) => void
}

/* ----------------------------------
   Component
---------------------------------- */

export function RemotePaginatedTable<TData, TFilters>({
  columns,
  fetchData,
  pageSize = 10,
  filters,
  onTotalChange,
}: RemotePaginatedTableProps<TData, TFilters>) {
  const [data, setData] = React.useState<TData[]>([])
  const [page, setPage] = React.useState(1)
  const [total, setTotal] = React.useState(0)
  const [loading, setLoading] = React.useState(false)

  /* Reset page when filters change */
  React.useEffect(() => {
    setPage(1)
  }, [filters])

  /* Fetch data */
  React.useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true)
        const res = await fetchData({ page, pageSize, filters })
        setData(res.data)
        setTotal(res.total)

        /* 🔔 Notify parent */
        onTotalChange?.(res.total)
      } catch (error) {
        console.error('Failed to fetch data:', error)
        setData([])
        setTotal(0)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [page, pageSize, filters, fetchData, onTotalChange])

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    pageCount: Math.ceil(total / pageSize),
  })

  const totalPages = Math.ceil(total / pageSize)

  return (
    <div className="space-y-4">
      <div className="rounded-md border">
        <Table>
          <TableHeader className="bg-table-header border-b--table-border">
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <TableHead key={header.id}>
                    {flexRender(
                      header.column.columnDef.header,
                      header.getContext()
                    )}
                  </TableHead>
                ))}
              </TableRow>
            ))}
          </TableHeader>

          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={columns.length} className="text-center">
                  Loading...
                </TableCell>
              </TableRow>
            ) : table.getRowModel().rows.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow key={row.id}>
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={columns.length} className="text-center">
                  No results found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-end gap-2">
        <Button
          size="sm"
          variant="outline"
          onClick={() => setPage((p) => Math.max(p - 1, 1))}
          disabled={page === 1}
        >
          <ChevronLeft className="w-4 h-4 mr-1" />
          Prev
        </Button>

        <span className="text-sm text-muted-foreground">
          Page {page} of {totalPages || 1}
        </span>

        <Button
          size="sm"
          variant="outline"
          onClick={() => setPage((p) => Math.min(p + 1, totalPages))}
          disabled={page === totalPages}
        >
          Next
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      </div>
    </div>
  )
}
