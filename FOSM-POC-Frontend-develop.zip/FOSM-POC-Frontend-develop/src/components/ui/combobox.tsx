import * as React from "react"
import { ChevronsUpDown, Check, X } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"

export interface ComboboxOption<T = any> {
  value: T
  label: string
}

interface ComboboxProps<T = any> {
  options: ComboboxOption<T>[]
  value: T | null | undefined
  onChange: (value: T | null) => void
  placeholder?: string
  searchPlaceholder?: string
  emptyText?: string
  disabled?: boolean
  clearable?: boolean
}

// Deep equality comparison with object field optimization
// Check if objects have 'id' field first for faster comparison
const isEqual = (a: any, b: any): boolean => {
  if (a === b) return true
  if (a == null || b == null) return false
  if (typeof a !== 'object' || typeof b !== 'object') return false
  
  // Fast path: if both have 'id', compare that first
  if ('id' in a && 'id' in b && a.id !== b.id) return false
  
  try {
    return JSON.stringify(a) === JSON.stringify(b)
  } catch {
    return false
  }
}

export const Combobox = React.forwardRef<HTMLButtonElement, ComboboxProps>(
  ({
    options,
    value,
    onChange,
    placeholder = "Select...",
    searchPlaceholder = "Search...",
    emptyText = "No items found.",
    disabled = false,
    clearable = false,
  }, ref) => {
    const [open, setOpen] = React.useState(false)
    const [triggerWidth, setTriggerWidth] = React.useState<number>(0)
    const triggerRef = React.useRef<HTMLButtonElement>(null)
    
    // Memoize selectedLabel computation to ensure it updates properly
    const selectedLabel = React.useMemo(
      () => options.find((opt) => isEqual(opt.value, value))?.label,
      [options, value]
    )

    React.useEffect(() => {
      const updateWidth = () => {
        if (triggerRef.current) {
          setTriggerWidth(triggerRef.current.offsetWidth)
        }
      }

      updateWidth()
      window.addEventListener('resize', updateWidth)
      return () => window.removeEventListener('resize', updateWidth)
    }, [])

    return (
      <Popover open={open} onOpenChange={setOpen}>
        <div className="relative w-full">
          <PopoverTrigger asChild>
            <Button
              ref={(node) => {
                triggerRef.current = node
                if (typeof ref === 'function') {
                  ref(node)
                } else if (ref) {
                  ref.current = node
                }
              }}
              variant="outline"
              role="combobox"
              aria-expanded={open}
              className="w-full justify-between pr-10"
              disabled={disabled}
              onMouseEnter={() => {
                if (triggerRef.current) {
                  setTriggerWidth(triggerRef.current.offsetWidth)
                }
              }}
            >
              <span className="truncate flex-1">
                {selectedLabel || placeholder}
              </span>
              <ChevronsUpDown className="h-4 w-4 shrink-0 opacity-50 ml-2" />
            </Button>
          </PopoverTrigger>
          {clearable && value && !disabled && (
            <X
              className="absolute right-7 top-1/2 -translate-y-1/2 h-4 w-4 opacity-50 hover:opacity-100 cursor-pointer"
              onClick={(e) => {
                e.stopPropagation()
                onChange(null)
              }}
            />
          )}
        </div>
        <PopoverContent className="p-0" style={{ width: triggerWidth > 0 ? `${triggerWidth}px` : 'auto' }} align="start">
          <Command>
            <CommandInput placeholder={searchPlaceholder} />
            <CommandEmpty>{emptyText}</CommandEmpty>
            <CommandList>
            <CommandGroup>
                {options.map((option, index) => (
                  <CommandItem
                    key={`${option.label}-${index}`}
                    value={option.label}
                    onSelect={(currentValue) => {
                      const selectedOption = options.find(opt => opt.label === currentValue)
                      onChange(isEqual(selectedOption?.value, value) ? null : selectedOption?.value || null)
                      setOpen(false)
                    }}
                  >
                    <Check
                      className={cn(
                        "mr-2 h-4 w-4",
                        isEqual(value, option.value) ? "opacity-100" : "opacity-0"
                      )}
                    />
                    {option.label}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    )
  }
)

Combobox.displayName = "Combobox"
