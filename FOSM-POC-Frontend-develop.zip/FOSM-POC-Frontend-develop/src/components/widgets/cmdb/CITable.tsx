import { ConfigurationItem } from '@/types/cmdb';
import { CIClassBadge } from './CIClassBadge';
import { StatusBadge } from './StatusBadge';
import { formatRelativeTime } from '@/lib/cmdb';
import { ExternalLink, MoreHorizontal } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface CITableProps {
  items: ConfigurationItem[];
  onViewDetails: (ci: ConfigurationItem) => void;
  onViewRelationships: (ci: ConfigurationItem) => void;
}

export function CITable({ items, onViewDetails, onViewRelationships }: CITableProps) {
  if (items.length === 0) {
    return (
      <div className="card-elevated p-12 text-center">
        <p className="text-muted-foreground">No configuration items found</p>
        <p className="text-sm text-muted-foreground mt-1">
          Try adjusting your search or filters
        </p>
      </div>
    );
  }

  return (
    <div className="card-elevated overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50 hover:bg-muted/50">
            <TableHead className="data-table-header w-[250px]">Name</TableHead>
            <TableHead className="data-table-header">Type</TableHead>
            <TableHead className="data-table-header">Status</TableHead>
            <TableHead className="data-table-header">Environment</TableHead>
            <TableHead className="data-table-header">Source</TableHead>
            <TableHead className="data-table-header">Owner</TableHead>
            <TableHead className="data-table-header">Updated</TableHead>
            <TableHead className="data-table-header w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((item, index) => (
            <TableRow
              key={item.id}
              className="cursor-pointer hover:bg-muted/30 transition-colors"
              style={{ animationDelay: `${index * 30}ms` }}
              onClick={() => onViewDetails(item)}
            >
              <TableCell>
                <div className="flex items-center gap-3">
                  <div>
                    <p className="font-medium text-sm">{item.name}</p>
                    {item.description && (
                      <p className="text-xs text-muted-foreground truncate max-w-[200px]">
                        {item.description}
                      </p>
                    )}
                  </div>
                </div>
              </TableCell>
              <TableCell>
                <CIClassBadge ciClass={item.class} />
              </TableCell>
              <TableCell>
                <StatusBadge status={item.status} />
              </TableCell>
              <TableCell>
                <span className="text-sm capitalize">{item.environment}</span>
              </TableCell>
              <TableCell>
                <span className="text-sm text-muted-foreground">{item.source}</span>
              </TableCell>
              <TableCell>
                <span className="text-sm">{item.owner || '—'}</span>
              </TableCell>
              <TableCell>
                <span className="text-sm text-muted-foreground">
                  {formatRelativeTime(item.updatedAt)}
                </span>
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onViewDetails(item); }}>
                      View Details
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onViewRelationships(item); }}>
                      View Relationships
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={(e) => e.stopPropagation()}>
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Open in Source
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
