import { ConfigurationItem, CIRelationship } from '@/types/cmdb';
import { CIClassBadge } from './CIClassBadge';
import { StatusBadge } from './StatusBadge';
import { formatDate } from '@/lib/cmdb';
import { X, ExternalLink, GitBranch, Clock, User, MapPin, Server } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

interface CIDetailPanelProps {
  ci: ConfigurationItem;
  relationships: CIRelationship[];
  allCIs: ConfigurationItem[];
  onClose: () => void;
  onViewRelated: (ci: ConfigurationItem) => void;
}

export function CIDetailPanel({
  ci,
  relationships,
  allCIs,
  onClose,
  onViewRelated,
}: CIDetailPanelProps) {
  const incomingRelationships = relationships.filter(r => r.targetId === ci.id);
  const outgoingRelationships = relationships.filter(r => r.sourceId === ci.id);

  const getRelatedCI = (id: string) => allCIs.find(c => c.id === id);

  return (
    <div className="fixed inset-y-0 right-0 w-full max-w-md bg-card border-l shadow-lg z-50 animate-slide-in-right">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-muted/30">
        <div className="flex items-center gap-3">
          <CIClassBadge ciClass={ci.class} size="md" />
          <div>
            <h2 className="font-semibold">{ci.name}</h2>
            <p className="text-xs text-muted-foreground font-mono">{ci.id}</p>
          </div>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <ScrollArea className="h-[calc(100vh-65px)]">
        <div className="p-4 space-y-6">
          {/* Status & Environment */}
          <div className="flex items-center gap-3">
            <StatusBadge status={ci.status} size="md" />
            <span className="text-sm px-2 py-1 bg-secondary rounded capitalize">
              {ci.environment}
            </span>
          </div>

          {/* Description */}
          {ci.description && (
            <div>
              <p className="text-sm text-muted-foreground">{ci.description}</p>
            </div>
          )}

          <Separator />

          {/* Metadata */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-start gap-2">
              <User className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-xs text-muted-foreground">Owner</p>
                <p className="text-sm font-medium">{ci.owner || '—'}</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <Server className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-xs text-muted-foreground">Team</p>
                <p className="text-sm font-medium">{ci.team || '—'}</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-xs text-muted-foreground">Location</p>
                <p className="text-sm font-medium">{ci.location || '—'}</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <ExternalLink className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-xs text-muted-foreground">Source</p>
                <p className="text-sm font-medium">{ci.source}</p>
              </div>
            </div>
          </div>

          <Separator />

          {/* Attributes */}
          <div>
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <span>Attributes</span>
            </h3>
            <div className="bg-muted/50 rounded-lg p-3 space-y-2">
              {Object.entries(ci.attributes).map(([key, value]) => (
                <div key={key} className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">{key.replace(/_/g, ' ')}</span>
                  <span className="font-mono text-xs bg-background px-2 py-0.5 rounded">
                    {String(value)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Relationships */}
          <div>
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <GitBranch className="h-4 w-4" />
              <span>Relationships</span>
              <span className="text-xs text-muted-foreground font-normal">
                ({incomingRelationships.length + outgoingRelationships.length})
              </span>
            </h3>

            {outgoingRelationships.length > 0 && (
              <div className="mb-4">
                <p className="text-xs text-muted-foreground mb-2">Outgoing</p>
                <div className="space-y-2">
                  {outgoingRelationships.map(rel => {
                    const targetCI = getRelatedCI(rel.targetId);
                    if (!targetCI) return null;
                    return (
                      <button
                        key={rel.id}
                        onClick={() => onViewRelated(targetCI)}
                        className="w-full flex items-center gap-3 p-2 rounded-lg bg-muted/50 hover:bg-muted transition-colors text-left"
                      >
                        <CIClassBadge ciClass={targetCI.class} showLabel={false} />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{targetCI.name}</p>
                          <p className="text-xs text-muted-foreground capitalize">
                            {rel.type.replace(/_/g, ' ')}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {incomingRelationships.length > 0 && (
              <div>
                <p className="text-xs text-muted-foreground mb-2">Incoming</p>
                <div className="space-y-2">
                  {incomingRelationships.map(rel => {
                    const sourceCI = getRelatedCI(rel.sourceId);
                    if (!sourceCI) return null;
                    return (
                      <button
                        key={rel.id}
                        onClick={() => onViewRelated(sourceCI)}
                        className="w-full flex items-center gap-3 p-2 rounded-lg bg-muted/50 hover:bg-muted transition-colors text-left"
                      >
                        <CIClassBadge ciClass={sourceCI.class} showLabel={false} />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{sourceCI.name}</p>
                          <p className="text-xs text-muted-foreground capitalize">
                            {rel.type.replace(/_/g, ' ')}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {incomingRelationships.length === 0 && outgoingRelationships.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">
                No relationships defined
              </p>
            )}
          </div>

          <Separator />

          {/* Timestamps */}
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              <span>Created: {formatDate(ci.createdAt)}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              <span>Updated: {formatDate(ci.updatedAt)}</span>
            </div>
            {ci.lastSyncedAt && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Clock className="h-3.5 w-3.5" />
                <span>Last Sync: {formatDate(ci.lastSyncedAt)}</span>
              </div>
            )}
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}
