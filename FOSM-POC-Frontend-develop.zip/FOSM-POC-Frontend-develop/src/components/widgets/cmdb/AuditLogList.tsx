import { AuditLogEntry } from '@/types/cmdb';
import { formatDate } from '@/lib/cmdb-utils';
import {
  Plus,
  Edit,
  Trash2,
  Link,
  Unlink,
  RefreshCw,
  User,
  Bot,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface AuditLogListProps {
  entries: AuditLogEntry[];
}

export function AuditLogList({ entries }: AuditLogListProps) {
  const getActionIcon = (action: AuditLogEntry['action']) => {
    const icons = {
      create: Plus,
      update: Edit,
      delete: Trash2,
      relationship_added: Link,
      relationship_removed: Unlink,
      reconciliation: RefreshCw,
    };
    return icons[action];
  };

  const getActionColor = (action: AuditLogEntry['action']) => {
    const colors = {
      create: 'bg-green-100 text-green-600',
      update: 'bg-blue-100 text-blue-600',
      delete: 'bg-red-100 text-red-600',
      relationship_added: 'bg-purple-100 text-purple-600',
      relationship_removed: 'bg-orange-100 text-orange-600',
      reconciliation: 'bg-cyan-100 text-cyan-600',
    };
    return colors[action];
  };

  if (entries.length === 0) {
    return (
      <div className="card-elevated p-8 text-center">
        <p className="text-muted-foreground">No audit log entries</p>
      </div>
    );
  }

  return (
    <div className="card-elevated overflow-hidden">
      <div className="divide-y">
        {entries.map((entry, index) => {
          const ActionIcon = getActionIcon(entry.action);
          const actionColor = getActionColor(entry.action);
          const isSystem = entry.source === 'integration' || entry.source === 'reconciliation';

          return (
            <div
              key={entry.id}
              className="p-4 hover:bg-muted/30 transition-colors animate-fade-in"
              style={{ animationDelay: `${index * 30}ms` }}
            >
              <div className="flex items-start gap-3">
                <div className={cn('p-1.5 rounded-lg shrink-0', actionColor)}>
                  <ActionIcon className="h-4 w-4" />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-sm">{entry.ciName}</span>
                    <span className="text-xs text-muted-foreground capitalize">
                      {entry.action.replace(/_/g, ' ')}
                    </span>
                  </div>

                  {entry.changes && entry.changes.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {entry.changes.map((change, i) => (
                        <div key={i} className="text-xs flex items-center gap-2">
                          <span className="text-muted-foreground">{change.field}:</span>
                          {change.oldValue !== null && (
                            <>
                              <span className="font-mono bg-muted px-1.5 py-0.5 rounded line-through">
                                {String(change.oldValue)}
                              </span>
                              <span className="text-muted-foreground">→</span>
                            </>
                          )}
                          <span className="font-mono bg-green-50 text-green-700 px-1.5 py-0.5 rounded">
                            {String(change.newValue)}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      {isSystem ? (
                        <Bot className="h-3 w-3" />
                      ) : (
                        <User className="h-3 w-3" />
                      )}
                      <span>{entry.userName}</span>
                    </div>
                    <span>·</span>
                    <span>{formatDate(entry.timestamp)}</span>
                    <span>·</span>
                    <span className="capitalize">{entry.source}</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
