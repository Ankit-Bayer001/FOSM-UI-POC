import { cn } from '@/lib/utils';
import { CIClass } from '@/types/cmdb';
import { getCIClassIcon, getCIClassBgLight } from '@/lib/cmdb';

interface CIClassBadgeProps {
  ciClass: CIClass;
  showLabel?: boolean;
  size?: 'sm' | 'md';
  className?: string;
}

export function CIClassBadge({ ciClass, showLabel = true, size = 'sm', className }: CIClassBadgeProps) {
  const Icon = getCIClassIcon(ciClass);
  const colorClass = getCIClassBgLight(ciClass);

  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-1 text-sm',
  };

  const iconSizes = {
    sm: 12,
    md: 14,
  };

  return (
    <span
      className={cn(
        'ci-badge inline-flex items-center gap-1.5 rounded font-medium',
        colorClass,
        sizeClasses[size],
        className
      )}
    >
      <Icon size={iconSizes[size]} />
      {showLabel && <span className="capitalize">{ciClass}</span>}
    </span>
  );
}
