import { DriftAlert } from '@/types/cmdb';
import { getDriftSeverityColor, formatRelativeTime } from '@/lib/cmdb';
import { AlertTriangle, Check, Eye, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface DriftAlertCardProps {
  alert: DriftAlert;
  onAcknowledge?: () => void;
  onResolve?: () => void;
  onDismiss?: () => void;
}

export function DriftAlertCard({
  alert,
  onAcknowledge,
  onResolve,
  onDismiss,
}: DriftAlertCardProps) {
  const severityColor = getDriftSeverityColor(alert.severity);

  return (
    <div
      className={cn(
        'card-elevated p-4 animate-fade-in border-l-4',
        alert.severity === 'critical' && 'border-l-status-critical',
        alert.severity === 'high' && 'border-l-orange-500',
        alert.severity === 'medium' && 'border-l-status-warning',
        alert.severity === 'low' && 'border-l-status-info'
      )}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div
            className={cn(
              'p-1.5 rounded-lg',
              alert.severity === 'critical' && 'bg-red-100',
              alert.severity === 'high' && 'bg-orange-100',
              alert.severity === 'medium' && 'bg-amber-100',
              alert.severity === 'low' && 'bg-blue-100'
            )}
          >
            <AlertTriangle
              className={cn(
                'h-4 w-4',
                alert.severity === 'critical' && 'text-status-critical',
                alert.severity === 'high' && 'text-orange-600',
                alert.severity === 'medium' && 'text-status-warning',
                alert.severity === 'low' && 'text-status-info'
              )}
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-medium text-sm">{alert.ciName}</h4>
              <span className={cn('status-badge', severityColor)}>
                {alert.severity}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">
              <span className="font-mono">{alert.attribute}</span> mismatch from {alert.source}
            </p>
          </div>
        </div>

        {alert.status === 'open' && (
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onAcknowledge}>
              <Eye className="h-3.5 w-3.5" />
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onResolve}>
              <Check className="h-3.5 w-3.5" />
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onDismiss}>
              <X className="h-3.5 w-3.5" />
            </Button>
          </div>
        )}
      </div>

      <div className="mt-3 flex items-center gap-4 text-xs">
        <div className="flex items-center gap-2 px-2 py-1 bg-muted rounded">
          <span className="text-muted-foreground">Expected:</span>
          <span className="font-mono font-medium">{String(alert.expectedValue)}</span>
        </div>
        <div className="flex items-center gap-2 px-2 py-1 bg-red-50 rounded">
          <span className="text-muted-foreground">Actual:</span>
          <span className="font-mono font-medium text-status-critical">
            {String(alert.actualValue)}
          </span>
        </div>
      </div>

      <div className="mt-2 text-xs text-muted-foreground">
        Detected {formatRelativeTime(alert.detectedAt)}
        {alert.resolvedAt && ` · Resolved ${formatRelativeTime(alert.resolvedAt)}`}
      </div>
    </div>
  );
}
