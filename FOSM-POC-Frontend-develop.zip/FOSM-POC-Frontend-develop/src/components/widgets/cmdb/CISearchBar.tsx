import { useState } from 'react';
import { Search, X, Filter, ChevronDown } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { CIClass, CIStatus, CISearchFilters } from '@/types/cmdb';
import { cn } from '@/lib/utils';

interface CISearchBarProps {
  filters: CISearchFilters;
  onQueryChange: (query: string) => void;
  onToggleClass: (ciClass: CIClass) => void;
  onToggleStatus: (status: CIStatus) => void;
  onClearFilters: () => void;
  hasActiveFilters: boolean;
}

const ciClasses: CIClass[] = ['server', 'application', 'database', 'network', 'storage', 'service'];
const ciStatuses: CIStatus[] = ['active', 'inactive', 'maintenance', 'decommissioned', 'planned'];

export function CISearchBar({
  filters,
  onQueryChange,
  onToggleClass,
  onToggleStatus,
  onClearFilters,
  hasActiveFilters,
}: CISearchBarProps) {
  const [isFocused, setIsFocused] = useState(false);

  return (
    <div className="flex flex-col sm:flex-row gap-3">
      {/* Search Input */}
      <div className="relative flex-1">
        <Search
          className={cn(
            'absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 transition-colors',
            isFocused ? 'text-accent' : 'text-muted-foreground'
          )}
        />
        <Input
          placeholder="Search CIs by name, description, owner..."
          value={filters.query || ''}
          onChange={(e) => onQueryChange(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          className="pl-9 pr-9 h-10"
        />
        {filters.query && (
          <button
            onClick={() => onQueryChange('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Filter Dropdowns */}
      <div className="flex gap-2">
        {/* Class Filter */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="h-10 gap-2">
              <Filter className="h-4 w-4" />
              <span className="hidden sm:inline">Type</span>
              {filters.classes && filters.classes.length > 0 && (
                <span className="ml-1 px-1.5 py-0.5 text-xs bg-accent text-accent-foreground rounded">
                  {filters.classes.length}
                </span>
              )}
              <ChevronDown className="h-3 w-3 opacity-50" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuLabel>CI Types</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {ciClasses.map((ciClass) => (
              <DropdownMenuCheckboxItem
                key={ciClass}
                checked={filters.classes?.includes(ciClass) || false}
                onCheckedChange={() => onToggleClass(ciClass)}
                className="capitalize"
              >
                {ciClass}
              </DropdownMenuCheckboxItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Status Filter */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="h-10 gap-2">
              <span className="hidden sm:inline">Status</span>
              {filters.statuses && filters.statuses.length > 0 && (
                <span className="ml-1 px-1.5 py-0.5 text-xs bg-accent text-accent-foreground rounded">
                  {filters.statuses.length}
                </span>
              )}
              <ChevronDown className="h-3 w-3 opacity-50" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuLabel>Status</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {ciStatuses.map((status) => (
              <DropdownMenuCheckboxItem
                key={status}
                checked={filters.statuses?.includes(status) || false}
                onCheckedChange={() => onToggleStatus(status)}
                className="capitalize"
              >
                {status}
              </DropdownMenuCheckboxItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Clear Filters */}
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClearFilters}
            className="h-10 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4 mr-1" />
            Clear
          </Button>
        )}
      </div>
    </div>
  );
}
