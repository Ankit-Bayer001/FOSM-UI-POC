import { cn } from '@/lib/utils';
import { CIStatus } from '@/types/cmdb';
import { getStatusColor, getStatusIcon } from '@/lib/cmdb-utils';

interface StatusBadgeProps {
  status: CIStatus;
  showIcon?: boolean;
  size?: 'sm' | 'md';
  className?: string;
}

export function StatusBadge({ status, showIcon = true, size = 'sm', className }: StatusBadgeProps) {
  const Icon = getStatusIcon(status);
  const colorClass = getStatusColor(status);

  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-1 text-sm',
  };

  const iconSizes = {
    sm: 12,
    md: 14,
  };

  return (
    <span
      className={cn(
        'status-badge inline-flex items-center gap-1.5 rounded-full font-medium',
        colorClass,
        sizeClasses[size],
        className
      )}
    >
      {showIcon && <Icon size={iconSizes[size]} />}
      <span className="capitalize">{status}</span>
    </span>
  );
}
