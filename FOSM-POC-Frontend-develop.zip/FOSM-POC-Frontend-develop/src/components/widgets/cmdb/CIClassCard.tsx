import { CIClassDefinition } from '@/types/cmdb';
import { getCIClassIcon, getCIClassBgLight, formatDateShort } from '@/lib/cmdb';
import { Settings, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CIClassCardProps {
  definition: CIClassDefinition;
  onClick?: () => void;
}

export function CIClassCard({ definition, onClick }: CIClassCardProps) {
  const Icon = getCIClassIcon(definition.class);
  const colorClass = getCIClassBgLight(definition.class);

  return (
    <button
      onClick={onClick}
      className="card-elevated p-4 text-left hover:shadow-md transition-all duration-200 w-full group animate-fade-in"
    >
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-3">
          <div className={cn('p-2.5 rounded-lg', colorClass)}>
            <Icon className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-semibold text-sm">{definition.name}</h3>
            <p className="text-xs text-muted-foreground mt-0.5">
              {definition.description}
            </p>
          </div>
        </div>
        <ChevronRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>

      <div className="mt-4 pt-3 border-t">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1 text-muted-foreground">
            <Settings className="h-3 w-3" />
            <span>{definition.attributes.length} attributes</span>
          </div>
          <span className="text-muted-foreground">
            Updated {formatDateShort(definition.updatedAt)}
          </span>
        </div>

        <div className="mt-2 flex flex-wrap gap-1">
          {definition.attributes.slice(0, 4).map((attr) => (
            <span
              key={attr.name}
              className="px-1.5 py-0.5 bg-muted rounded text-[10px] font-mono"
            >
              {attr.name}
            </span>
          ))}
          {definition.attributes.length > 4 && (
            <span className="px-1.5 py-0.5 text-[10px] text-muted-foreground">
              +{definition.attributes.length - 4} more
            </span>
          )}
        </div>
      </div>
    </button>
  );
}
