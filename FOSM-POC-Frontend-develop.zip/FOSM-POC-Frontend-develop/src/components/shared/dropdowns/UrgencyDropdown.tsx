import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { urgencyBadgeClassMap } from '@/lib/ui'

interface UrgencyDropdownProps {
  value: string | null | undefined
  onChange: (value: string | null) => void
}

const URGENCY_OPTIONS = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
]

export const UrgencyDropdown = ({
  value,
  onChange,
}: UrgencyDropdownProps) => {
  return (
    <div className="flex flex-col gap-1 w-[180px]">
      <Label htmlFor="urgency">Urgency</Label>
      <Select
        value={value ?? ''}
        onValueChange={(val) => onChange(val || null)}
      >
        <SelectTrigger id="urgency">
          <SelectValue placeholder="Please Select" />
        </SelectTrigger>
        <SelectContent>
          {URGENCY_OPTIONS.map((option) => (
            <SelectItem key={option.value} value={option.value}>
              <Badge
                className={`capitalize border-none ${
                  urgencyBadgeClassMap[option.value] ??
                  'bg-gray-100 text-gray-600'
                }`}
              >
                {option.label}
              </Badge>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}
