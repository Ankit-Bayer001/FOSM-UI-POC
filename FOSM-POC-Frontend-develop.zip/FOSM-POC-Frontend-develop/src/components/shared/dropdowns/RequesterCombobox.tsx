import { useMemo } from 'react'
import { Label } from '@/components/ui/label'
import { Combobox } from '@/components/ui/combobox'
import { mockUsers } from '@/mockData'
import { getUserDisplayName } from '@/lib'

interface RequesterComboboxProps {
  value: string | null | undefined
  onChange: (value: string | null) => void
}

export const RequesterCombobox = ({
  value,
  onChange,
}: RequesterComboboxProps) => {
  // Use mock data for requesters
  const users = mockUsers

  const options = useMemo(
    () => users.map((user: any) => {
      const displayName = getUserDisplayName(user)
      return {
        value: user.id,
        label: `${displayName} <${user.email}>`,
      }
    }),
    [users]
  )

  return (
    <div className="flex flex-col gap-1 w-[260px]">
      <Label>Requester</Label>
      <Combobox
        options={options}
        value={value}
        onChange={onChange}
        placeholder="Select requester..."
        searchPlaceholder="Search requesters..."
        emptyText="No requesters found."
        disabled={false}
        clearable={true}
      />
    </div>
  )
}
