import { useEffect, useRef } from 'react'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useGroups } from '@/hooks/queries/useGroups'
import { useToast } from '@/components/ui/use-toast'

interface AssignedGroupDropdownProps {
  value: string | null | undefined
  onChange: (value: string | null) => void
}

export const AssignedGroupDropdown = ({
  value,
  onChange,
}: AssignedGroupDropdownProps) => {
  const { data: groups = [], isLoading, isError } = useGroups()
  const { toast } = useToast()
  const hasShownErrorRef = useRef(false)

  // Handle error state - log to console, show toast, and clear value (only once)
  useEffect(() => {
    if (isError && !hasShownErrorRef.current) {
      hasShownErrorRef.current = true
      console.error('Failed to load groups for AssignedGroupDropdown')
      toast({
        title: 'Error',
        description: 'Failed to load assigned groups. Please try again.',
        variant: 'destructive',
      })
      // Clear the selected value
      onChange(null)
    }
  }, [isError, toast, onChange])

  // Don't render if loading (parent should handle this)
  if (isLoading) {
    return (
      <div className="flex flex-col gap-1 w-[260px]">
        <Label htmlFor="assignedGroup">Assigned Group</Label>
        <Select disabled value="">
          <SelectTrigger id="assignedGroup">
            <SelectValue placeholder="Loading..." />
          </SelectTrigger>
        </Select>
      </div>
    )
  }

  // Don't render if error occurred (value was cleared by useEffect)
  if (isError) {
    return (
      <div className="flex flex-col gap-1 w-[260px]">
        <Label htmlFor="assignedGroup">Assigned Group</Label>
        <Select disabled value="">
          <SelectTrigger id="assignedGroup">
            <SelectValue placeholder="No groups available" />
          </SelectTrigger>
        </Select>
      </div>
    )
  }

  // Check if we have groups data
  if (!groups || groups.length === 0) {
    return (
      <div className="flex flex-col gap-1 w-[260px]">
        <Label htmlFor="assignedGroup">Assigned Group</Label>
        <Select disabled value="">
          <SelectTrigger id="assignedGroup">
            <SelectValue placeholder="No groups available" />
          </SelectTrigger>
        </Select>
      </div>
    )
  }

  // Render the dropdown with groups
  return (
    <div className="flex flex-col gap-1 w-[260px]">
      <Label htmlFor="assignedGroup">Assigned Group</Label>
      <Select
        value={value ?? ''}
        onValueChange={(val) => onChange(val || null)}
      >
        <SelectTrigger id="assignedGroup">
          <SelectValue placeholder="Select a group" />
        </SelectTrigger>
        <SelectContent>
          {groups.map((group) => (
            <SelectItem key={group.id} value={group.id}>
              {group.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}
