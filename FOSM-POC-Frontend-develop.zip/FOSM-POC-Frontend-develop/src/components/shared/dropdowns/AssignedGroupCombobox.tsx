import { useMemo } from 'react'
import { Label } from '@/components/ui/label'
import { Combobox } from '@/components/ui/combobox'
import { useGroups } from '@/hooks/queries/useGroups'
import { useInitialLoadError, normalizeComboboxValue, cn } from '@/lib'

interface AssignedGroupComboboxProps {
  value: { id: string; name: string } | string | null | undefined
  onChange: (value: { id: string; name: string } | null) => void
  className?: string
}

export const AssignedGroupCombobox = ({
  value,
  onChange,
  className,
}: AssignedGroupComboboxProps) => {
  const { data: groups = [], isLoading, isError } = useGroups()

  // Handle initial load error
  useInitialLoadError(
    isError,
    'Failed to load assigned groups. Please try again.',
    () => onChange(null)
  )

  // Normalize value: convert string ID to object for consistent comparison
  const normalizedValue = useMemo(
    () => normalizeComboboxValue(value, groups, 'id', (group) => ({
      id: group.id,
      name: group.name,
    })),
    [value, groups]
  )

  const options = useMemo(
    () => groups.map((group) => ({
      value: { id: group.id, name: group.name },
      label: group.name,
    })),
    [groups]
  )

  return (
    <div className={cn('flex flex-col gap-1 w-[260px]', className)}>
      <Label>Assigned Group</Label>
      <Combobox
        options={options}
        value={normalizedValue}
        onChange={onChange}
        placeholder="Select group..."
        searchPlaceholder="Search groups..."
        emptyText="No groups found."
        disabled={isLoading || isError}
        clearable={true}
      />
    </div>
  )
}
