import { useMemo } from 'react'
import { Label } from '@/components/ui/label'
import { Combobox } from '@/components/ui/combobox'
import { useUsers } from '@/hooks/queries/useUsers'
import { useInitialLoadError, normalizeComboboxValue, getUserDisplayName, cn } from '@/lib'

interface AssigneeComboboxProps {
  value: { id: string; display_name: string } | string | null | undefined
  onChange: (value: { id: string; display_name: string } | null) => void
  selectedGroup: { id: string; name: string } | string | null | undefined
  className?: string
}

export const AssigneeCombobox = ({
  value,
  onChange,
  selectedGroup,
  className,
}: AssigneeComboboxProps) => {
  // Extract group ID for filtering - ensure it's a string
  const selectedGroupId = typeof selectedGroup === 'object' && selectedGroup && 'id' in selectedGroup 
    ? (selectedGroup.id as string)
    : (selectedGroup as string | null | undefined)
  
  const { data: queryData, isLoading, isError } = useUsers(
    1,
    100,
    selectedGroupId ? { assignedGroups: selectedGroupId } : undefined
  )

  // Handle initial load error
  useInitialLoadError(
    isError,
    'Failed to load assignees. Please try again.',
    () => onChange(null)
  )

  const users = queryData?.data || []

  // Normalize value: convert string ID to object for consistent comparison
  const normalizedValue = useMemo(
    () => normalizeComboboxValue(value, users, 'id', (user) => ({
      id: user.id,
      display_name: getUserDisplayName(user),
    })),
    [value, users]
  )

  const options = useMemo(
    () => users.map((user: any) => {
      const displayName = getUserDisplayName(user)
      return {
        value: { id: user.id, display_name: displayName },
        label: `${displayName} <${user.email}>`,
      }
    }),
    [users]
  )

  return (
    <div className={cn('flex flex-col gap-1 w-[260px]', className)}>
      <Label>Assignee</Label>
      <Combobox
        options={options}
        value={normalizedValue}
        onChange={onChange}
        placeholder="Select assignee..."
        searchPlaceholder="Search assignees..."
        emptyText={selectedGroupId ? 'No users in selected group.' : 'No assignees found.'}
        disabled={isLoading || isError}
        clearable={true}
      />
    </div>
  )
}
