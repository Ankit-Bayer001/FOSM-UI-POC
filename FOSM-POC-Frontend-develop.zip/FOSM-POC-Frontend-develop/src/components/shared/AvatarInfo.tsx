import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card'
import { ReactNode } from 'react'
import { cn } from "@/lib/utils";

interface AvatarInfoProps {
  name: string
  initials: string
  src?: string
  children: ReactNode
  className?: string
  side?: 'top' | 'right' | 'bottom' | 'left'
  contentClassName?: string
}

export const AvatarInfo = ({ name, initials, src, children, className = 'h-8 w-8', side = 'bottom', contentClassName }: AvatarInfoProps) => {
  return (
    <HoverCard>
      <HoverCardTrigger asChild>
        <Avatar className={className} title={name}>
          {src && <AvatarImage src={src} alt={name} />}
          <AvatarFallback className="text-xs fosm__avatar">{initials}</AvatarFallback>
        </Avatar>
      </HoverCardTrigger>
      <HoverCardContent side={side} className={cn("w-80", contentClassName)}>{children}</HoverCardContent>
    </HoverCard>
  )
}
