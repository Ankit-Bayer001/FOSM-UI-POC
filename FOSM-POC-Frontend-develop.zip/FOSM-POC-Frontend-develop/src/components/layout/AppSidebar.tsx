import { Link, useLocation } from 'react-router-dom';
import logo from '../../assets/icons/bayerLogo.svg';
 
import { 
  LayoutDashboard, 
  Ticket, 
  AlertCircle,
  Users, 
  Shield, 
  UserCog,
  // Settings,
  LogOut,
  ChevronDown
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { useState } from 'react';

interface NavItem {
  label: string;
  href?: string;
  icon: React.ElementType;
  permission?: { resource: string; action: 'create' | 'read' | 'update' | 'delete' | 'approve' };
  children?: { label: string; href: string }[];
}

const navItems: NavItem[] = [
  { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { 
    label: 'Incident Management', 
    icon: AlertCircle,
    children: [
      { label: 'All Incidents', href: '/incidents' },
      { label: "Create Incident", href: "/incidents/new" },
      { label: 'My Incidents', href: '/incidents/my' },
      // { label: 'Pending Approval', href: '' },
    ],
    permission: { resource: 'change_tickets', action: 'read' },
  },
  { 
    label: 'Change Management', 
    icon: Ticket,
    children: [
      { label: 'All Changes', href: '/changes' },
      { label: 'Create Change', href: '/changes/new' },
      // { label: 'My Changes', href: '/changes/my' },
      { label: 'Pending Approval', href: '/changes/pending' },
    ],
    permission: { resource: 'change_tickets', action: 'read' },
  },

  // { 
  //   label: 'Access Control', 
  //   icon: Shield,
  //   children: [
  //     { label: 'Users', href: '/admin/users' },
  //     { label: 'Groups', href: '/admin/groups' },
  //     { label: 'Roles', href: '/admin/roles' },
  //   ],
  //   permission: { resource: 'users', action: 'read' },
  // },
  {
  label: 'CMDB',
  icon: LayoutDashboard,
  children: [
    { label: 'Dashboard', href: '/cmdb' },
    { label: 'Configuration Items', href: '/cmdb/cis' },
    { label: 'Relationships', href: '/cmdb/relationships' },
    { label: 'Integrations', href: '/cmdb/integrations' },
    { label: 'Reconciliation', href: '/cmdb/reconciliation' },
    { label: 'Drift Detection', href: '/cmdb/drift' },
    { label: 'Search', href: '/cmdb/search' },
    { label: 'Audit Log', href: '/cmdb/audit' },
    { label: 'CI Classes', href: '/cmdb/classes' },
    { label: 'Governance', href: '/cmdb/governance' },
  ],
}
];

export const AppSidebar = () => {
  const location = useLocation();
  const { user, logout, hasPermission } = useAuth();
  const [openItems, setOpenItems] = useState<string[]>(['Change Management']);

  const toggleItem = (label: string) => {
    setOpenItems(prev => 
      prev.includes(label) 
        ? prev.filter(item => item !== label)
        : [...prev, label]
    );
  };

  const isActive = (href: string) => location.pathname === href;
  const isParentActive = (children?: { href: string }[]) => 
    children?.some(child => location.pathname.startsWith(child.href));

  const filteredNavItems = navItems;

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 bg-sidebar border-r border-sidebar-border flex flex-col">
      {/* Logo */}
      <div className="flex items-center gap-3 px-6 py-5 border-b border-sidebar-border">
        <div className="w-8 h-8 rounded-lg bg-sidebar-primary flex items-center justify-center">
          {/* <logo className="w-5 h-5 text-sidebar-primary-foreground" /> */}
          <img src={logo} alt="Bayer Logo" className="w-10 h-10" />
        </div>
        <div>
          <h1 className="text-lg font-semibold text-sidebar-foreground">FOSM</h1>
          <p className="text-xs text-sidebar-foreground/60">IT Service Management</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-3 py-4">
        <ul className="space-y-1">
          {filteredNavItems.map((item) => (
            <li key={item.label}>
              {item.children ? (
                <Collapsible 
                  open={openItems.includes(item.label)}
                  onOpenChange={() => toggleItem(item.label)}
                >
                  <CollapsibleTrigger className={cn(
                    "w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                    isParentActive(item.children)
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  )}>
                    <div className="flex items-center gap-3">
                      <item.icon className="w-5 h-5" />
                      {item.label}
                    </div>
                    <ChevronDown className={cn(
                      "w-4 h-4 transition-transform",
                      openItems.includes(item.label) && "rotate-180"
                    )} />
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <ul className="mt-1 ml-4 pl-4 border-l border-sidebar-border space-y-1">
                      {item.children.map((child) => (
                        <li key={child.href}>
                          <Link
                            to={child.href}
                            className={cn(
                              "block px-3 py-2 rounded-lg text-sm transition-colors",
                              isActive(child.href)
                                ? "bg-sidebar-primary text-sidebar-primary-foreground"
                                : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                            )}
                          >
                            {child.label}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </CollapsibleContent>
                </Collapsible>
              ) : (
                <Link
                  to={item.href!}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                    isActive(item.href!)
                      ? "bg-sidebar-primary text-sidebar-primary-foreground"
                      : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </Link>
              )}
            </li>
          ))}
        </ul>
      </nav>

      {/* User Section */}
      <div className="border-t border-sidebar-border p-4">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-full bg-sidebar-accent flex items-center justify-center">
            <UserCog className="w-5 h-5 text-sidebar-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-sidebar-foreground truncate">
              {user?.displayName}
            </p>
            <p className="text-xs text-sidebar-foreground/60 truncate">
              {user?.email}
            </p>
          </div>
        </div>
        <button
          onClick={logout}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </aside>
  );
};
