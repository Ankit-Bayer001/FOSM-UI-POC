/**
 * Data Lookup and Transformation Utilities
 * Helpers for finding and transforming data from collections
 */

import type { User, Group, Role } from '@/types'
import { mockUsers, mockGroups, mockRoles, mockCategories } from '@/mockData'

/**
 * Get a user by ID from mock data
 */
export const getUserById = (id: string): User | undefined => {
  return mockUsers.find(u => u.id === id)
}

/**
 * Get a group by ID from mock data
 */
export const getGroupById = (id: string): Group | undefined => {
  return mockGroups.find(g => g.id === id)
}

/**
 * Get a role by ID from mock data
 */
export const getRoleById = (id: string): Role | undefined => {
  return mockRoles.find(r => r.id === id)
}

/**
 * Get a category name by ID from mock data
 */
export const getCategoryName = (categoryId: number): string => {
  const category = mockCategories.find(c => c.id === categoryId)
  return category ? category.name : 'Unknown'
}

/**
 * Generic function to find item by ID in any collection
 */
export function findById<T extends { id: string }>(
  collection: T[],
  id: string
): T | undefined {
  return collection.find(item => item.id === id)
}

/**
 * Generic function to find all items matching a property value
 */
export function findByProperty<T, K extends keyof T>(
  collection: T[],
  property: K,
  value: T[K]
): T[] {
  return collection.filter(item => item[property] === value)
}
