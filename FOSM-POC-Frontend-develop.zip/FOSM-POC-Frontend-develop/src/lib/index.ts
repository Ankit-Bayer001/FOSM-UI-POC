/**
 * Lib Utilities Index
 * 
 * Centralized exports for all utility functions and helpers
 * Organized by category for easy discovery and imports
 */

// ============================================================================
// UI & CSS Utilities
// ============================================================================
export { 
  cn,
  stateBadgeClassMap,
  priorityBadgeClassMap,
  urgencyBadgeClassMap
} from './ui'

// ============================================================================
// API & HTTP Utilities  
// ============================================================================
export { 
  API_BASE_URL, 
  fetchWithAuth, 
  buildQueryParams,
  handleApiResponse 
} from './api'

// ============================================================================
// Form & Combobox Utilities
// ============================================================================
export {
  normalizeComboboxValue,
  getUserDisplayName
} from './form'

// ============================================================================
// Data Lookup Utilities
// ============================================================================
export {
  getUserById,
  getGroupById,
  getRoleById,
  getCategoryName,
  findById,
  findByProperty
} from './data'

// ============================================================================
// Custom Hooks
// ============================================================================
export {
  useInitialLoadError,
  useDebounce,
  usePrevious
} from './hooks'

// ============================================================================
// Domain-Specific Utilities
// ============================================================================

// CMDB utilities - keep organized with domain context
export * from './cmdb'

// ============================================================================
// Query Client Configuration
// ============================================================================
export { queryClient } from './queryClient'
