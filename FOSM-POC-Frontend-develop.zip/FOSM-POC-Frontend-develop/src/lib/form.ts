/**
 * Form and Combobox Utilities
 * Helper functions for form handling and combobox components
 */

/**
 * Normalizes a combobox value to ensure consistent object format
 * Converts string IDs to full objects by looking up in an items array
 */
export function normalizeComboboxValue<T, R extends object>(
  value: R | string | null | undefined,
  items: T[],
  idField: keyof T,
  buildObject: (item: T) => R
): R | null {
  if (!value) return null
  
  // Already in object form
  if (typeof value === 'object' && value !== null) {
    return value
  }
  
  // String ID: find matching item and return object
  if (typeof value === 'string') {
    const matchingItem = items.find(item => (item as any)[idField] === value)
    if (matchingItem) {
      return buildObject(matchingItem)
    }
  }
  
  return null
}

/**
 * Extracts display name from user objects
 * Handles both snake_case (mock data) and camelCase (real API) property names
 */
export function getUserDisplayName(user: any): string {
  const displayName = user.display_name || user.displayName
  if (displayName) return displayName
  
  const firstName = user.first_name || user.firstName || ''
  const lastName = user.last_name || user.lastName || ''
  
  return `${firstName} ${lastName}`.trim()
}
