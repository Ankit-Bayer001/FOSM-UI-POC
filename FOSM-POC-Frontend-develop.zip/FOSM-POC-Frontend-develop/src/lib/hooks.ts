/**
 * Custom React Hook Factories and Utilities
 * Reusable hook patterns and utilities for common scenarios
 */

import { useEffect, useRef } from 'react'
import { useToast } from '@/components/ui/use-toast'

/**
 * Hook for handling initial load errors in data fetching
 * Shows error toast only once and calls onError callback
 * 
 * Prevents duplicate error messages on re-renders
 * 
 * @param isError - Boolean indicating error state
 * @param errorMessage - Message to display in toast
 * @param onError - Optional callback when error occurs
 */
export function useInitialLoadError(
  isError: boolean,
  errorMessage: string,
  onError?: () => void
) {
  const { toast } = useToast()
  const hasShownErrorRef = useRef(false)

  useEffect(() => {
    if (isError && !hasShownErrorRef.current) {
      hasShownErrorRef.current = true
      console.error(errorMessage)
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      })
      onError?.()
    }
  }, [isError, errorMessage, toast, onError])
}

/**
 * Hook for debouncing values - useful for search inputs
 */
export function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useRef(value)

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value)
    }, delay)

    return () => clearTimeout(handler)
  }, [value, delay])

  return debouncedValue.current
}

/**
 * Hook for handling previous value - useful for detecting changes
 */
export function usePrevious<T>(value: T): T | undefined {
  const ref = useRef<T>()

  useEffect(() => {
    ref.current = value
  }, [value])

  return ref.current
}
