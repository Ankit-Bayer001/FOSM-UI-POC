import { CIClass, CIStatus, RelationshipType, DriftSeverity, IntegrationStatus } from '@/types/cmdb';
import { 
  Server, 
  AppWindow, 
  Database, 
  Network, 
  HardDrive, 
  Briefcase,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Clock,
  Calendar,
  ArrowRight,
  Link2,
  Plug,
  Box
} from 'lucide-react';

export const getCIClassIcon = (ciClass: CIClass) => {
  const icons: Record<CIClass, typeof Server> = {
    server: Server,
    application: AppWindow,
    database: Database,
    network: Network,
    storage: HardDrive,
    service: Briefcase,
  };
  return icons[ciClass];
};

export const getCIClassColor = (ciClass: CIClass): string => {
  const colors: Record<CIClass, string> = {
    server: 'bg-ci-server text-white',
    application: 'bg-ci-application text-white',
    database: 'bg-ci-database text-white',
    network: 'bg-ci-network text-white',
    storage: 'bg-ci-storage text-white',
    service: 'bg-ci-service text-white',
  };
  return colors[ciClass];
};

export const getCIClassBgLight = (ciClass: CIClass): string => {
  const colors: Record<CIClass, string> = {
    server: 'bg-purple-100 text-purple-700',
    application: 'bg-blue-100 text-blue-700',
    database: 'bg-green-100 text-green-700',
    network: 'bg-amber-100 text-amber-700',
    storage: 'bg-pink-100 text-pink-700',
    service: 'bg-cyan-100 text-cyan-700',
  };
  return colors[ciClass];
};

export const getStatusColor = (status: CIStatus): string => {
  const colors: Record<CIStatus, string> = {
    active: 'status-healthy',
    inactive: 'status-critical',
    maintenance: 'status-warning',
    decommissioned: 'bg-gray-100 text-gray-600',
    planned: 'status-info',
  };
  return colors[status];
};

export const getStatusIcon = (status: CIStatus) => {
  const icons: Record<CIStatus, typeof CheckCircle> = {
    active: CheckCircle,
    inactive: XCircle,
    maintenance: AlertTriangle,
    decommissioned: Clock,
    planned: Calendar,
  };
  return icons[status];
};

export const getRelationshipLabel = (type: RelationshipType): string => {
  const labels: Record<RelationshipType, string> = {
    depends_on: 'Depends On',
    hosts: 'Hosts',
    connected_to: 'Connected To',
    part_of: 'Part Of',
    runs_on: 'Runs On',
    uses: 'Uses',
  };
  return labels[type];
};

export const getRelationshipIcon = (type: RelationshipType) => {
  const icons: Record<RelationshipType, typeof ArrowRight> = {
    depends_on: ArrowRight,
    hosts: Box,
    connected_to: Link2,
    part_of: Box,
    runs_on: Server,
    uses: Plug,
  };
  return icons[type];
};

export const getDriftSeverityColor = (severity: DriftSeverity): string => {
  const colors: Record<DriftSeverity, string> = {
    low: 'status-info',
    medium: 'status-warning',
    high: 'bg-orange-100 text-orange-700',
    critical: 'status-critical',
  };
  return colors[severity];
};

export const getIntegrationStatusColor = (status: IntegrationStatus): string => {
  const colors: Record<IntegrationStatus, string> = {
    connected: 'status-healthy',
    disconnected: 'status-critical',
    syncing: 'status-info',
    error: 'status-critical',
  };
  return colors[status];
};

export const formatDate = (date: Date): string => {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
};

export const formatDateShort = (date: Date): string => {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(date);
};

export const formatRelativeTime = (date: Date): string => {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return formatDateShort(date);
};
