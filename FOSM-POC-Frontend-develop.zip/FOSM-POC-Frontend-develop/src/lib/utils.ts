/**
 * Lib Utils - Backwards Compatibility Index
 * 
 * Re-exports commonly used utilities for backward compatibility.
 * New code should import directly from specific modules:
 * - @/lib/ui - UI utilities (cn)
 * - @/lib/api - API utilities (fetchWithAuth, etc.)
 * - @/lib/form - Form utilities (normalizeComboboxValue, etc.)
 * - @/lib/data - Data utilities (getUserById, etc.)
 * - @/lib/hooks - Custom hooks
 */

// Re-export commonly used utilities
export { 
  cn,
  stateBadgeClassMap,
  priorityBadgeClassMap,
  urgencyBadgeClassMap
} from './ui'
export { API_BASE_URL, fetchWithAuth } from './api'
export { normalizeComboboxValue, getUserDisplayName } from './form'
export { getUserById, getGroupById, getRoleById, getCategoryName, findById, findByProperty } from './data'
export { useInitialLoadError, useDebounce, usePrevious } from './hooks'

