/**
 * API and HTTP Utilities
 * Core helpers for making authenticated API requests
 */

/**
 * Base configuration - API endpoint URL
 * Can be overridden via VITE_API_BASE_URL environment variable
 */
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api'

/**
 * Makes authenticated HTTP requests with automatic token handling
 * 
 * Features:
 * - Automatically includes Authorization header with bearer token
 * - Handles token expiration (401 responses)
 * - Processes 204 No Content responses
 * - Forwards all request options
 * 
 * @param endpoint - Path relative to API_BASE_URL
 * @param options - Standard fetch RequestInit options
 * @returns Parsed JSON response or parsed response body
 */
export async function fetchWithAuth<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = localStorage.getItem('itsm_access_token')
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
    ...options.headers,
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  })

  if (!response.ok) {
    if (response.status === 401) {
      // Handle token expiration - redirect to login
      localStorage.removeItem('itsm_access_token')
      localStorage.removeItem('itsm_user')
      window.location.href = '/login'
    }
    throw new Error(`API Error: ${response.status}`)
  }

  // Handle 204 No Content responses
  if (response.status === 204) {
    return undefined as unknown as T
  }

  return response.json()
}

/**
 * Builds URLSearchParams from an object, filtering out undefined/null values
 * Useful for constructing query strings for API calls
 */
export function buildQueryParams(params?: Record<string, any>): URLSearchParams {
  const searchParams = new URLSearchParams()
  if (!params) return searchParams
  
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null) {
      searchParams.append(key, String(value))
    }
  })
  
  return searchParams
}

/**
 * Handles API responses with consistent error handling pattern
 */
export async function handleApiResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const error = await response.text()
    throw new Error(error || `API request failed with status ${response.status}`)
  }
  
  if (response.status === 204) {
    return undefined as unknown as T
  }
  
  return response.json()
}
