import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Enable MSW (Mock Service Worker) in development mode
if (import.meta.env.DEV) {
  import('@/mocks/browser').then(({ worker }) => {
    worker.start({
      onUnhandledRequest: 'warn', // Log warnings for unhandled requests
    });
  });
}

createRoot(document.getElementById("root")!).render(<App />);
