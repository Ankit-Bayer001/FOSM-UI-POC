import { useState } from "react"
import { Link } from "react-router-dom"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ColumnDef } from "@tanstack/react-table"
import { RemotePaginatedTable } from "@/components/ui/remote-paginated-table"
import { Plus, Eye, Edit } from "lucide-react"
import { useAuth } from "@/contexts/AuthContext"
import { FiltersWidget } from "@/components/widgets/CommonWidgets/FiltersWidget"

/* ----------------------------------
   Badge Color Configs
---------------------------------- */

const filledPriorityBadgeConfig: Record<string, string> = {
  low: "bg-green-100 text-green-700",
  medium: "bg-yellow-100 text-yellow-700",
  high: "bg-orange-100 text-orange-700",
  critical: "bg-red-100 text-red-700",
}

const filledStateBadgeConfig: Record<string, string> = {
  open: "bg-blue-100 text-blue-700",
  assigned: "bg-indigo-100 text-indigo-700",
  in_progress: "bg-orange-100 text-orange-700",
  resolved: "bg-green-100 text-green-700",
  closed: "bg-gray-100 text-gray-600",
}

/* ----------------------------------
   Mock Incident Data
---------------------------------- */

const mockIncidentData = [
  {
    id: "1",
    incidentNo: "INC001",
    state: "in_progress",
    caller: "John Doe",
    configurationItem: "Email Server",
    issueDescription: "Email outage",
    impact: "high",
    priority: "critical",
    assignedGroup: "IT Support",
    assignedTo: "Alex Brown",
  },
  {
    id: "2",
    incidentNo: "INC002",
    state: "assigned",
    caller: "Jane Smith",
    configurationItem: "VPN",
    issueDescription: "VPN not connecting",
    impact: "medium",
    priority: "medium",
    assignedGroup: "Network Team",
    assignedTo: "Emily White",
  },
  {
    id: "3",
    incidentNo: "INC003",
    state: "open",
    caller: "Michael Scott",
    configurationItem: "Laptop",
    issueDescription: "Blue screen",
    impact: "medium",
    priority: "high",
    assignedGroup: "Desktop Support",
    assignedTo: "Jim Halpert",
  },
  {
    id: "4",
    incidentNo: "INC004",
    state: "resolved",
    caller: "Pam Beesly",
    configurationItem: "Printer",
    issueDescription: "Printer offline",
    impact: "low",
    priority: "low",
    assignedGroup: "Facilities",
    assignedTo: "Dwight Schrute",
  },
  {
    id: "5",
    incidentNo: "INC005",
    state: "closed",
    caller: "Stanley Hudson",
    configurationItem: "HR Portal",
    issueDescription: "Login issue",
    impact: "high",
    priority: "high",
    assignedGroup: "Application Support",
    assignedTo: "Ryan Howard",
  },
]

/* ----------------------------------
   Filters Type + Initial State
---------------------------------- */

const initialFilters = {
  search: "",
  priority: "all",
  state: "all",
  caller: "",
  assignedGroup: "",
}

/* ----------------------------------
   Remote Fetch Function
---------------------------------- */

const fetchIncidents = async ({
  page,
  pageSize,
  filters,
}: {
  page: number
  pageSize: number
  filters: typeof initialFilters
}) => {
  let data = [...mockIncidentData]

  if (filters.search) {
    const q = filters.search.toLowerCase()
    data = data.filter(
      (i) =>
        i.incidentNo.toLowerCase().includes(q) ||
        i.issueDescription.toLowerCase().includes(q)
    )
  }

  if (filters.priority !== "all") {
    data = data.filter((i) => i.priority === filters.priority)
  }

  if (filters.state !== "all") {
    data = data.filter((i) => i.state === filters.state)
  }

  if (filters.caller) {
    data = data.filter((i) =>
      i.caller.toLowerCase().includes(filters.caller.toLowerCase())
    )
  }

  if (filters.assignedGroup) {
    data = data.filter((i) =>
      i.assignedGroup
        .toLowerCase()
        .includes(filters.assignedGroup.toLowerCase())
    )
  }

  const total = data.length

  return {
    data: data.slice((page - 1) * pageSize, page * pageSize),
    total,
  }
}

/* ----------------------------------
   Page Component
---------------------------------- */

export const AllIncidentsPage = () => {
  const { hasPermission } = useAuth()
  const [filters, setFilters] = useState(initialFilters)
const [totalCount, setTotalCount] = useState(0)

  const columns: ColumnDef<any>[] = [
    { accessorKey: "incidentNo", header: "Incident No" },

    {
      accessorKey: "state",
      header: "State",
      cell: ({ row }) => (
        <Badge className={`capitalize border-none ${filledStateBadgeConfig[row.original.state]}`}>
          {row.original.state.replace("_", " ")}
        </Badge>
      ),
    },

    { accessorKey: "caller", header: "Caller" },
    { accessorKey: "configurationItem", header: "Configuration Item" },
    { accessorKey: "issueDescription", header: "Issue Description" },

    {
      accessorKey: "priority",
      header: "Priority",
      cell: ({ row }) => (
        <Badge className={`capitalize border-none ${filledPriorityBadgeConfig[row.original.priority]}`}>
          {row.original.priority}
        </Badge>
      ),
    },

    { accessorKey: "assignedGroup", header: "Assigned Group" },
    { accessorKey: "assignedTo", header: "Assigned To" },

    {
      id: "action",
      header: "Action",
      cell: () => (
        <div className="flex justify-end gap-2">
          <Button size="icon" variant="ghost">
            <Eye className="w-4 h-4" />
          </Button>
          {hasPermission("change_tickets", "update") && (
            <Button size="icon" variant="ghost">
              <Edit className="w-4 h-4" />
            </Button>
          )}
        </div>
      ),
    },
  ]

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="page-header flex items-center justify-between">
        <h1 className="page-title">All Incidents</h1>

        {hasPermission("change_tickets", "create") && (
          <Button asChild>
            <Link to="">
              <Plus className="w-4 h-4 mr-2" />
              New Incident
            </Link>
          </Button>
        )}
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <FiltersWidget
            searchTerm={filters.search}
            priorityFilter={filters.priority}
            stateFilter={filters.state}
            caller={filters.caller}
            assignedGroup={filters.assignedGroup}
            onSearchChange={(v) => setFilters((p) => ({ ...p, search: v }))}
            onPriorityChange={(v) => setFilters((p) => ({ ...p, priority: v }))}
            onStateChange={(v) => setFilters((p) => ({ ...p, state: v }))}
            onCallerChange={(v) => setFilters((p) => ({ ...p, caller: v }))}
            onAssignedGroupChange={(v) =>
              setFilters((p) => ({ ...p, assignedGroup: v }))
            }
          />
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader>
<CardTitle className="text-lg">
  {totalCount} Incident{totalCount !== 1 ? "s" : ""} Found
</CardTitle>
        </CardHeader>
        <CardContent>
          <RemotePaginatedTable
            columns={columns}
            fetchData={fetchIncidents}
            pageSize={3}
            filters={filters}
              onTotalChange={setTotalCount}
          />
        </CardContent>
      </Card>
    </div>
  )
}
