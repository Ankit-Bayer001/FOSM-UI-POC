import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { mockChangeTickets, getUserById } from '@/data/mockData';
import { 
  Ticket, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Plus,
  ArrowRight,
  TrendingUp
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { ChangeStatus, ChangePriority } from '@/types';

const statusConfig: Record<ChangeStatus, { label: string; className: string }> = {
  draft: { label: 'Draft', className: 'status-draft' },
  pending_approval: { label: 'Pending', className: 'status-pending' },
  approved: { label: 'Approved', className: 'status-approved' },
  in_progress: { label: 'In Progress', className: 'status-in-progress' },
  completed: { label: 'Completed', className: 'status-completed' },
  rejected: { label: 'Rejected', className: 'status-rejected' },
  cancelled: { label: 'Cancelled', className: 'status-draft' },
};

const priorityConfig: Record<ChangePriority, string> = {
  low: 'priority-low',
  medium: 'priority-medium',
  high: 'priority-high',
  critical: 'priority-critical',
};

export const DashboardPage = () => {
  const { user, hasPermission } = useAuth();

  const stats = {
    total: mockChangeTickets.length,
    pending: mockChangeTickets.filter(t => t.status === 'pending_approval').length,
    inProgress: mockChangeTickets.filter(t => t.status === 'in_progress').length,
    completed: mockChangeTickets.filter(t => t.status === 'completed').length,
  };

  const recentChanges = mockChangeTickets.slice(0, 5);

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="page-header flex items-center justify-between">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-description">Welcome back, {user?.firstName}. Here's what's happening today.</p>
        </div>
        {hasPermission('change_tickets', 'create') && (
          <Button asChild>
            <Link to="/changes/new">
              <Plus className="w-4 h-4 mr-2" />
              New Change
            </Link>
          </Button>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Changes</p>
                <p className="text-3xl font-bold text-foreground">{stats.total}</p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Ticket className="w-6 h-6 text-primary" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-3 text-sm text-muted-foreground">
              <TrendingUp className="w-4 h-4 text-success" />
              <span className="text-success font-medium">+12%</span>
              <span>from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Approval</p>
                <p className="text-3xl font-bold text-foreground">{stats.pending}</p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-warning/10 flex items-center justify-center">
                <Clock className="w-6 h-6 text-warning" />
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-3">Awaiting CAB review</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">In Progress</p>
                <p className="text-3xl font-bold text-foreground">{stats.inProgress}</p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-accent" />
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-3">Currently being implemented</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Completed</p>
                <p className="text-3xl font-bold text-foreground">{stats.completed}</p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-success/10 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-success" />
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-3">This month</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Changes */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Recent Changes</CardTitle>
            <CardDescription>Latest change requests in the system</CardDescription>
          </div>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/changes">
              View All
              <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
          </Button>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Ticket #</th>
                  <th>Title</th>
                  <th>Requester</th>
                  <th>Priority</th>
                  <th>Status</th>
                  <th>Created</th>
                </tr>
              </thead>
              <tbody>
                {recentChanges.map((ticket) => {
                  const requester = getUserById(ticket.requesterId);
                  const status = statusConfig[ticket.status];
                  return (
                    <tr key={ticket.id}>
                      <td>
                        <Link 
                          to={`/changes/${ticket.id}`}
                          className="font-medium text-primary hover:underline"
                        >
                          {ticket.ticketNumber}
                        </Link>
                      </td>
                      <td className="max-w-xs truncate">{ticket.title}</td>
                      <td>{requester?.displayName}</td>
                      <td>
                        <span className={`font-medium capitalize ${priorityConfig[ticket.priority]}`}>
                          {ticket.priority}
                        </span>
                      </td>
                      <td>
                        <span className={`status-badge ${status.className}`}>
                          {status.label}
                        </span>
                      </td>
                      <td className="text-muted-foreground">
                        {new Date(ticket.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
