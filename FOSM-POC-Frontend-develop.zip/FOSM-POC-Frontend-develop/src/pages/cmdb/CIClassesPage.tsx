import { CMDBLayout } from '@/components/widgets/cmdb/CMDBLayout';
import { CIClassCard } from '@/components/widgets/cmdb/CIClassCard';
import { ciClassDefinitions } from '@/data/mockCmdbData';
import { Settings, Plus, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function CIClassesPage() {
  return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Settings className="h-6 w-6" />
              CI Class Definitions
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              Define CI types, attributes, and validation rules
            </p>
          </div>
          <Button disabled className="gap-2">
            <Lock className="h-4 w-4" />
            Add Class (Admin Only)
          </Button>
        </div>

        {/* Info Banner */}
        <div className="card-elevated p-4 bg-muted/30 border-l-4 border-l-accent">
          <h3 className="font-medium text-sm">CI Class Model (CI-01)</h3>
          <p className="text-sm text-muted-foreground mt-1">
            CI Classes define the types of configuration items that can be tracked in the CMDB.
            Each class has specific attributes and validation rules. Modifying class definitions
            requires administrator privileges.
          </p>
        </div>

        {/* Class Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {ciClassDefinitions.map((definition) => (
            <CIClassCard key={definition.id} definition={definition} />
          ))}
        </div>

        {/* Attribute Types Legend */}
        <div className="card-elevated p-5">
          <h3 className="font-semibold mb-4">Supported Attribute Types</h3>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
            {[
              { type: 'string', desc: 'Text values' },
              { type: 'number', desc: 'Numeric values' },
              { type: 'boolean', desc: 'True/False' },
              { type: 'date', desc: 'Date/Time' },
              { type: 'enum', desc: 'Predefined options' },
            ].map(({ type, desc }) => (
              <div key={type} className="text-center p-3 rounded-lg bg-muted/50">
                <p className="font-mono text-sm font-medium">{type}</p>
                <p className="text-xs text-muted-foreground mt-1">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
  );
}
