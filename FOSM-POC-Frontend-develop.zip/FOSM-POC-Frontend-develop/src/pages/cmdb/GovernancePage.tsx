import { CMDBLayout } from '@/components/widgets/cmdb/CMDBLayout';
import { Shield, CheckCircle, XCircle } from 'lucide-react';

export default function GovernancePage() {
  return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Shield className="h-6 w-6" />
            CMDB Governance
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Data quality rules and compliance policies
          </p>
        </div>

        <div className="grid gap-4">
          <div className="card-elevated p-4 flex items-center justify-between">
            <div>
              <h3 className="font-medium">Auto-Discovery Disabled (CI-09)</h3>
              <p className="text-sm text-muted-foreground">No automatic CI creation from network scans</p>
            </div>
            <CheckCircle className="h-5 w-5 text-status-healthy" />
          </div>
          <div className="card-elevated p-4 flex items-center justify-between">
            <div>
              <h3 className="font-medium">Integration Limit Enforced</h3>
              <p className="text-sm text-muted-foreground">Maximum 3 data sources allowed</p>
            </div>
            <CheckCircle className="h-5 w-5 text-status-healthy" />
          </div>
          <div className="card-elevated p-4 flex items-center justify-between">
            <div>
              <h3 className="font-medium">Read-Only Access for Standard Users</h3>
              <p className="text-sm text-muted-foreground">CI modifications via integrations only</p>
            </div>
            <CheckCircle className="h-5 w-5 text-status-healthy" />
          </div>
          <div className="card-elevated p-4 flex items-center justify-between">
            <div>
              <h3 className="font-medium">Audit Logging Enabled</h3>
              <p className="text-sm text-muted-foreground">All changes tracked with full history</p>
            </div>
            <CheckCircle className="h-5 w-5 text-status-healthy" />
          </div>
        </div>
      </div>
  );
}
