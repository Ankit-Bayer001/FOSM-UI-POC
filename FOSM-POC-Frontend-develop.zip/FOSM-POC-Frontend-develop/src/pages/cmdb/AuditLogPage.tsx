import { CMDBLayout } from '@/components/widgets/cmdb/CMDBLayout';
import { AuditLogList } from '@/components/widgets/cmdb/AuditLogList';
import { auditLog } from '@/data/mockCmdbData';
import { FileText, Download, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function AuditLogPage() {
  return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <FileText className="h-6 w-6" />
              CI Change Audit Log
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              Track all changes to configuration items
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        {/* Info Banner (CI-08) */}
        <div className="card-elevated p-4 bg-muted/30 border-l-4 border-l-accent">
          <h3 className="font-medium text-sm">Audit Trail Governance</h3>
          <p className="text-sm text-muted-foreground mt-1">
            All CI changes are logged with timestamp, user, and change details. This audit trail
            is immutable and retained for compliance purposes. Manual changes, integration syncs,
            and reconciliation actions are all tracked.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="card-elevated p-4 text-center">
            <p className="text-2xl font-bold">{auditLog.length}</p>
            <p className="text-sm text-muted-foreground">Total Entries</p>
          </div>
          <div className="card-elevated p-4 text-center">
            <p className="text-2xl font-bold">
              {auditLog.filter(e => e.source === 'manual').length}
            </p>
            <p className="text-sm text-muted-foreground">Manual Changes</p>
          </div>
          <div className="card-elevated p-4 text-center">
            <p className="text-2xl font-bold">
              {auditLog.filter(e => e.source === 'integration').length}
            </p>
            <p className="text-sm text-muted-foreground">Integration Syncs</p>
          </div>
          <div className="card-elevated p-4 text-center">
            <p className="text-2xl font-bold">
              {auditLog.filter(e => e.source === 'reconciliation').length}
            </p>
            <p className="text-sm text-muted-foreground">Reconciliations</p>
          </div>
        </div>

        {/* Audit Log List */}
        <AuditLogList entries={auditLog} />
      </div>
  );
}
