import { CMDBLayout } from '@/components/widgets/cmdb/CMDBLayout';
import { configurationItems, ciRelationships } from '@/data/mockCmdbData';
import { CIClassBadge } from '@/components/widgets/cmdb/CIClassBadge';
import { GitBranch, ArrowRight } from 'lucide-react';
import { getRelationshipLabel } from '@/lib/cmdb';

export default function RelationshipsPage() {
  return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <GitBranch className="h-6 w-6" />
            CI Relationships
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            View dependencies and connections between configuration items
          </p>
        </div>

        <div className="card-elevated p-4 bg-muted/30 border-l-4 border-l-accent">
          <h3 className="font-medium text-sm">Relationship Types (CI-02)</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Supported relationships: depends_on, hosts, connected_to, part_of, runs_on, uses
          </p>
        </div>

        <div className="space-y-3">
          {ciRelationships.map((rel) => {
            const source = configurationItems.find(c => c.id === rel.sourceId);
            const target = configurationItems.find(c => c.id === rel.targetId);
            if (!source || !target) return null;
            
            return (
              <div key={rel.id} className="card-elevated p-4 flex items-center gap-4">
                <div className="flex items-center gap-2 flex-1">
                  <CIClassBadge ciClass={source.class} showLabel={false} />
                  <span className="font-medium text-sm">{source.name}</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1 bg-muted rounded-full text-xs">
                  <span>{getRelationshipLabel(rel.type)}</span>
                  <ArrowRight className="h-3 w-3" />
                </div>
                <div className="flex items-center gap-2 flex-1">
                  <CIClassBadge ciClass={target.class} showLabel={false} />
                  <span className="font-medium text-sm">{target.name}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
  );
}
