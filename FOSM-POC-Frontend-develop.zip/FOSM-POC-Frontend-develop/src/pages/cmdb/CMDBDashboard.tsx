import { useState } from 'react';
import { CMDBLayout } from '@/components/widgets/cmdb/CMDBLayout';
import { MetricCard } from '@/components/widgets/cmdb/MetricCard';
import { DriftAlertCard } from '@/components/widgets/cmdb/DriftAlertCard';
import { IntegrationCard } from '@/components/widgets/cmdb/IntegrationCard';
import { ReconciliationCard } from '@/components/widgets/cmdb/ReconciliationCard';
import { AuditLogList } from '@/components/widgets/cmdb/AuditLogList';
import { CIClassBadge } from '@/components/widgets/cmdb/CIClassBadge';
import {
  cmdbMetrics,
  integrationSources,
  driftAlerts,
  duplicateCandidates,
  auditLog,
  configurationItems,
} from '@/data/mockCmdbData';
import {
  Server,
  Plug,
  GitMerge,
  AlertTriangle,
  Activity,
  TrendingUp,
  ArrowRight,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { CIClass } from '@/types/cmdb';

export default function CMDBDashboard() {
  const openDriftAlerts = driftAlerts.filter((d) => d.status === 'open');
  const pendingReconciliations = duplicateCandidates.filter((d) => d.status === 'pending');
  const recentAuditEntries = auditLog.slice(0, 5);

  const ciClassCounts: { class: CIClass; count: number }[] = [
    { class: 'server', count: cmdbMetrics.cisByClass.server },
    { class: 'application', count: cmdbMetrics.cisByClass.application },
    { class: 'database', count: cmdbMetrics.cisByClass.database },
    { class: 'network', count: cmdbMetrics.cisByClass.network },
    { class: 'storage', count: cmdbMetrics.cisByClass.storage },
    { class: 'service', count: cmdbMetrics.cisByClass.service },
  ];

  return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">CMDB Dashboard</h1>
            <p className="text-muted-foreground text-sm mt-1">
              Configuration Management Database Overview
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-100 text-green-700 text-sm">
              <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
              System Healthy
            </span>
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            title="Total CIs"
            value={cmdbMetrics.totalCIs}
            subtitle={`${cmdbMetrics.cisByStatus.active} active`}
            icon={Server}
            trend={{ value: 5, isPositive: true }}
          />
          <MetricCard
            title="Active Integrations"
            value={`${cmdbMetrics.activeIntegrations}/3`}
            subtitle="All sources connected"
            icon={Plug}
            variant="success"
          />
          <MetricCard
            title="Pending Reconciliations"
            value={cmdbMetrics.pendingReconciliations}
            subtitle="Duplicates to review"
            icon={GitMerge}
            variant={cmdbMetrics.pendingReconciliations > 0 ? 'warning' : 'default'}
          />
          <MetricCard
            title="Drift Alerts"
            value={cmdbMetrics.openDriftAlerts}
            subtitle="Open alerts"
            icon={AlertTriangle}
            variant={cmdbMetrics.openDriftAlerts > 0 ? 'danger' : 'default'}
          />
        </div>

        {/* CI Distribution */}
        <div className="card-elevated p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">CI Distribution by Type</h2>
            <Link to="/cis">
              <Button variant="ghost" size="sm" className="gap-1">
                View All <ArrowRight className="h-3.5 w-3.5" />
              </Button>
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {ciClassCounts.map(({ class: ciClass, count }) => (
              <div
                key={ciClass}
                className="p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
              >
                <div className="flex items-center justify-between mb-2">
                  <CIClassBadge ciClass={ciClass} showLabel={false} />
                  <span className="text-xl font-semibold">{count}</span>
                </div>
                <p className="text-xs text-muted-foreground capitalize">{ciClass}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Drift Alerts & Reconciliation */}
          <div className="lg:col-span-2 space-y-6">
            {/* Drift Alerts */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-status-warning" />
                  Open Drift Alerts
                  {openDriftAlerts.length > 0 && (
                    <span className="px-2 py-0.5 text-xs bg-red-100 text-red-700 rounded-full">
                      {openDriftAlerts.length}
                    </span>
                  )}
                </h2>
                <Link to="/drift">
                  <Button variant="ghost" size="sm" className="gap-1">
                    View All <ArrowRight className="h-3.5 w-3.5" />
                  </Button>
                </Link>
              </div>
              <div className="space-y-3">
                {openDriftAlerts.slice(0, 3).map((alert) => (
                  <DriftAlertCard key={alert.id} alert={alert} />
                ))}
                {openDriftAlerts.length === 0 && (
                  <div className="card-elevated p-6 text-center text-muted-foreground">
                    No open drift alerts
                  </div>
                )}
              </div>
            </div>

            {/* Reconciliation */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold flex items-center gap-2">
                  <GitMerge className="h-4 w-4 text-purple-600" />
                  Pending Reconciliations
                  {pendingReconciliations.length > 0 && (
                    <span className="px-2 py-0.5 text-xs bg-purple-100 text-purple-700 rounded-full">
                      {pendingReconciliations.length}
                    </span>
                  )}
                </h2>
                <Link to="/reconciliation">
                  <Button variant="ghost" size="sm" className="gap-1">
                    View All <ArrowRight className="h-3.5 w-3.5" />
                  </Button>
                </Link>
              </div>
              <div className="space-y-3">
                {pendingReconciliations.slice(0, 2).map((candidate) => (
                  <ReconciliationCard key={candidate.id} candidate={candidate} />
                ))}
                {pendingReconciliations.length === 0 && (
                  <div className="card-elevated p-6 text-center text-muted-foreground">
                    No pending reconciliations
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Column - Integrations & Activity */}
          <div className="space-y-6">
            {/* Integrations */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold flex items-center gap-2">
                  <Plug className="h-4 w-4" />
                  Data Sources
                </h2>
                <Link to="/integrations">
                  <Button variant="ghost" size="sm" className="gap-1">
                    Manage <ArrowRight className="h-3.5 w-3.5" />
                  </Button>
                </Link>
              </div>
              <div className="space-y-3">
                {integrationSources.map((source) => (
                  <IntegrationCard key={source.id} integration={source} />
                ))}
              </div>
            </div>

            {/* Recent Activity */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold flex items-center gap-2">
                  <Activity className="h-4 w-4" />
                  Recent Activity
                </h2>
                <Link to="/audit">
                  <Button variant="ghost" size="sm" className="gap-1">
                    View All <ArrowRight className="h-3.5 w-3.5" />
                  </Button>
                </Link>
              </div>
              <AuditLogList entries={recentAuditEntries} />
            </div>
          </div>
        </div>
      </div>
  );
}
