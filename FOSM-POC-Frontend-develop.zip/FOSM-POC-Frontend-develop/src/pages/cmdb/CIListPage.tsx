import { useState } from 'react';
import { CMDBLayout } from '@/components/widgets/cmdb/CMDBLayout';
import { CITable } from '@/components/widgets/cmdb/CITable';
import { CISearchBar } from '@/components/widgets/cmdb/CISearchBar';
import { CIDetailPanel } from '@/components/widgets/cmdb/CIDetailPanel';
import { configurationItems, ciRelationships } from '@/data/mockCmdbData';
import { useCISearch } from '@/hooks/useCISearch';
import { ConfigurationItem } from '@/types/cmdb';
import { Server, Download, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function CIListPage() {
  const [selectedCI, setSelectedCI] = useState<ConfigurationItem | null>(null);
  const {
    filters,
    filteredItems,
    updateFilter,
    clearFilters,
    toggleClassFilter,
    toggleStatusFilter,
    hasActiveFilters,
  } = useCISearch(configurationItems);

  const handleViewDetails = (ci: ConfigurationItem) => {
    setSelectedCI(ci);
  };

  const handleViewRelationships = (ci: ConfigurationItem) => {
    setSelectedCI(ci);
  };

  return (
 
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Server className="h-6 w-6" />
              Configuration Items
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              {filteredItems.length} of {configurationItems.length} CIs
              {hasActiveFilters && ' (filtered)'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        {/* Search & Filter */}
        <CISearchBar
          filters={filters}
          onQueryChange={(query) => updateFilter('query', query || undefined)}
          onToggleClass={toggleClassFilter}
          onToggleStatus={toggleStatusFilter}
          onClearFilters={clearFilters}
          hasActiveFilters={hasActiveFilters}
        />

        {/* Read-only notice */}
        <div className="flex items-center gap-2 px-3 py-2 bg-blue-50 rounded-lg text-sm text-blue-700">
          <Filter className="h-4 w-4" />
          <span>
            CI management is <strong>read-only</strong> for most roles. Changes are made via approved integrations.
          </span>
        </div>

        {/* CI Table */}
        <CITable
          items={filteredItems}
          onViewDetails={handleViewDetails}
          onViewRelationships={handleViewRelationships}
        />

        {/* Detail Panel */}
        {selectedCI && (
          <CIDetailPanel
            ci={selectedCI}
            relationships={ciRelationships}
            allCIs={configurationItems}
            onClose={() => setSelectedCI(null)}
            onViewRelated={(ci) => setSelectedCI(ci)}
          />
        )}
      </div>
  );
}
