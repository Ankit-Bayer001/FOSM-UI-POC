import { CMDBLayout } from '@/components/widgets/cmdb/CMDBLayout';
import { IntegrationCard } from '@/components/widgets/cmdb/IntegrationCard';
import { integrationSources } from '@/data/mockCmdbData';
import { Plug, Plus, AlertCircle, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function IntegrationsPage() {
  const maxIntegrations = 3;
  const currentCount = integrationSources.length;
  const canAddMore = currentCount < maxIntegrations;

  return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Plug className="h-6 w-6" />
              Data Source Integrations
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              {currentCount} of {maxIntegrations} integration slots used
            </p>
          </div>
          <Button disabled={!canAddMore} className="gap-2">
            <Plus className="h-4 w-4" />
            Add Integration
          </Button>
        </div>

        {/* Integration Limit Info (CI-04) */}
        <div className="card-elevated p-4 bg-amber-50 border-l-4 border-l-status-warning">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-status-warning shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium text-sm">Integration Limit: 3 Sources Maximum</h3>
              <p className="text-sm text-muted-foreground mt-1">
                To ensure data quality and manageable reconciliation, the CMDB supports a maximum
                of 3 data source integrations. All integrations use Azure Data Factory for ingestion.
              </p>
            </div>
          </div>
        </div>

        {/* Auto-Discovery Disabled Notice (CI-09) */}
        <div className="card-elevated p-4 bg-blue-50 border-l-4 border-l-status-info">
          <div className="flex items-start gap-3">
            <Shield className="h-5 w-5 text-status-info shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium text-sm">Auto-Discovery is Disabled</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Configuration items are only ingested from approved integration sources.
                No automatic network scanning or discovery agents are active. This ensures
                controlled data ingestion and prevents unauthorized CI creation.
              </p>
            </div>
          </div>
        </div>

        {/* Integration Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {integrationSources.map((source) => (
            <IntegrationCard key={source.id} integration={source} />
          ))}

          {/* Empty Slot */}
          {canAddMore && (
            <button
              className="card-elevated p-8 border-2 border-dashed border-border hover:border-accent hover:bg-muted/30 transition-all flex flex-col items-center justify-center gap-2 text-muted-foreground"
            >
              <Plus className="h-8 w-8" />
              <span className="text-sm font-medium">Add Data Source</span>
              <span className="text-xs">Azure, AWS, or ServiceNow</span>
            </button>
          )}
        </div>

        {/* Sync Schedule Info */}
        <div className="card-elevated p-5">
          <h3 className="font-semibold mb-4">Sync Schedule</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {integrationSources.map((source) => (
              <div key={source.id} className="p-3 rounded-lg bg-muted/50">
                <p className="font-medium text-sm">{source.name}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Syncs every 4 hours via Azure Data Factory
                </p>
                <p className="text-xs font-mono text-muted-foreground mt-2">
                  Next: {source.nextSyncAt?.toLocaleTimeString() || 'Manual only'}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
  );
}
