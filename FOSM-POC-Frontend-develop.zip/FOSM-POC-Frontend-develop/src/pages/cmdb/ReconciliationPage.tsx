import { useState } from 'react';
import { CMDBLayout } from '@/components/widgets/cmdb/CMDBLayout';
import { ReconciliationCard } from '@/components/widgets/cmdb/ReconciliationCard';
import { duplicateCandidates, reconciliationRules } from '@/data/mockCmdbData';
import { GitMerge, Settings, Sparkles, CheckCircle, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';

export default function ReconciliationPage() {
  const [candidates, setCandidates] = useState(duplicateCandidates);
  
  const pendingCount = candidates.filter(c => c.status === 'pending').length;
  const mergedCount = candidates.filter(c => c.status === 'merged').length;
  const dismissedCount = candidates.filter(c => c.status === 'dismissed').length;

  return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <GitMerge className="h-6 w-6" />
              CI Reconciliation
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              De-duplicate and merge configuration items from multiple sources
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="card-elevated p-4 text-center">
            <p className="text-2xl font-bold text-amber-600">{pendingCount}</p>
            <p className="text-sm text-muted-foreground">Pending Review</p>
          </div>
          <div className="card-elevated p-4 text-center">
            <p className="text-2xl font-bold text-green-600">{mergedCount}</p>
            <p className="text-sm text-muted-foreground">Merged</p>
          </div>
          <div className="card-elevated p-4 text-center">
            <p className="text-2xl font-bold text-gray-600">{dismissedCount}</p>
            <p className="text-sm text-muted-foreground">Dismissed</p>
          </div>
        </div>

        {/* AI Assistance Notice (CI-05) */}
        <div className="card-elevated p-4 bg-purple-50 border-l-4 border-l-purple-500">
          <div className="flex items-start gap-3">
            <Sparkles className="h-5 w-5 text-purple-600 shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium text-sm">Agent-Assisted Reconciliation</h3>
              <p className="text-sm text-muted-foreground mt-1">
                AI suggestions are provided for each duplicate candidate based on matching rules
                and historical merge decisions. Review suggestions carefully before applying.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Candidates List */}
          <div className="lg:col-span-2 space-y-4">
            <h2 className="font-semibold">Duplicate Candidates</h2>
            {candidates.filter(c => c.status === 'pending').length > 0 ? (
              <div className="space-y-4">
                {candidates
                  .filter(c => c.status === 'pending')
                  .map((candidate) => (
                    <ReconciliationCard key={candidate.id} candidate={candidate} />
                  ))}
              </div>
            ) : (
              <div className="card-elevated p-8 text-center">
                <CheckCircle className="h-12 w-12 text-status-healthy mx-auto mb-3" />
                <p className="font-medium">All duplicates resolved</p>
                <p className="text-sm text-muted-foreground mt-1">
                  No pending reconciliation tasks
                </p>
              </div>
            )}
          </div>

          {/* Matching Rules */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Matching Rules
              </h2>
            </div>

            <div className="space-y-3">
              {reconciliationRules.map((rule) => (
                <div key={rule.id} className="card-elevated p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-medium text-sm">{rule.name}</h4>
                        <span className="px-1.5 py-0.5 text-xs bg-muted rounded">
                          P{rule.priority}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        {rule.description}
                      </p>
                    </div>
                    <Switch checked={rule.enabled} />
                  </div>

                  <div className="mt-3 flex items-center gap-2 text-xs">
                    <span className="text-muted-foreground">Match on:</span>
                    {rule.matchFields.map((field) => (
                      <span
                        key={field}
                        className="px-1.5 py-0.5 bg-secondary rounded font-mono"
                      >
                        {field}
                      </span>
                    ))}
                  </div>

                  {rule.autoMerge && (
                    <div className="mt-2 flex items-center gap-1 text-xs text-green-600">
                      <CheckCircle className="h-3 w-3" />
                      Auto-merge enabled
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
  );
}
