import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { mockGroups, mockGroupRoles, mockRoles, getUserById } from '@/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { Plus, Search, Users, Edit, Shield, MoreVertical } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export const GroupsPage = () => {
  const { hasPermission } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredGroups = mockGroups.filter(group =>
    group.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    group.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getGroupRoles = (groupId: string) => {
    const roleIds = mockGroupRoles.filter(gr => gr.groupId === groupId).map(gr => gr.roleId);
    return mockRoles.filter(r => roleIds.includes(r.id));
  };

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="page-header flex items-center justify-between">
        <div>
          <h1 className="page-title">Groups</h1>
          <p className="page-description">Manage user groups and their permissions</p>
        </div>
        {hasPermission('groups', 'create') && (
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Create Group
          </Button>
        )}
      </div>

      {/* Search */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search groups..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Groups Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredGroups.map((group) => {
          const roles = getGroupRoles(group.id);
          return (
            <Card key={group.id} className="relative">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Users className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{group.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        {group.members.length} member{group.members.length !== 1 ? 's' : ''}
                      </p>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Edit className="w-4 h-4 mr-2" />
                        Edit Group
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Users className="w-4 h-4 mr-2" />
                        Manage Members
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Shield className="w-4 h-4 mr-2" />
                        Manage Roles
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">{group.description}</p>
                
                {/* Roles */}
                <div className="mb-4">
                  <p className="text-xs font-medium text-muted-foreground mb-2">Assigned Roles</p>
                  <div className="flex flex-wrap gap-1">
                    {roles.length > 0 ? (
                      roles.map(role => (
                        <Badge key={role.id} variant="secondary" className="text-xs">
                          {role.name}
                        </Badge>
                      ))
                    ) : (
                      <span className="text-xs text-muted-foreground">No roles assigned</span>
                    )}
                  </div>
                </div>

                {/* Members Preview */}
                <div>
                  <p className="text-xs font-medium text-muted-foreground mb-2">Members</p>
                  <div className="flex -space-x-2">
                    {group.members.slice(0, 5).map((memberId) => {
                      const member = getUserById(memberId);
                      return (
                        <div
                          key={memberId}
                          className="w-8 h-8 rounded-full bg-muted border-2 border-card flex items-center justify-center"
                          title={member?.displayName}
                        >
                          <span className="text-xs font-medium">
                            {member?.firstName?.[0]}{member?.lastName?.[0]}
                          </span>
                        </div>
                      );
                    })}
                    {group.members.length > 5 && (
                      <div className="w-8 h-8 rounded-full bg-primary/10 border-2 border-card flex items-center justify-center">
                        <span className="text-xs font-medium text-primary">
                          +{group.members.length - 5}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};
