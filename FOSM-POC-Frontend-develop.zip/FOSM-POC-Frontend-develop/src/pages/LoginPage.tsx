import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, AlertCircle, KeyRound } from 'lucide-react';
import logo from '../assets/icons/bayerLogo.svg';

export const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isEntraLoading, setIsEntraLoading] = useState(false);
  
  const { login, loginWithEntra } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const from = (location.state as { from?: { pathname: string } })?.from?.pathname || '/dashboard';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      await login(email, password);
      navigate(from, { replace: true });
    } catch (err) {
      setError('Invalid email or password. Try: admin@company.com');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEntraLogin = async () => {
    setError('');
    setIsEntraLoading(true);
    
    try {
      await loginWithEntra();
      navigate(from, { replace: true });
    } catch (err: any) {
      setError(err.message || 'Microsoft login failed. Please try again.');
    } finally {
      setIsEntraLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="flex items-center justify-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center">
            <img src={logo} alt="Bayer Logo" className="w-10 h-10" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">FOSM</h1>
            <p className="text-sm text-muted-foreground">IT SERVICE MANAGEMENT</p>
          </div>
        </div>

        <Card className="border-border shadow-lg">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-xl">Welcome back</CardTitle>
            <CardDescription>Sign in to access the FOSM</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Entra ID Button */}
            <Button 
              type="button"
              variant="outline" 
              className="w-full h-12 gap-3 border-border"
              onClick={handleEntraLogin}
              disabled={isEntraLoading}
            >
              {isEntraLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <svg viewBox="0 0 23 23" className="w-5 h-5" fill="none">
                    <path d="M11 0H0v11h11V0z" fill="#f25022"/>
                    <path d="M23 0H12v11h11V0z" fill="#7fba00"/>
                    <path d="M11 12H0v11h11V12z" fill="#00a4ef"/>
                    <path d="M23 12H12v11h11V12z" fill="#ffb900"/>
                  </svg>
                  Sign in with Microsoft Entra
                </>
              )}
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-border" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-card px-2 text-muted-foreground">Or continue with</span>
              </div>
            </div>

            {error && (
              <Alert variant="destructive" className="border-destructive/50">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="h-11"
                />
              </div>
              <Button type="submit" className="w-full h-11" disabled={isLoading}>
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <KeyRound className="w-4 h-4 mr-2" />
                    Sign In
                  </>
                )}
              </Button>
            </form>

            <div className="pt-4 border-t border-border">
              <p className="text-xs text-muted-foreground text-center mb-2">Demo accounts (any password):</p>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-muted/50 rounded p-2">
                  <p className="font-medium text-foreground">Admin</p>
                  <p className="text-muted-foreground">admin@company.com</p>
                </div>
                <div className="bg-muted/50 rounded p-2">
                  <p className="font-medium text-foreground">Manager</p>
                  <p className="text-muted-foreground">sarah.manager@company.com</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
