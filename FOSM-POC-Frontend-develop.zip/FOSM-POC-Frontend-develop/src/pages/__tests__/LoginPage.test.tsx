import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { BrowserRouter, useNavigate, useLocation } from 'react-router-dom';
import { LoginPage } from '@/pages/LoginPage';
import { useAuth } from '@/contexts/AuthContext';

// Mock the router
vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual('react-router-dom');
  return {
    ...actual,
    useNavigate: vi.fn(),
    useLocation: vi.fn(),
  };
});

// Mock the AuthContext
vi.mock('@/contexts/AuthContext', () => ({
  useAuth: vi.fn(),
}));

let mockNavigate: any;

// Helper function to find the submit button (Sign In button in form)
const getSubmitButton = () => {
  const buttons = screen.getAllByRole('button');
  return buttons.find(btn => {
    const text = btn.textContent || '';
    return text.includes('Sign In') && !text.includes('Microsoft');
  }) as HTMLButtonElement;
};

describe('LoginPage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockNavigate = vi.fn();
    (useNavigate as any).mockReturnValue(mockNavigate);
    (useLocation as any).mockReturnValue({
      state: null,
      pathname: '/login',
    });
  });

  describe('Rendering', () => {
    it('should render the login page with all elements', () => {
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      // Check for main elements
      expect(screen.getByText('FOSM')).toBeInTheDocument();
      expect(screen.getByText('IT SERVICE MANAGEMENT')).toBeInTheDocument();
      expect(screen.getByText('Welcome back')).toBeInTheDocument();
      expect(screen.getByText('Sign in to access the FOSM')).toBeInTheDocument();
    });

    it('should render email input field', () => {
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i);
      expect(emailInput).toBeInTheDocument();
      expect(emailInput).toHaveAttribute('type', 'email');
      expect(emailInput).toHaveAttribute('placeholder', 'you@company.com');
    });

    it('should render password input field', () => {
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const passwordInput = screen.getByLabelText(/password/i);
      expect(passwordInput).toBeInTheDocument();
      expect(passwordInput).toHaveAttribute('type', 'password');
      expect(passwordInput).toHaveAttribute('placeholder', '••••••••');
    });

    it('should render Sign In button', () => {
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const signInButton = getSubmitButton();
      expect(signInButton).toBeInTheDocument();
    });

    it('should render Microsoft Entra login button', () => {
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const entraButton = screen.getByRole('button', { name: /sign in with microsoft entra/i });
      expect(entraButton).toBeInTheDocument();
    });

    it('should render demo account information', () => {
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      expect(screen.getByText(/demo accounts/i)).toBeInTheDocument();
      expect(screen.getByText('Admin')).toBeInTheDocument();
      expect(screen.getByText('Manager')).toBeInTheDocument();
      expect(screen.getByText('admin@company.com')).toBeInTheDocument();
      expect(screen.getByText('sarah.manager@company.com')).toBeInTheDocument();
    });
  });

  describe('Form Input Handling', () => {
    it('should update email input on change', async () => {
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i) as HTMLInputElement;
      await userEvent.type(emailInput, 'test@example.com');

      expect(emailInput.value).toBe('test@example.com');
    });

    it('should update password input on change', async () => {
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const passwordInput = screen.getByLabelText(/password/i) as HTMLInputElement;
      await userEvent.type(passwordInput, 'password123');

      expect(passwordInput.value).toBe('password123');
    });

    it('should clear previous error when user starts typing', async () => {
      const mockLogin = vi.fn().mockRejectedValue(new Error('Invalid credentials'));
      (useAuth as any).mockReturnValue({
        login: mockLogin,
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      // First attempt with wrong credentials
      const emailInput = screen.getByLabelText(/email/i);
      const passwordInput = screen.getByLabelText(/password/i);
      const submitButton = getSubmitButton();

      await userEvent.type(emailInput, 'wrong@example.com');
      await userEvent.type(passwordInput, 'wrong');
      fireEvent.click(submitButton);

      // Wait for error to appear
      await waitFor(() => {
        expect(screen.getByText(/invalid email or password/i)).toBeInTheDocument();
      });

      // Clear error by typing in email field
      mockLogin.mockClear();
      mockLogin.mockResolvedValue(undefined);
      await userEvent.clear(emailInput);
      await userEvent.type(emailInput, 'correct@example.com');

      // Error should still be visible until form submission
      // (The component only clears error on form submit, not on field change)
    });
  });

  describe('Form Submission - Valid Login', () => {
    it('should call login with correct credentials', async () => {
      const mockLogin = vi.fn().mockResolvedValue(undefined);
      (useAuth as any).mockReturnValue({
        login: mockLogin,
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i);
      const passwordInput = screen.getByLabelText(/password/i);
      const submitButton = getSubmitButton();

      await userEvent.type(emailInput, 'admin@company.com');
      await userEvent.type(passwordInput, 'password123');
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(mockLogin).toHaveBeenCalledWith('admin@company.com', 'password123');
      });
    });

    it('should show loading state during login', async () => {
      const mockLogin = vi.fn(() => new Promise(resolve => setTimeout(resolve, 100)));
      (useAuth as any).mockReturnValue({
        login: mockLogin,
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i);
      const passwordInput = screen.getByLabelText(/password/i);
      const submitButton = getSubmitButton();

      await userEvent.type(emailInput, 'admin@company.com');
      await userEvent.type(passwordInput, 'password');
      fireEvent.click(submitButton);

      // Button should be disabled while loading
      await waitFor(() => {
        expect(submitButton).toBeDisabled();
      });
    });

    it('should navigate to dashboard after successful login', async () => {
      const mockLogin = vi.fn().mockResolvedValue(undefined);
      (useAuth as any).mockReturnValue({
        login: mockLogin,
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i);
      const passwordInput = screen.getByLabelText(/password/i);
      const submitButton = getSubmitButton();

      await userEvent.type(emailInput, 'admin@company.com');
      await userEvent.type(passwordInput, 'password');
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(mockNavigate).toHaveBeenCalledWith('/dashboard', { replace: true });
      });
    });

    it('should navigate to redirected path after successful login', async () => {
      const mockLogin = vi.fn().mockResolvedValue(undefined);
      (useAuth as any).mockReturnValue({
        login: mockLogin,
        loginWithEntra: vi.fn(),
      });

      // Override useLocation mock for this test
      (useLocation as any).mockReturnValue({
        state: { from: { pathname: '/admin/users' } },
        pathname: '/login',
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i);
      const passwordInput = screen.getByLabelText(/password/i);
      const submitButton = getSubmitButton();

      await userEvent.type(emailInput, 'admin@company.com');
      await userEvent.type(passwordInput, 'password');
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(mockNavigate).toHaveBeenCalledWith('/admin/users', { replace: true });
      });
    });
  });

  describe('Form Submission - Invalid Login', () => {
    it('should display error message on failed login', async () => {
      const mockLogin = vi.fn().mockRejectedValue(new Error('Invalid credentials'));
      (useAuth as any).mockReturnValue({
        login: mockLogin,
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i);
      const passwordInput = screen.getByLabelText(/password/i);
      const submitButton = getSubmitButton();

      await userEvent.type(emailInput, 'wrong@example.com');
      await userEvent.type(passwordInput, 'wrongpassword');
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(screen.getByText(/invalid email or password/i)).toBeInTheDocument();
      });
    });

    it('should not navigate on failed login', async () => {
      const mockLogin = vi.fn().mockRejectedValue(new Error('Invalid credentials'));
      (useAuth as any).mockReturnValue({
        login: mockLogin,
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i);
      const passwordInput = screen.getByLabelText(/password/i);
      const submitButton = getSubmitButton();

      await userEvent.type(emailInput, 'wrong@example.com');
      await userEvent.type(passwordInput, 'wrongpassword');
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(screen.getByText(/invalid email or password/i)).toBeInTheDocument();
      });

      expect(mockNavigate).not.toHaveBeenCalled();
    });

    it('should keep form fields populated after failed login', async () => {
      const mockLogin = vi.fn().mockRejectedValue(new Error('Invalid credentials'));
      (useAuth as any).mockReturnValue({
        login: mockLogin,
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i) as HTMLInputElement;
      const passwordInput = screen.getByLabelText(/password/i) as HTMLInputElement;
      const submitButton = getSubmitButton();

      await userEvent.type(emailInput, 'test@example.com');
      await userEvent.type(passwordInput, 'password123');
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(screen.getByText(/invalid email or password/i)).toBeInTheDocument();
      });

      // Form fields should still contain the values
      expect(emailInput.value).toBe('test@example.com');
      expect(passwordInput.value).toBe('password123');
    });

    it('should disable submit button during failed login attempt', async () => {
      const mockLogin = vi.fn(() => new Promise(resolve => setTimeout(resolve, 100)));
      (useAuth as any).mockReturnValue({
        login: mockLogin,
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i);
      const passwordInput = screen.getByLabelText(/password/i);
      const submitButton = getSubmitButton();

      await userEvent.type(emailInput, 'test@example.com');
      await userEvent.type(passwordInput, 'password');
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(submitButton).toBeDisabled();
      });
    });
  });

  describe('Microsoft Entra Login', () => {
    it('should call loginWithEntra when Entra button is clicked', async () => {
      const mockLoginWithEntra = vi.fn().mockResolvedValue(undefined);
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: mockLoginWithEntra,
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const entraButton = screen.getByRole('button', { name: /sign in with microsoft entra/i });
      fireEvent.click(entraButton);

      await waitFor(() => {
        expect(mockLoginWithEntra).toHaveBeenCalled();
      });
    });

    it('should show loading state during Entra login', async () => {
      const mockLoginWithEntra = vi.fn(() => new Promise(resolve => setTimeout(resolve, 100)));
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: mockLoginWithEntra,
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const entraButton = screen.getByRole('button', { name: /sign in with microsoft entra/i });
      fireEvent.click(entraButton);

      await waitFor(() => {
        expect(entraButton).toBeDisabled();
      });
    });

    it('should navigate to dashboard after successful Entra login', async () => {
      const mockLoginWithEntra = vi.fn().mockResolvedValue(undefined);
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: mockLoginWithEntra,
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const entraButton = screen.getByRole('button', { name: /sign in with microsoft entra/i });
      fireEvent.click(entraButton);

      await waitFor(() => {
        expect(mockNavigate).toHaveBeenCalledWith('/dashboard', { replace: true });
      });
    });

    it('should display error message on failed Entra login', async () => {
      const mockLoginWithEntra = vi.fn().mockRejectedValue(new Error('Microsoft login failed'));
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: mockLoginWithEntra,
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const entraButton = screen.getByRole('button', { name: /sign in with microsoft entra/i });
      fireEvent.click(entraButton);

      await waitFor(() => {
        expect(screen.getByText(/microsoft login failed/i)).toBeInTheDocument();
      });
    });

    it('should not navigate on failed Entra login', async () => {
      const mockLoginWithEntra = vi.fn().mockRejectedValue(new Error('Microsoft login failed'));
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: mockLoginWithEntra,
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const entraButton = screen.getByRole('button', { name: /sign in with microsoft entra/i });
      fireEvent.click(entraButton);

      await waitFor(() => {
        expect(screen.getByText(/microsoft login failed/i)).toBeInTheDocument();
      });

      expect(mockNavigate).not.toHaveBeenCalled();
    });
  });

  describe('Form Validation', () => {
    it('should require email field', async () => {
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i) as HTMLInputElement;
      expect(emailInput.required).toBe(true);
    });

    it('should require password field', async () => {
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const passwordInput = screen.getByLabelText(/password/i) as HTMLInputElement;
      expect(passwordInput.required).toBe(true);
    });

    it('should validate email format', async () => {
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i) as HTMLInputElement;
      expect(emailInput.type).toBe('email');
    });
  });

  describe('Error Handling', () => {
    it('should clear error state when form is submitted again', async () => {
      const mockLogin = vi.fn()
        .mockRejectedValueOnce(new Error('Invalid credentials'))
        .mockResolvedValueOnce(undefined);

      (useAuth as any).mockReturnValue({
        login: mockLogin,
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i);
      const passwordInput = screen.getByLabelText(/password/i);
      const submitButton = getSubmitButton();

      // First failed attempt
      await userEvent.type(emailInput, 'wrong@example.com');
      await userEvent.type(passwordInput, 'wrong');
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(screen.getByText(/invalid email or password/i)).toBeInTheDocument();
      });

      // Second successful attempt
      await userEvent.clear(emailInput);
      await userEvent.clear(passwordInput);
      await userEvent.type(emailInput, 'correct@example.com');
      await userEvent.type(passwordInput, 'correct');
      fireEvent.click(submitButton);

      // Error message should disappear and navigation should happen
      await waitFor(() => {
        expect(mockNavigate).toHaveBeenCalled();
      });
    });

    it('should handle generic login error', async () => {
      const mockLogin = vi.fn().mockRejectedValue(new Error('Network error'));
      (useAuth as any).mockReturnValue({
        login: mockLogin,
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      const emailInput = screen.getByLabelText(/email/i);
      const passwordInput = screen.getByLabelText(/password/i);
      const submitButton = getSubmitButton();

      await userEvent.type(emailInput, 'test@example.com');
      await userEvent.type(passwordInput, 'password');
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(screen.getByText(/invalid email or password/i)).toBeInTheDocument();
      });
    });
  });

  describe('Accessibility', () => {
    it('should have proper labels for form inputs', () => {
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      expect(screen.getByLabelText(/email/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/password/i)).toBeInTheDocument();
    });

    it('should have descriptive button text', () => {
      (useAuth as any).mockReturnValue({
        login: vi.fn(),
        loginWithEntra: vi.fn(),
      });

      render(
        <BrowserRouter>
          <LoginPage />
        </BrowserRouter>
      );

      expect(getSubmitButton()).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /sign in with microsoft entra/i })).toBeInTheDocument();
    });
  });
});
