/**
 * Users API Module
 */

import { User, Role, PaginatedResponse } from '@/types';
import { fetchWithAuth } from '@/lib/api';

export const usersApi = {
  async getAll(page = 1, pageSize = 20, filters?: { assignedGroups?: string }): Promise<PaginatedResponse<User>> {
    let url = `/users?page=${page}&pageSize=${pageSize}`;
    if (filters?.assignedGroups) {
      url += `&assignedGroups=${filters.assignedGroups}`;
    }
    return fetchWithAuth(url);
  },

  async getById(id: string): Promise<User> {
    return fetchWithAuth(`/users/${id}`);
  },

  async create(user: Partial<User>): Promise<User> {
    return fetchWithAuth('/users', {
      method: 'POST',
      body: JSON.stringify(user),
    });
  },

  async update(id: string, user: Partial<User>): Promise<User> {
    return fetchWithAuth(`/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(user),
    });
  },

  async delete(id: string): Promise<void> {
    return fetchWithAuth(`/users/${id}`, { method: 'DELETE' });
  },

  async getUserRoles(userId: string): Promise<Role[]> {
    return fetchWithAuth(`/users/${userId}/roles`);
  },

  async assignRole(userId: string, roleId: string): Promise<void> {
    return fetchWithAuth(`/users/${userId}/roles/${roleId}`, { method: 'POST' });
  },

  async removeRole(userId: string, roleId: string): Promise<void> {
    return fetchWithAuth(`/users/${userId}/roles/${roleId}`, { method: 'DELETE' });
  },
};
