/**
 * Groups API Module
 */

import { Group } from '@/types';
import { fetchWithAuth } from '@/lib/api';

export const groupsApi = {
  async getAll(): Promise<Group[]> {
    return fetchWithAuth('/groups');
  },

  async getById(id: string): Promise<Group> {
    return fetchWithAuth(`/groups/${id}`);
  },

  async create(group: Partial<Group>): Promise<Group> {
    return fetchWithAuth('/groups', {
      method: 'POST',
      body: JSON.stringify(group),
    });
  },

  async update(id: string, group: Partial<Group>): Promise<Group> {
    return fetchWithAuth(`/groups/${id}`, {
      method: 'PUT',
      body: JSON.stringify(group),
    });
  },

  async delete(id: string): Promise<void> {
    return fetchWithAuth(`/groups/${id}`, { method: 'DELETE' });
  },

  async addMember(groupId: string, userId: string): Promise<void> {
    return fetchWithAuth(`/groups/${groupId}/members/${userId}`, { method: 'POST' });
  },

  async removeMember(groupId: string, userId: string): Promise<void> {
    return fetchWithAuth(`/groups/${groupId}/members/${userId}`, { method: 'DELETE' });
  },
};
