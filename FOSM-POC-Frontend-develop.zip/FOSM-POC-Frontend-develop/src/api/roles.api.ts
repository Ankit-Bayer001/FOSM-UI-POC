/**
 * Roles API Module
 */

import { Role } from '@/types';
import { fetchWithAuth } from '@/lib/api';

export const rolesApi = {
  async getAll(): Promise<Role[]> {
    return fetchWithAuth('/roles');
  },

  async getById(id: string): Promise<Role> {
    return fetchWithAuth(`/roles/${id}`);
  },

  async create(role: Partial<Role>): Promise<Role> {
    return fetchWithAuth('/roles', {
      method: 'POST',
      body: JSON.stringify(role),
    });
  },

  async update(id: string, role: Partial<Role>): Promise<Role> {
    return fetchWithAuth(`/roles/${id}`, {
      method: 'PUT',
      body: JSON.stringify(role),
    });
  },

  async delete(id: string): Promise<void> {
    return fetchWithAuth(`/roles/${id}`, { method: 'DELETE' });
  },
};
