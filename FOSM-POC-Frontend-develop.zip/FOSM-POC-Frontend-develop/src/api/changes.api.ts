/**
 * Changes (Change Tickets) API Module
 */

import { ChangeTicket, PaginatedResponse } from '@/types';
import { fetchWithAuth } from '@/lib/api';

export const changesApi = {
  async getAll(
    page = 1,
    pageSize = 20,
    filters?: { status?: string; priority?: string; search?: string }
  ): Promise<PaginatedResponse<ChangeTicket>> {
    const params = new URLSearchParams({
      page: page.toString(),
      pageSize: pageSize.toString(),
      ...(filters?.status && { status: filters.status }),
      ...(filters?.priority && { priority: filters.priority }),
      ...(filters?.search && { search: filters.search }),
    });
    return fetchWithAuth(`/changes?${params}`);
  },

  async getById(id: string): Promise<ChangeTicket> {
    return fetchWithAuth(`/changes/${id}`);
  },

  async create(ticket: Partial<ChangeTicket>): Promise<ChangeTicket> {
    return fetchWithAuth('/changes', {
      method: 'POST',
      body: JSON.stringify(ticket),
    });
  },

  async update(id: string, ticket: Partial<ChangeTicket>): Promise<ChangeTicket> {
    return fetchWithAuth(`/changes/${id}`, {
      method: 'PUT',
      body: JSON.stringify(ticket),
    });
  },

  async submitForApproval(id: string): Promise<ChangeTicket> {
    return fetchWithAuth(`/changes/${id}/submit`, { method: 'POST' });
  },

  async approve(id: string, comments?: string): Promise<ChangeTicket> {
    return fetchWithAuth(`/changes/${id}/approve`, {
      method: 'POST',
      body: JSON.stringify({ comments }),
    });
  },

  async reject(id: string, comments: string): Promise<ChangeTicket> {
    return fetchWithAuth(`/changes/${id}/reject`, {
      method: 'POST',
      body: JSON.stringify({ comments }),
    });
  },

  async addComment(id: string, content: string): Promise<void> {
    return fetchWithAuth(`/changes/${id}/comments`, {
      method: 'POST',
      body: JSON.stringify({ content }),
    });
  },
};
