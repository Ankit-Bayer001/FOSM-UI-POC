/**
 * Authentication API Module
 */

import { User } from '@/types';
import { fetchWithAuth, API_BASE_URL } from '@/lib/api';

export const authApi = {
  /**
   * Login with email/password
   */
  async login(email: string, password: string): Promise<{ user: User; token: string }> {
    return fetchWithAuth('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },

  /**
   * Initiate Entra ID (Azure AD) login
   */
  initiateEntraLogin(): void {
    window.location.href = `${API_BASE_URL}/auth/entra/login?redirectUrl=${encodeURIComponent(window.location.origin)}`;
  },

  /**
   * Handle Entra ID callback
   */
  async handleEntraCallback(code: string): Promise<{ user: User; token: string }> {
    return fetchWithAuth('/auth/entra/callback', {
      method: 'POST',
      body: JSON.stringify({ code }),
    });
  },

  /**
   * Get current user from token
   */
  async getCurrentUser(): Promise<User> {
    return fetchWithAuth('/auth/me');
  },

  /**
   * Logout
   */
  async logout(): Promise<void> {
    await fetchWithAuth('/auth/logout', { method: 'POST' });
    localStorage.removeItem('itsm_access_token');
    localStorage.removeItem('itsm_user');
  },
};
