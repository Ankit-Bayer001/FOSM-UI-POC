import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { User, Role, Permission, AuthContextType } from '@/types';
import { mockUsers, mockRoles, mockUserRoles } from '@/mockData';
import { useMsal } from '@azure/msal-react';
import { loginRequest } from '@/config/authConfig';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userRoles, setUserRoles] = useState<Role[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { instance, accounts, inProgress } = useMsal();

  const userPermissions = userRoles.flatMap(role => role.permissions);

  useEffect(() => {
    const checkSession = async () => {
      if (inProgress !== "none") {
        return;
      }

      if (accounts.length > 0) {
        const entraAccount = accounts[0];
        await loadUserFromEntra(entraAccount);
      } else {
        const storedUser = localStorage.getItem('itsm_user');
        if (storedUser) {
          try {
            const parsedUser = JSON.parse(storedUser);
            setUser(parsedUser);
            loadUserRoles(parsedUser.id);
          } catch (e) {
            localStorage.removeItem('itsm_user');
          }
        }
      }
      setIsLoading(false);
    };

    checkSession();
  }, [accounts, inProgress]);

  const loadUserFromEntra = async (entraAccount: any) => {
    console.log('Loading user from Entra:', entraAccount);
    const email = entraAccount.username;
    
    let foundUser = mockUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    
    if (!foundUser) {
      foundUser = {
        id: entraAccount.localAccountId,
        email: entraAccount.username,
        firstName: entraAccount.name?.split(' ')[0] || '',
        lastName: entraAccount.name?.split(' ').slice(1).join(' ') || '',
        displayName: entraAccount.name || entraAccount.username,
        isActive: true,
        createdAt: new Date().toISOString(),
      };
    }

    setUser(foundUser);
    loadUserRoles(foundUser.id);
    localStorage.setItem('itsm_user', JSON.stringify(foundUser));
  };

  const loadUserRoles = (userId: string) => {
    const userRoleAssignments = mockUserRoles.filter(ur => ur.userId === userId);
    const roles = mockRoles.filter(r => 
      userRoleAssignments.some(ur => ur.roleId === r.id)
    );
    setUserRoles(roles);
  };

  const loginWithEntra = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await instance.loginPopup(loginRequest);
      console.log("Entra Response:", response);
      await loadUserFromEntra(response.account);
    } catch (error) {
      console.error('Entra login failed:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, [instance]);

  const login = useCallback(async (email: string, password: string) => {
    setIsLoading(true);
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const foundUser = mockUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    
    if (!foundUser) {
      setIsLoading(false);
      throw new Error('Invalid credentials');
    }

    setUser(foundUser);
    loadUserRoles(foundUser.id);
    localStorage.setItem('itsm_user', JSON.stringify(foundUser));
    setIsLoading(false);
  }, []);

  const logout = useCallback(async () => {
    console.log('Logging out...');
    
    // Clear local state first
    setUser(null);
    setUserRoles([]);
    localStorage.removeItem('itsm_user');
    
    if (accounts.length > 0) {
      try {
        await instance.logoutRedirect({
          postLogoutRedirectUri: window.location.origin + "/login",
        });
      } catch (error) {
        console.error('Entra logout failed:', error);
        window.location.href = "/login";
      }
    } else {
      window.location.href = "/login";
    }
  }, [instance, accounts]);

  const hasPermission = useCallback((resource: string, action: Permission['action']): boolean => {
    return userPermissions.some(
      p => p.resource === resource && p.action === action
    );
  }, [userPermissions]);

  const hasRole = useCallback((roleName: string): boolean => {
    return userRoles.some(r => r.name.toLowerCase() === roleName.toLowerCase());
  }, [userRoles]);

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    userRoles,
    userPermissions,
    login,
    loginWithEntra,
    logout,
    hasPermission,
    hasRole,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};