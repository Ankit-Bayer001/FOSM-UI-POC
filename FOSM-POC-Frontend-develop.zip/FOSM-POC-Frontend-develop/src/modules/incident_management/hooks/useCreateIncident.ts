import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { incidentsApi } from '@/modules/incident_management/services/incidents.api';
import type { Incident, CreateIncidentFormValues } from '@/types';

export const useCreateIncident = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleFormSubmit = async (formValues: CreateIncidentFormValues) => {
    try {
      setIsSubmitting(true);

      // Generate incident ID
      const incidentId = `${Date.now()}`;
      const incidentNumber =
        formValues.number ||
        `INC${String(Math.floor(Math.random() * 1000000)).padStart(6, '0')}`;

      // Map form data to Incident interface
      const incidentData: Partial<Incident> = {
        id: incidentId,
        incidentNumber,
        title: formValues.shortDescription,
        description: formValues.description,
        priority: formValues.priority || 'P3',
        status: 1, // New status
        category: 0,
        reportedBy: 'current-user-id',
        reportedByName: formValues.caller?.split('(')[0].trim() || 'User',
        assignedTo: formValues.assignedTo || null,
        assignedToName: formValues.assignedToName || null,
        assignedGroup: formValues.assignedGroups || '',
        assignedGroupName: formValues.assignedGroupName || '',
        configurationItemName: formValues.configurationItem || '',
        impact: formValues.impact || 'Medium',
        urgency: formValues.urgency || 'Medium',
        createdDate: new Date().toISOString(),
        resolvedDate: null,
        closedDate: null,
        resolution: null,
      };

      // Call API to create incident
      await incidentsApi.create(incidentData);

      toast({
        title: 'Success',
        description: `Incident ${incidentNumber} created successfully`,
        variant: 'success',
      });

      // Navigate back to incidents list
      navigate('/incidents');
    } catch (error) {
      console.error('Error creating incident:', error);
      toast({
        title: 'Error',
        description: 'Failed to create incident. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    isSubmitting,
    handleFormSubmit,
  };
};
