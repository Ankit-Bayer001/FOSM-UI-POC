/**
 * Incidents Query Hooks
 */

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { incidentsApi } from '../services/incidents.api';
import { Incident } from '@/types';

export const useIncidents = (
  page = 1,
  pageSize = 20,
  filters?: { 
    status?: string; 
    priority?: string; 
    search?: string;
    reportedBy?: string;
    assignedGroup?: string;
    assignedTo?: string;
    userId?: string;
  }
) => {
  return useQuery({
    queryKey: ['incidents', page, pageSize, filters],
    queryFn: () => incidentsApi.getAll(page, pageSize, filters),
    staleTime: 30 * 1000, // 30 seconds
    gcTime: 60 * 1000, // 1 minute
  });
};

export const useIncident = (id: string | undefined) => {
  return useQuery({
    queryKey: ['incidents', id],
    queryFn: () => incidentsApi.getById(id!),
    enabled: !!id,
    staleTime: 30 * 1000, // 30 seconds
    gcTime: 60 * 1000, // 1 minute
  });
};

export const useCreateIncident = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (incident: Partial<Incident>) => incidentsApi.create(incident),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['incidents'] });
    },
  });
};

export const useUpdateIncident = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, incident }: { id: string; incident: Partial<Incident> }) =>
      incidentsApi.update(id, incident),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['incidents'] });
      queryClient.setQueryData(['incidents', data.id], data);
    },
  });
};

export const useResolveIncident = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, resolutionNotes }: { id: string; resolutionNotes: string }) =>
      incidentsApi.resolve(id, resolutionNotes),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['incidents'] });
      queryClient.setQueryData(['incidents', data.id], data);
    },
  });
};

export const useReassignIncident = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, assignedTo }: { id: string; assignedTo: string }) =>
      incidentsApi.reassign(id, assignedTo),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['incidents'] });
      queryClient.setQueryData(['incidents', data.id], data);
    },
  });
};

export const useAddIncidentComment = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, content }: { id: string; content: string }) =>
      incidentsApi.addComment(id, content),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['incidents', variables.id] });
    },
  });
};
