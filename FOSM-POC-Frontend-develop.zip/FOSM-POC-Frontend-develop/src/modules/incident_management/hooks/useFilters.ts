import { useState, useCallback } from 'react'
import { IncidentFilters } from '@/types/incidents'

const DEFAULT_FILTERS: IncidentFilters = {
  search: null,
  priority: null,
  status: null,
  assignedGroup: null,
  assignedTo: null,
  reportedBy: null,
}

export function useFilters(initialFilters?: Partial<IncidentFilters>) {
  const [filters, setFiltersState] = useState<IncidentFilters>({
    ...DEFAULT_FILTERS,
    ...initialFilters,
  })

  const setFilters = useCallback((newFilters: Partial<IncidentFilters>) => {
    setFiltersState((prev) => ({ ...prev, ...newFilters }))
  }, [])

  const resetFilters = useCallback(() => {
    setFiltersState(DEFAULT_FILTERS)
  }, [])

  const hasActiveFilters = useCallback(() => {
    return Object.entries(filters).some(([, value]) => {
      // Check if value is not null and not empty string
      return value !== null && value !== ''
    })
  }, [filters])

  return {
    filters,
    setFilters,
    resetFilters,
    hasActiveFilters: hasActiveFilters(),
  }
}
