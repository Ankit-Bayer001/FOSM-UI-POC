import { useState, useMemo } from "react";
import { ColumnDef } from "@tanstack/react-table";
import { Badge } from "@/components/ui/badge";
import { AvatarInfo } from "@/components/shared/AvatarInfo";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import { Link } from "react-router-dom";
import { Eye, Edit, User } from "lucide-react";
import { useIncidents } from "./useIncidents";
import { useAuth } from "@/contexts/AuthContext";
import { IncidentFilters, Incident } from "@/types/incidents";

import {
  getStatusLabel,
  getStatusColor,
  getPriorityLabel,
  getPriorityColor,
} from "../constants";

// All available columns definition
const getAllColumns = (): ColumnDef<Incident>[] => [
  {
  accessorKey: "incidentNumber",
  header: "Incident Number",
  size: 120,
  cell: ({ row }) => (
    <Link
      to={`/incidents/${row.original.id}`}
      className="text-primary font-medium hover:underline"
    >
      {row.original.incidentNumber}
    </Link>
  ),
},

  {
    accessorKey: "status",
    header: "State",
    size: 100,
    cell: ({ row }) => (
      <Badge
        className={
          "capitalize border-none " + getStatusColor(row.original.status)
        }
      >
        {getStatusLabel(row.original.status)}
      </Badge>
    ),
  },
  {
    accessorKey: "reportedByName",
    header: "Reported By",
    size: 120,
  },
  {
    accessorKey: "configurationItemName",
    header: "Configuration Item",
    size: 140,
  },
  {
    accessorKey: "title",
    header: "Issue Description",
    size: 160,
    cell: ({ row }) => (
      <HoverCard>
        <HoverCardTrigger asChild>
          <div
            className="w-[240px] truncate overflow-hidden cursor-pointer"
            title={row.original.title}
          >
            {row.original.title}
          </div>
        </HoverCardTrigger>
        <HoverCardContent className="w-80" align="center">
          <p className="text-sm text-gray-700">{row.original.title}</p>
        </HoverCardContent>
      </HoverCard>
    ),
  },
  {
    accessorKey: "priority",
    header: "Priority",
    size: 100,
    cell: ({ row }) => (
      <Badge
        className={
          "capitalize border-none " + getPriorityColor(row.original.priority)
        }
      >
        {getPriorityLabel(row.original.priority)}
      </Badge>
    ),
  },
  {
    accessorKey: "assignedGroupName",
    header: "Assigned Group",
    size: 130,
  },
  {
    accessorKey: "assignedToName",
    header: "Assigned To",
    size: 80,
    cell: ({ row }) => {
      const name = row.original.assignedToName;
      if (!name) {
        return (
          <div
            className="flex items-center justify-center text-xs text-gray-400"
            title="Unassigned"
          >
            -
          </div>
        );
      }
      const initials = name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase();
      return (
        <div className="flex items-center justify-center">
          <AvatarInfo
            side="right"
            name={name}
            initials={initials}
            className="h-8 w-8"
            contentClassName="w-50"
          >
            <div className="text-center flex gap-2 items-center">
              <User className="size-4" />
              <p className="font-normal text-sm">{name}</p>
            </div>
          </AvatarInfo>
        </div>
      );
    },
  },
  {
    accessorKey: "createdDate",
    header: "Created Date",
    size: 120,
    cell: ({ row }) => {
      const date = new Date(row.original.createdDate);
      return date.toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "2-digit",
      });
    },
  },
  {
    id: "actions",
    header: "Actions",
    size: 80,
    cell: ({ row }) => (
      <div className="flex justify-center items-center">
        <Link
          to={`/incidents/${row.original.id}`}
          title="View"
          className="hover:text-primary"
        >
          <Eye className="w-4 h-4" />
        </Link>
      </div>
    ),
  },
];

interface UseIncidentTableOptions {
  pageSize?: number;
  myIncidentsOnly?: boolean;
  hiddenColumns?: string[];
}

export function useIncidentTable(
  filters: IncidentFilters,
  options: UseIncidentTableOptions = {},
) {
  const { user } = useAuth();
  const {
    pageSize: initialPageSize = 5,
    myIncidentsOnly = false,
    hiddenColumns = [],
  } = options;
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(initialPageSize);

  // Reset page to 1 when page size changes
  const handlePageSizeChange = (newPageSize: number) => {
    setPageSize(newPageSize);
    setPage(1);
  };

  // Convert IncidentFilters to API filters format
  const apiFilters = useMemo(
    () => ({
      status: filters.status ? String(filters.status) : undefined,
      priority: filters.priority,
      search: filters.search,
      reportedBy: filters.reportedBy,
      assignedGroup: myIncidentsOnly ? undefined : filters.assignedGroup,
      assignedTo: myIncidentsOnly ? undefined : filters.assignedTo,
      userId: undefined,
    }),
    [
      filters.status,
      filters.priority,
      filters.search,
      filters.reportedBy,
      filters.assignedGroup,
      filters.assignedTo,
      myIncidentsOnly,
      user?.id,
    ],
  );

  // Use React Query hook
  const { data, isLoading, error } = useIncidents(page, pageSize, apiFilters);

  // Filter columns based on hiddenColumns
  const columns = useMemo(() => {
    const allColumns = getAllColumns();
    if (hiddenColumns.length === 0) return allColumns;
    return allColumns.filter((col) => {
      const colKey = "accessorKey" in col ? col.accessorKey : col.id;
      return !hiddenColumns.includes(colKey as string);
    });
  }, [hiddenColumns]);

  return {
    data: data?.data || [],
    total: data?.total || 0,
    page,
    setPage,
    pageSize,
    setPageSize: handlePageSizeChange,
    loading: isLoading,
    error: error?.message || null,
    columns,
  };
}
