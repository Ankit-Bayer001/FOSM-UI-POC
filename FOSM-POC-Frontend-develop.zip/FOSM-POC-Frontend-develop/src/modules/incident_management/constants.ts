/**
 * Incident Management Constants
 * Single source of truth for status and priority configurations
 */

// Status Configuration - array of objects with all metadata
export const STATUS_CONFIG = [
  { value: 1, label: 'Open', class: 'bg-blue-100 text-blue-800' },
  { value: 2, label: 'In Progress', class: 'bg-yellow-100 text-yellow-800' },
  { value: 3, label: 'Resolved', class: 'bg-green-100 text-green-800' },
  { value: 4, label: 'Closed', class: 'bg-gray-100 text-gray-800' },
] as const

// Dropdown options for Status - direct reference to STATUS_CONFIG
export const STATUS_OPTIONS = STATUS_CONFIG.map(({ value, label }) => ({
  value: String(value),
  label,
})) as const

// Priority Configuration - array of objects with all metadata
export const PRIORITY_CONFIG = [
  { value: 'P1', label: 'P1 - Critical', class: 'bg-red-100 text-red-800' },
  { value: 'P2', label: 'P2 - High', class: 'bg-orange-100 text-orange-800' },
  { value: 'P3', label: 'P3 - Medium', class: 'bg-amber-100 text-amber-800' },
  { value: 'P4', label: 'P4 - Low', class: 'bg-lime-100 text-lime-800' },
  { value: 'P5', label: 'P5 - Very Low', class: 'bg-green-100 text-green-700' },
] as const

// Dropdown options for Priority - direct reference to PRIORITY_CONFIG
export const PRIORITY_OPTIONS = PRIORITY_CONFIG.map(({ value, label }) => ({
  value,
  label,
})) as const

/**
 * Helper functions
 */

export function getStatusLabel(status: number): string {
  return STATUS_CONFIG.find(item => item.value === status)?.label || 'Unknown'
}

export function getStatusColor(status: number): string {
  return STATUS_CONFIG.find(item => item.value === status)?.class || 'bg-gray-100 text-gray-600'
}

export function getPriorityLabel(priority: string): string {
  return PRIORITY_CONFIG.find(item => item.value === priority)?.label || priority
}

export function getPriorityColor(priority: string): string {
  return PRIORITY_CONFIG.find(item => item.value === priority)?.class || 'bg-gray-100 text-gray-600'
}
