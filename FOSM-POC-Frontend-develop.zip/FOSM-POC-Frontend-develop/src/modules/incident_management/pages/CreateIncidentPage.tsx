import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AddIncidentForm, AddIncidentFormEndUser } from "@/modules/incident_management/components/forms";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useCreateIncident } from "@/modules/incident_management/hooks/useCreateIncident";

type UserType = "itil" | "enduser";

const AddIncidentPage = () => {
  const [userType, setUserType] = useState<UserType>("itil");
  const { isSubmitting, handleFormSubmit } = useCreateIncident();

  return (
    <div className="p-6 mx-auto">
      <div className="animate-fade-in">
        {/* Header */}
        <div className="page-header flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Link
              to="/incidents"
              className="rounded-md p-2 hover:bg-muted transition"
              aria-label="Back to incidents"
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>

            <div>
              <h1 className="page-title">Add Incident</h1>
              <p className="page-description">
                Create and submit a new incident ticket
              </p>
            </div>
          </div>

          {/* User Type Dropdown */}
          <Select
            value={userType}
            onValueChange={(value) => setUserType(value as UserType)}
          >
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Select user type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="itil">ITIL User</SelectItem>
              <SelectItem value="enduser">End User</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Conditional Form Rendering */}
      {userType === "itil" ? (
        <AddIncidentForm onSubmit={handleFormSubmit} isSubmitting={isSubmitting} />
      ) : (
        <AddIncidentFormEndUser />
      )}
    </div>
  );
};

export default AddIncidentPage;
