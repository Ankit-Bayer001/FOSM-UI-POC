import { Link } from "react-router-dom"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { useAuth } from "@/contexts/AuthContext"
import { SimplePaginatedTable } from "@/components/shared/paginated-table/SimplePaginatedTable"
import { IncidentFilterBox } from "../components/filters"
import { useFilters } from "../hooks/useFilters"
import { useIncidentTable } from "../hooks/useIncidentTable"

/* ----------------------------------
   Page Component
---------------------------------- */

export const MyIncidentsPage = () => {
  
  const { filters, setFilters, resetFilters, hasActiveFilters } = useFilters()
  
  // Get data, columns, and pagination from hook
  const { data, total, page, setPage, pageSize, setPageSize, loading, error, columns } = useIncidentTable({...filters, reportedBy : '1949dfba-ae2c-40da-b852-d530407f2f75'}, {
    pageSize: 5,
    hiddenColumns: ['reportedByName', 'category', 'actions', 'assignedToName', 'assignedGroupName', 'priority'], // Hide these columns
  })

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="page-header flex items-center justify-between">
        <h1 className="page-title">My Incidents</h1>
          <Button asChild>
            <Link to="/incidents/new">
              <Plus className="w-4 h-4 mr-2" />
              New Incident
            </Link>
          </Button>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <IncidentFilterBox
            filters={filters}
            onChange={setFilters}
            onReset={resetFilters}
            hasActiveFilters={hasActiveFilters}
            hiddenFields={['assignedGroup', 'priority', 'reportedBy', 'assignedTo']}

          />
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">
            {total} Incident{total !== 1 ? "s" : ""} Found
          </CardTitle>
        </CardHeader>
        <CardContent>
          <SimplePaginatedTable
            columns={columns}
            data={data}
            total={total}
            page={page}
            onPageChange={setPage}
            pageSize={pageSize}
            onPageSizeChange={setPageSize}
            loading={loading}
            error={error}
          />
        </CardContent>
      </Card>
    </div>
  )
}
