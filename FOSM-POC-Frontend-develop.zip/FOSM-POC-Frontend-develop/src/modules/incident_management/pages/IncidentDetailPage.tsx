import { useParams, useNavigate, Link } from "react-router-dom";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";

import {
  ArrowLeft,
  Edit,
  User,
  Calendar,
  AlertTriangle,
  MessageSquare,
  History,
  Loader2,
} from "lucide-react";

import { useIncident, useAddIncidentComment } from "../hooks/useIncidents";
/* ---------------- BADGES ---------------- */

const statusConfig: any = {
  1: { label: "open", className: "bg-blue-100 text-blue-700" },
  2: { label: "assigned", className: "bg-indigo-100 text-indigo-700" },
  3: { label: "in_progress", className: "bg-orange-100 text-orange-700" },
  4: { label: "resolved", className: "bg-green-100 text-green-700" },
  5: { label: "closed", className: "bg-gray-100 text-gray-600" },
};

const priorityConfig: any = {
  P1: "bg-red-100 text-red-700",
  P2: "bg-orange-100 text-orange-700",
  P3: "bg-yellow-100 text-yellow-700",
  P4: "bg-green-100 text-green-700",
};

const impactConfig: any = {
  High: "bg-red-100 text-red-700",
  Medium: "bg-yellow-100 text-yellow-700",
  Low: "bg-green-100 text-green-700",
};

const urgencyConfig: any = {
  High: "bg-red-100 text-red-700",
  Medium: "bg-yellow-100 text-yellow-700",
  Low: "bg-green-100 text-green-700",
};

/* ---------------- PAGE ---------------- */

export const IncidentDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [comment, setComment] = useState("");

  const { data: incident, isLoading, error } = useIncident(id);

  const addCommentMutation = useAddIncidentComment();

  const handleAddComment = () => {
    if (!comment.trim() || !id) return;

    addCommentMutation.mutate(
      { id, content: comment },
      {
        onSuccess: () => {
          setComment("");
        },
      },
    );
  };

  // Format date
  const formatDate = (dateString: string | null) => {
    if (!dateString) return "N/A";
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-10 min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="flex justify-center p-10">
        <Alert variant="destructive" className="max-w-md">
          <AlertDescription>
            Failed to load incident details. Please try again.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Not found state
  if (!incident) {
    return (
      <div className="flex justify-center p-10">
        <p className="text-muted-foreground">Incident not found</p>
      </div>
    );
  }

  const statusInfo = statusConfig[incident.status] || {
    label: "unknown",
    className: "bg-gray-100 text-gray-600",
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* HEADER */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4" />
          </Button>

          <div>
            <div className="flex gap-2 items-center">
              <h1 className="text-xl font-semibold">
                {incident.incidentNumber}
              </h1>
            </div>
            <p className="text-muted-foreground">{incident.title}</p>
          </div>
        </div>

        {/* <Button variant="outline" asChild>
                    <Link to={`/incidents/${incident.id}/edit`}>
                        <Edit className="w-4 h-4 mr-2" />
                        Edit
                    </Link>
                </Button> */}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* LEFT */}
        <div className="lg:col-span-2 space-y-6">
          {/* Description */}
          <Card>
            <CardHeader>
              <CardTitle>Description</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="whitespace-pre-wrap">{incident.description}</p>
            </CardContent>
          </Card>

          {/* Resolution Notes */}
          {incident.resolution && (
            <Card>
              <CardHeader>
                <CardTitle>Resolution Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-wrap">{incident.resolution}</p>
              </CardContent>
            </Card>
          )}

          {/* COMMENTS */}
          <Card>
            <CardHeader>
              <CardTitle className="flex gap-2 items-center">
                <MessageSquare className="w-5 h-5" />
                Comments
              </CardTitle>
            </CardHeader>

            <CardContent>
              {!incident.comments || incident.comments.length === 0 ? (
                <p className="text-sm text-muted-foreground mb-4">
                  No comments yet
                </p>
              ) : (
                <div className="space-y-4 mb-4">
                  {incident.comments.map((c: any) => (
                    <div key={c.id} className="flex gap-3">
                      <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                        <User className="w-4 h-4" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">
                          {c.authorName || "Unknown User"}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {formatDate(c.createdAt)}
                        </p>
                        <p className="mt-1">{c.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex gap-2">
                <Textarea
                  placeholder="Add a comment..."
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  disabled={addCommentMutation.isPending}
                />
                <Button
                  onClick={handleAddComment}
                  disabled={!comment.trim() || addCommentMutation.isPending}
                >
                  {addCommentMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    "Post"
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* RIGHT */}
        <div className="space-y-6">
          {/* STATUS, PRIORITY, IMPACT & URGENCY */}
          <Card>
            <CardHeader>
              <CardTitle>Status & Classification</CardTitle>
            </CardHeader>

            <CardContent className="grid grid-cols-2 gap-4">
              {/* Status */}
              <div>
                <p className="text-xs text-muted-foreground mb-2">Status</p>
                <Badge className={statusInfo.className}>
                  {statusInfo.label}
                </Badge>
              </div>

              {/* Priority */}
              <div>
                <p className="text-xs text-muted-foreground mb-2">Priority</p>
                <Badge className={priorityConfig[incident.priority]}>
                  {incident.priority}
                </Badge>
              </div>

              {/* Impact */}
              <div>
                <p className="text-xs text-muted-foreground mb-2">Impact</p>
                <Badge className={impactConfig[incident.impact]}>
                  {incident.impact}
                </Badge>
              </div>

              {/* Urgency */}
              <div>
                <p className="text-xs text-muted-foreground mb-2">Urgency</p>
                <Badge className={urgencyConfig[incident.urgency]}>
                  {incident.urgency}
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* DETAILS */}
          <Card>
            <CardHeader>
              <CardTitle>Details</CardTitle>
            </CardHeader>

            <CardContent className="space-y-4">
              <div className="flex gap-3">
                <User className="w-4 h-4 mt-1" />
                <div>
                  <p className="text-xs text-muted-foreground">Reported By</p>
                  <p className="text-sm font-medium">
                    {incident.reportedByName || "Unknown"}
                  </p>
                </div>
              </div>

              <Separator />

              <div className="flex gap-3">
                <User className="w-4 h-4 mt-1" />
                <div>
                  <p className="text-xs text-muted-foreground">Assigned To</p>
                  <p className="text-sm font-medium">
                    {incident.assignedToName || "Unassigned"}
                  </p>
                </div>
              </div>

              <Separator />

              <div className="flex gap-3">
                <User className="w-4 h-4 mt-1" />
                <div>
                  <p className="text-xs text-muted-foreground">
                    Assigned Group
                  </p>
                  <p className="text-sm font-medium">
                    {incident.assignedGroupName || "Unassigned"}
                  </p>
                </div>
              </div>

              <Separator />

              <div className="flex gap-3">
                <AlertTriangle className="w-4 h-4 mt-1" />
                <div>
                  <p className="text-xs text-muted-foreground">
                    Configuration Item
                  </p>
                  <p className="text-sm font-medium">
                    {incident.configurationItemName || "N/A"}
                  </p>
                </div>
              </div>

              <Separator />

              <div className="flex gap-3">
                <Calendar className="w-4 h-4 mt-1" />
                <div>
                  <p className="text-xs text-muted-foreground">Created</p>
                  <p className="text-sm font-medium">
                    {formatDate(incident.createdDate)}
                  </p>
                </div>
              </div>

              {incident.resolvedDate && (
                <>
                  <Separator />
                  <div className="flex gap-3">
                    <Calendar className="w-4 h-4 mt-1" />
                    <div>
                      <p className="text-xs text-muted-foreground">Resolved</p>
                      <p className="text-sm font-medium">
                        {formatDate(incident.resolvedDate)}
                      </p>
                    </div>
                  </div>
                </>
              )}

              {incident.closedDate && (
                <>
                  <Separator />
                  <div className="flex gap-3">
                    <Calendar className="w-4 h-4 mt-1" />
                    <div>
                      <p className="text-xs text-muted-foreground">Closed</p>
                      <p className="text-sm font-medium">
                        {formatDate(incident.closedDate)}
                      </p>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* ACTIVITY */}
          <Card>
            <CardHeader>
              <CardTitle className="flex gap-2 items-center">
                <History className="w-5 h-5" />
                Activity Log
              </CardTitle>
            </CardHeader>

            <CardContent>
              {!incident.auditLog || incident.auditLog.length === 0 ? (
                <p className="text-sm text-muted-foreground">No activity yet</p>
              ) : (
                <div className="space-y-3">
                  {incident.auditLog.map((a: any) => (
                    <div key={a.id}>
                      <p className="text-sm">
                        <span className="font-medium">
                          {a.performedByName || "System"}
                        </span>{" "}
                        {a.action}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatDate(a.performedAt)}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
