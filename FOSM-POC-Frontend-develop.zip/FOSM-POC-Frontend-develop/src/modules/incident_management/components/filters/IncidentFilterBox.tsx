import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Search, X } from "lucide-react"
import { useEffect, useState } from "react"
import { AssignedGroupCombobox } from "@/components/shared/dropdowns/AssignedGroupCombobox"
import { AssigneeCombobox } from "@/components/shared/dropdowns/AssigneeCombobox"
import { RequesterCombobox } from "@/components/shared/dropdowns/RequesterCombobox"
import { IncidentFilters } from "@/types/incidents"
import { 
  PRIORITY_CONFIG,
  STATUS_CONFIG,
  getPriorityLabel,
  getPriorityColor,
  getStatusLabel,
  getStatusColor,
} from "../../constants"

type IncidentFilterField = 'search' | 'priority' | 'status' | 'assignedGroup' | 'assignedTo' | 'reportedBy'

interface IncidentFilterBoxProps {
  filters: IncidentFilters
  onChange: (filters: Partial<IncidentFilters>) => void
  onReset: () => void
  hasActiveFilters: boolean
  hiddenFields?: IncidentFilterField[]
}

export const IncidentFilterBox = ({
  filters,
  onChange,
  onReset,
  hasActiveFilters,
  hiddenFields = [],
}: IncidentFilterBoxProps) => {
  const [searchInput, setSearchInput] = useState(filters.search ?? '')

  // Check if a field should be visible
  const isFieldVisible = (field: IncidentFilterField): boolean => {
    return !hiddenFields.includes(field)
  }

  // Debounce search input
  useEffect(() => {
    const timer = setTimeout(() => {
      onChange({ search: searchInput || null })
    }, 200) // 500ms debounce

    return () => clearTimeout(timer)
  }, [searchInput, onChange])

  return (
    <div className="flex flex-wrap gap-4 items-end">
      {/* Search - Conditionally visible */}
      {isFieldVisible('search') && (
        <div className="flex flex-col gap-1 flex-1 min-w-[250px]">
          <Label htmlFor="search">Search</Label>
          <div className="relative">
            <Input
              id="search"
              placeholder="Search by incident number, title, or description"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="pr-10"
            />
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          </div>
        </div>
      )}

      {/* Priority */}
      {isFieldVisible('priority') && (
        <div className="flex flex-col gap-1 w-[180px]">
          <Label htmlFor="priority">Priority</Label>
          <Select value={filters.priority ?? ''} onValueChange={(value) => onChange({ priority: value || null })}>
            <SelectTrigger id="priority" className="h-10">
              {filters.priority ? (
                <Badge className={'capitalize border-none ' + getPriorityColor(filters.priority)}>
                  {getPriorityLabel(filters.priority)}
                </Badge>
              ) : (
                <SelectValue placeholder="All Priorities" />
              )}
            </SelectTrigger>
            <SelectContent>
              {PRIORITY_CONFIG.map((config) => (
                <SelectItem key={config.value} value={config.value}>
                  <Badge className={'capitalize border-none ' + config.class}>
                    {config.label}
                  </Badge>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* State */}
      {isFieldVisible('status') && (
        <div className="flex flex-col gap-1 w-[180px]">
          <Label htmlFor="status">State</Label>
          <Select value={filters.status ? String(filters.status) : ''} onValueChange={(value) => onChange({ status: value ? parseInt(value) : null })}>
            <SelectTrigger id="status" className="h-10">
              {filters.status ? (
                <Badge className={'capitalize border-none ' + getStatusColor(filters.status)}>
                  {getStatusLabel(filters.status)}
                </Badge>
              ) : (
                <SelectValue placeholder="All States" />
              )}
            </SelectTrigger>
            <SelectContent>
              {STATUS_CONFIG.map((config) => (
                <SelectItem key={config.value} value={String(config.value)}>
                  <Badge className={'capitalize border-none ' + config.class}>
                    {config.label}
                  </Badge>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Assigned Group Combobox */}
      {isFieldVisible('assignedGroup') && (
        <AssignedGroupCombobox
          value={filters.assignedGroup}
          onChange={(value) => onChange({ assignedGroup: value ? (typeof value === 'object' ? value.id : value) : null })}
        />
      )}

      {/* Assignee Combobox */}
      {isFieldVisible('assignedTo') && (
        <AssigneeCombobox
          value={filters.assignedTo}
          onChange={(value) => onChange({ assignedTo: value ? (typeof value === 'object' ? value.id : value) : null })}
          selectedGroup={filters.assignedGroup}
        />
      )}

      {/* Requester Combobox */}
      {isFieldVisible('reportedBy') && (
        <RequesterCombobox
          value={filters.reportedBy}
          onChange={(value) => onChange({ reportedBy: value })}
        />
      )}

      {/* Reset Button - Visible only when filters are applied */}
      {hasActiveFilters && (
        <Button
          size="icon"
          variant="destructive"
          onClick={onReset}
          title="Clear Filters"
        >
          <X className="w-4 h-4" />
        </Button>
      )}
    </div>
  )
}
