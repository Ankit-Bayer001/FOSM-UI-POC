import React from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ArrowLeft, Upload } from "lucide-react";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { AssignedGroupCombobox } from "@/components/shared/dropdowns/AssignedGroupCombobox";
import { AssigneeCombobox } from "@/components/shared/dropdowns/AssigneeCombobox";

// ITIL User Incident Schema - matches FRD requirements
const itilIncidentSchema = z.object({
  number: z.string().optional(),
  caller: z.string().optional(),
  configurationItem: z.string().optional(),
  shortDescription: z
    .string()
    .min(1, "Short description is required")
    .max(200, "Short description must be less than 200 characters"),
  description: z.string().min(1, "Description is required"),
  urgency: z.enum(["Low", "Medium", "High"], {
    required_error: "Urgency is required",
  }),
  impact: z.enum(["Low", "Medium", "High"], {
    required_error: "Impact is required",
  }),
  priority: z.string().optional(),
  assignmentGroup: z.union([
    z.object({ id: z.string(), name: z.string() }),
    z.string(),
  ]).nullable().optional(),
  assignedTo: z.union([
    z.object({ id: z.string(), display_name: z.string() }),
    z.string(),
  ]).nullable().optional(),
  assignedGroups: z.string().optional(),
  assignedGroupName: z.string().optional(),
  assignedToName: z.string().optional(),
  state: z.string().optional(),
  additionalDetails: z.string().optional(),
  attachments: z.array(z.any()).optional(),
});

type ITILIncidentFormValues = z.infer<typeof itilIncidentSchema>;

interface AddIncidentFormProps {
  onSubmit: (values: ITILIncidentFormValues) => void;
  isSubmitting?: boolean;
}

export const AddIncidentForm = ({ onSubmit: onFormSubmit, isSubmitting = false }: AddIncidentFormProps) => {
  const form = useForm<ITILIncidentFormValues>({
    resolver: zodResolver(itilIncidentSchema),
    defaultValues: {
      caller: "John Doe (john.doe@company.com)",
      configurationItem: "",
      shortDescription: "",
      description: "",
      urgency: undefined,
      impact: undefined,
      priority: "",
      assignmentGroup: null,
      assignedTo: null,
      state: "New",
      additionalDetails: "",
      attachments: [],
    },
  });

  const calculatePriority = (impact: string, urgency: string) => {
    const priorityMatrix: Record<string, Record<string, string>> = {
      High: { High: "P1", Medium: "P2", Low: "P3" },
      Medium: { High: "P2", Medium: "P3", Low: "P4" },
      Low: { High: "P3", Medium: "P4", Low: "P5" },
    };
    return priorityMatrix[impact]?.[urgency] || "";
  };

  const watchImpact = form.watch("impact");
  const watchUrgency = form.watch("urgency");
  const watchAssignmentGroup = form.watch("assignmentGroup");

  React.useEffect(() => {
    if (watchImpact && watchUrgency) {
      const calculatedPriority = calculatePriority(watchImpact, watchUrgency);
      form.setValue("priority", calculatedPriority);
    }
  }, [form, watchImpact, watchUrgency]);

  // Clear assigned user when group changes
  React.useEffect(() => {
    const hasGroup = watchAssignmentGroup && 
      (typeof watchAssignmentGroup === 'object' ? watchAssignmentGroup.id : watchAssignmentGroup);
    
    if (hasGroup) {
      form.setValue("assignedTo", null);
    }
  }, [watchAssignmentGroup, form]);

  const onSubmit = (values: ITILIncidentFormValues) => {
    // Extract assignment group data
    const assignmentGroupData = typeof values.assignmentGroup === 'object' && values.assignmentGroup
      ? { assignedGroups: values.assignmentGroup.id, assignedGroupName: values.assignmentGroup.name }
      : { assignedGroups: values.assignmentGroup || "", assignedGroupName: "" };

    // Extract assignee data
    const assigneeData = typeof values.assignedTo === 'object' && values.assignedTo
      ? { assignedTo: values.assignedTo.id, assignedToName: values.assignedTo.display_name }
      : { assignedTo: values.assignedTo || "", assignedToName: "" };

    // Prepare the payload with all four properties
    const payload = {
      ...values,
      ...assignmentGroupData,
      ...assigneeData,
    };

    onFormSubmit(payload as any);
  };

  const handleSaveDraft = () => {
    console.log("Saving as draft...", form.getValues());
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="px-4 sm:px-6 lg:px-8 py-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column - Main Content */}
              <div className="lg:col-span-2 space-y-6">
                {/* Incident Details Card */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Incident Details</CardTitle>
                      <CardDescription>
                        Provide information about the incident you want to
                        report
                      </CardDescription>
                    </div>

                    {/* Incident Number on right */}
                    <div className="text-sm font-bold text-gray-900">
                      Incident Number: 26723637
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Short Description */}
                    <FormField
                      control={form.control}
                      name="shortDescription"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>
                            Short Description{" "}
                            <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Brief summary of the issue"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>
                            Description <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Detailed symptoms and steps to reproduce"
                              rows={5}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name="urgency"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>
                              Urgency <span className="text-red-500">*</span>
                            </FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select urgency" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="Low">Low</SelectItem>
                                <SelectItem value="Medium">Medium</SelectItem>
                                <SelectItem value="High">High</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="impact"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>
                              Impact <span className="text-red-500">*</span>
                            </FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select impact" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="Low">Low</SelectItem>
                                <SelectItem value="Medium">Medium</SelectItem>
                                <SelectItem value="High">High</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="priority"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Priority</FormLabel>
                            <FormControl>
                              <Input
                                {...field}
                                disabled
                                placeholder="Auto-calculated"
                                className="bg-gray-50 text-gray-500"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="configurationItem"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Configuration Item (CI)</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Search for affected system or asset"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Additional Information</CardTitle>
                    <CardDescription>
                      Add any additional details or attachments
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Additional Details */}
                    <FormField
                      control={form.control}
                      name="additionalDetails"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Additional Details</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Any other relevant information"
                              rows={4}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              </div>

              {/* Right Column - Sidebar */}
              <div className="lg:col-span-1 space-y-6">
                {/* Status Card */}
                <Card>
                  <CardHeader>
                    <CardTitle>Status</CardTitle>
                    <CardDescription>Current incident state</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <FormField
                      control={form.control}
                      name="state"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>State</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              disabled
                              className="bg-gray-50 text-gray-500"
                            />
                          </FormControl>
                          <p className="text-xs text-gray-500 mt-2">
                            Auto-tagged based on lifecycle
                          </p>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Assignment Details</CardTitle>
                    <CardDescription>
                      Assign the incident to appropriate team and individual
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Assignment Group */}
                    <FormField
                      control={form.control}
                      name="assignmentGroup"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <AssignedGroupCombobox
                              value={field.value as any}
                              onChange={field.onChange}
                              className="w-full"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Assigned To */}
                    <FormField
                      control={form.control}
                      name="assignedTo"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <AssigneeCombobox
                              value={field.value as any}
                              onChange={field.onChange}
                              selectedGroup={watchAssignmentGroup as any}
                              className="w-full"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Caller Card */}
                <Card>
                  <CardHeader>
                    <CardTitle>Caller</CardTitle>
                    <CardDescription>
                      Person reporting the issue
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <FormField
                      control={form.control}
                      name="caller"
                      render={({ field }) => (
                        <FormItem>
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                              <span className="text-blue-600 font-semibold text-sm">
                                {field.value?.charAt(0) || "U"}
                              </span>
                            </div>
                            <div className="flex-1">
                              <FormControl>
                                <div>
                                  <p className="text-sm font-medium text-gray-900">
                                    {field.value?.split("(")[0].trim() ||
                                      "User"}
                                  </p>
                                  <p className="text-xs text-gray-500">
                                    {field.value?.match(/\((.*?)\)/)?.[1] ||
                                      "email@company.com"}
                                  </p>
                                </div>
                              </FormControl>
                            </div>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Action Buttons */}
                <div className="space-y-3">
                  <Button 
                    type="submit" 
                    className="w-full" 
                    size="lg"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Creating..." : "Create Incident"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    size="lg"
                    onClick={handleSaveDraft}
                    disabled={isSubmitting}
                  >
                    Save as Draft
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
}
