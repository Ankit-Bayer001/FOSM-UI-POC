import React from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ArrowLeft, Upload } from "lucide-react";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

const endUserIncidentSchema = z.object({
  incidentNumber: z.string().optional(),

  issueDescription: z
    .string()
    .min(1, "Issue description is required")
    .min(10, "Please provide at least 10 characters describing the issue")
    .max(500, "Issue description must be less than 500 characters"),

  urgency: z.enum(["Low", "Medium", "High"], {
    required_error: "Please select urgency level",
  }),

  additionalDetails: z.string().optional(),

  caller: z.string().optional(),
  impact: z.string().optional(),
  priority: z.string().optional(),

  attachments: z.array(z.any()).optional(),
});

type EndUserIncidentFormValues = z.infer<typeof endUserIncidentSchema>;

export const AddIncidentFormEndUser = () => {
  const form = useForm<EndUserIncidentFormValues>({
    resolver: zodResolver(endUserIncidentSchema),
    defaultValues: {
      incidentNumber: "INC00001",
      issueDescription: "",
      urgency: undefined,
      additionalDetails: "",
      caller: "John Doe (john.doe@company.com)",
      impact: "",
      priority: "",
      attachments: [],
    },
  });
  const calculateImpactAndPriority = (urgency: string) => {
    const urgencyMapping: Record<string, { impact: string; priority: string }> =
      {
        Low: { impact: "Low", priority: "P5" },
        Medium: { impact: "Medium", priority: "P3" },
        High: { impact: "High", priority: "P2" },
      };

    return urgencyMapping[urgency] || { impact: "", priority: "" };
  };

  const watchUrgency = form.watch("urgency");

  React.useEffect(() => {
    if (watchUrgency) {
      const { impact, priority } = calculateImpactAndPriority(watchUrgency);
      form.setValue("impact", impact);
      form.setValue("priority", priority);
    }
  }, [form, watchUrgency]);

  const onSubmit = (values: EndUserIncidentFormValues) => {
    console.log("End User Incident Form Data:", values);
  };

  const handleCancel = () => {
    form.reset();
    // Navigate back or close form
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="px-4 sm:px-6 lg:px-8 py-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column - Main Content */}
              <div className="lg:col-span-2 space-y-6">
                {/* Issue Details Card */}
                <Card>
                  <CardHeader>
                    <CardTitle>What's the issue?</CardTitle>
                    <CardDescription>
                      Please describe the problem you're experiencing
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Issue Description - Mandatory */}
                    <FormField
                      control={form.control}
                      name="issueDescription"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>
                            Issue Description{" "}
                            <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Example: My laptop won't connect to WiFi, I'm unable to access email, The application keeps crashing..."
                              rows={6}
                              {...field}
                            />
                          </FormControl>
                          <p className="text-xs text-gray-500">
                            Please provide as much detail as possible to help us
                            resolve your issue quickly
                          </p>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Urgency - Mandatory with descriptions */}
                    <FormField
                      control={form.control}
                      name="urgency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>
                            How urgent is this?{" "}
                            <span className="text-red-500">*</span>
                          </FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            value={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select urgency level" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Low">
                                <div className="flex flex-col items-start">
                                  <span className="font-medium">Low</span>
                                  <span className="text-xs text-gray-500">
                                    Single user impacted, can work around it
                                  </span>
                                </div>
                              </SelectItem>
                              <SelectItem value="Medium">
                                <div className="flex flex-col items-start">
                                  <span className="font-medium">Medium</span>
                                  <span className="text-xs text-gray-500">
                                    Multiple users impacted
                                  </span>
                                </div>
                              </SelectItem>
                              <SelectItem value="High">
                                <div className="flex flex-col items-start">
                                  <span className="font-medium">High</span>
                                  <span className="text-xs text-gray-500">
                                    Impacts business operations
                                  </span>
                                </div>
                              </SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Additional Information Card */}
                <Card>
                  <CardHeader>
                    <CardTitle>Additional Information</CardTitle>
                    <CardDescription>
                      Any other details that might help us (optional)
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Additional Details - Optional */}
                    <FormField
                      control={form.control}
                      name="additionalDetails"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Additional Details</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Example: Error messages you're seeing, steps you've already tried, when the problem started..."
                              rows={4}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              </div>

              {/* Right Column - Sidebar */}
              <div className="lg:col-span-1 space-y-6">
                {/* Your Information Card */}
                <Card>
                  <CardHeader>
                    <CardTitle>Your Information</CardTitle>
                    <CardDescription>We'll contact you at</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <FormField
                      control={form.control}
                      name="caller"
                      render={({ field }) => (
                        <FormItem>
                          <div className="flex items-center gap-3">
                            <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                              <span className="text-blue-600 font-semibold">
                                {field.value?.charAt(0) || "U"}
                              </span>
                            </div>
                            <div className="flex-1">
                              <FormControl>
                                <div>
                                  <p className="text-sm font-medium text-gray-900">
                                    {field.value?.split("(")[0].trim() ||
                                      "User"}
                                  </p>
                                  <p className="text-xs text-gray-500">
                                    {field.value?.match(/\((.*?)\)/)?.[1] ||
                                      "email@company.com"}
                                  </p>
                                </div>
                              </FormControl>
                            </div>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Action Buttons */}
                <div className="space-y-3">
                  <Button type="submit" className="w-full" size="lg">
                    Submit Incident
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    size="lg"
                    onClick={handleCancel}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
}
