/**
 * Incident Management Mock Data Exports
 */

export { mockAllIncidentsData } from '@/mockData';
