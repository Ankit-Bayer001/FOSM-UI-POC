/**
 * AddIncidentForm Component Tests
 * 
 * Tests for the incident creation form including:
 * - Form rendering
 * - Form validation
 * - Input field changes
 * - Default values
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { AddIncidentForm } from '../../components/forms/AddIncidentForm'

// Mock the dropdown components to avoid complex setup
vi.mock('@/components/shared/dropdowns/AssignedGroupCombobox', () => ({
  AssignedGroupCombobox: ({ value, onChange }: any) => (
    <div data-testid="assigned-group-combobox">
      <input
        data-testid="assigned-group-input"
        value={typeof value === 'object' ? value?.name || '' : (value || '')}
        onChange={(e) => {
          if (e.target.value === 'test-group') {
            onChange({ id: 'group1', name: 'IT Support' })
          } else {
            onChange(e.target.value)
          }
        }}
        placeholder="Select group"
      />
    </div>
  ),
}))

vi.mock('@/components/shared/dropdowns/AssigneeCombobox', () => ({
  AssigneeCombobox: ({ value, onChange }: any) => (
    <div data-testid="assignee-combobox">
      <input
        data-testid="assignee-input"
        value={typeof value === 'object' ? value?.display_name || '' : (value || '')}
        onChange={(e) => {
          if (e.target.value === 'test-user') {
            onChange({ id: 'user1', display_name: 'John Doe' })
          } else {
            onChange(e.target.value)
          }
        }}
        placeholder="Select assignee"
      />
    </div>
  ),
}))

describe('AddIncidentForm', () => {
  const mockOnSubmit = vi.fn()

  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('Rendering', () => {
    it('should render the form with all main sections', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      expect(screen.getByText('Incident Details')).toBeInTheDocument()
      expect(screen.getByText('Additional Information')).toBeInTheDocument()
      expect(screen.getByText('Status')).toBeInTheDocument()
      expect(screen.getByText('Assignment Details')).toBeInTheDocument()
      expect(screen.getByText('Caller')).toBeInTheDocument()
    })

    it('should render all key form fields', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      expect(screen.getByPlaceholderText('Brief summary of the issue')).toBeInTheDocument()
      expect(screen.getByPlaceholderText('Detailed symptoms and steps to reproduce')).toBeInTheDocument()
      expect(screen.getByPlaceholderText('Search for affected system or asset')).toBeInTheDocument()
      expect(screen.getByPlaceholderText('Any other relevant information')).toBeInTheDocument()
    })

    it('should render submit and draft buttons', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      expect(screen.getByRole('button', { name: /Create Incident/i })).toBeInTheDocument()
      expect(screen.getByRole('button', { name: /Save as Draft/i })).toBeInTheDocument()
    })

    it('should render priority field as read-only', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      // Look for placeholder instead of value since it might be empty initially
      const priorityInputs = screen.queryAllByPlaceholderText('Auto-calculated')
      if (priorityInputs.length === 0) {
        // If not found by placeholder, just check that there's a priority input that's disabled
        const allInputs = screen.getAllByDisplayValue('') as HTMLInputElement[]
        const priorityInput = allInputs.find(input => input.className.includes('bg-gray-50'))
        if (priorityInput) {
          expect(priorityInput).toBeDisabled()
        }
      } else {
        priorityInputs.forEach(input => {
          expect(input).toBeDisabled()
        })
      }
    })

    it('should render state field as read-only with default "New"', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const stateInput = screen.getByDisplayValue('New')
      expect(stateInput).toBeDisabled()
    })

    it('should render urgency and impact selectors', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      // Find all selects - they should include urgency and impact
      const selects = screen.getAllByRole('combobox')
      expect(selects.length).toBeGreaterThanOrEqual(2)
    })

    it('should render assignment and assignee comboboxes', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      expect(screen.getByTestId('assigned-group-combobox')).toBeInTheDocument()
      expect(screen.getByTestId('assignee-combobox')).toBeInTheDocument()
    })
  })

  describe('Form Validation', () => {
    it('should show validation error for empty short description', async () => {
      const user = userEvent.setup()
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const submitButton = screen.getByRole('button', { name: /Create Incident/i })
      await user.click(submitButton)

      await waitFor(() => {
        expect(screen.getByText('Short description is required')).toBeInTheDocument()
      })
    })

    it('should show validation error for empty description', async () => {
      const user = userEvent.setup()
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const shortDescInput = screen.getByPlaceholderText('Brief summary of the issue')
      await user.type(shortDescInput, 'Test')

      const submitButton = screen.getByRole('button', { name: /Create Incident/i })
      await user.click(submitButton)

      await waitFor(() => {
        expect(screen.getByText('Description is required')).toBeInTheDocument()
      })
    })

    it('should show validation error for missing urgency', async () => {
      const user = userEvent.setup()
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const shortDescInput = screen.getByPlaceholderText('Brief summary of the issue')
      const descInput = screen.getByPlaceholderText('Detailed symptoms and steps to reproduce')

      await user.type(shortDescInput, 'Test issue')
      await user.type(descInput, 'Test description')

      const submitButton = screen.getByRole('button', { name: /Create Incident/i })
      await user.click(submitButton)

      await waitFor(() => {
        expect(screen.getByText('Urgency is required')).toBeInTheDocument()
      })
    })

    it('should show validation error for missing impact', async () => {
      const user = userEvent.setup()
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const shortDescInput = screen.getByPlaceholderText('Brief summary of the issue')
      const descInput = screen.getByPlaceholderText('Detailed symptoms and steps to reproduce')

      await user.type(shortDescInput, 'Test issue')
      await user.type(descInput, 'Test description')

      const submitButton = screen.getByRole('button', { name: /Create Incident/i })
      await user.click(submitButton)

      await waitFor(() => {
        expect(screen.getByText('Impact is required')).toBeInTheDocument()
      })
    })

    it('should enforce max 200 character limit on short description', async () => {
      const user = userEvent.setup()
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const shortDescInput = screen.getByPlaceholderText('Brief summary of the issue') as HTMLInputElement
      const longText = 'a'.repeat(201)

      await user.type(shortDescInput, longText)
      await user.click(screen.getByRole('button', { name: /Create Incident/i }))

      await waitFor(() => {
        expect(screen.getByText('Short description must be less than 200 characters')).toBeInTheDocument()
      })
    })
  })

  describe('Input Field Changes', () => {
    it('should update short description on user input', async () => {
      const user = userEvent.setup()
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const shortDescInput = screen.getByPlaceholderText('Brief summary of the issue') as HTMLInputElement
      await user.type(shortDescInput, 'Test short description')

      expect(shortDescInput).toHaveValue('Test short description')
    })

    it('should update description on user input', async () => {
      const user = userEvent.setup()
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const descInput = screen.getByPlaceholderText('Detailed symptoms and steps to reproduce') as HTMLTextAreaElement
      await user.type(descInput, 'Test detailed description')

      expect(descInput).toHaveValue('Test detailed description')
    })

    it('should update configuration item on user input', async () => {
      const user = userEvent.setup()
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const ciInput = screen.getByPlaceholderText('Search for affected system or asset') as HTMLInputElement
      await user.type(ciInput, 'Email Server')

      expect(ciInput).toHaveValue('Email Server')
    })

    it('should update additional details on user input', async () => {
      const user = userEvent.setup()
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const additionalInput = screen.getByPlaceholderText('Any other relevant information') as HTMLTextAreaElement
      await user.type(additionalInput, 'Additional test details')

      expect(additionalInput).toHaveValue('Additional test details')
    })

    it('should clear field content on backspace', async () => {
      const user = userEvent.setup()
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const shortDescInput = screen.getByPlaceholderText('Brief summary of the issue') as HTMLInputElement
      await user.type(shortDescInput, 'Test text')
      await user.clear(shortDescInput)

      expect(shortDescInput).toHaveValue('')
    })
  })

  describe('Combobox Interactions', () => {
    it('should update assignment group when selected', async () => {
      const user = userEvent.setup()
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const groupInput = screen.getByTestId('assigned-group-input')
      await user.type(groupInput, 'test-group')

      // The mock simulates selection by checking for 'test-group'
      await waitFor(() => {
        expect(groupInput).toHaveValue('IT Support')
      })
    })

    it('should update assignee when selected', async () => {
      const user = userEvent.setup()
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const assigneeInput = screen.getByTestId('assignee-input')
      await user.type(assigneeInput, 'test-user')

      // The mock simulates selection by checking for 'test-user'
      await waitFor(() => {
        expect(assigneeInput).toHaveValue('John Doe')
      })
    })
  })

  describe('Button States', () => {
    it('should disable submit button when isSubmitting is true', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} isSubmitting={true} />)

      const submitButton = screen.getByRole('button', { name: /Creating/i })
      expect(submitButton).toBeDisabled()
    })

    it('should disable draft button when isSubmitting is true', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} isSubmitting={true} />)

      const draftButton = screen.getByRole('button', { name: /Save as Draft/i })
      expect(draftButton).toBeDisabled()
    })

    it('should enable buttons when isSubmitting is false', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} isSubmitting={false} />)

      const submitButton = screen.getByRole('button', { name: /Create Incident/i })
      const draftButton = screen.getByRole('button', { name: /Save as Draft/i })

      expect(submitButton).not.toBeDisabled()
      expect(draftButton).not.toBeDisabled()
    })
  })

  describe('Save as Draft', () => {
    it('should call console.log when draft button is clicked', async () => {
      const user = userEvent.setup()
      const consoleLogSpy = vi.spyOn(console, 'log')

      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const draftButton = screen.getByRole('button', { name: /Save as Draft/i })
      await user.click(draftButton)

      expect(consoleLogSpy).toHaveBeenCalledWith(
        'Saving as draft...',
        expect.any(Object)
      )

      consoleLogSpy.mockRestore()
    })
  })

  describe('Default Values', () => {
    it('should display default caller information', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      expect(screen.getByText(/John Doe/i)).toBeInTheDocument()
      expect(screen.getByText(/john.doe@company.com/i)).toBeInTheDocument()
    })

    it('should have default state "New"', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const stateInput = screen.getByDisplayValue('New')
      expect(stateInput).toBeInTheDocument()
    })

    it('should have default incident number', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      expect(screen.getByText(/Incident Number: 26723637/i)).toBeInTheDocument()
    })

    it('should have empty assignment group by default', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const groupInput = screen.getByTestId('assigned-group-input') as HTMLInputElement
      expect(groupInput.value).toBe('')
    })

    it('should have empty assignee by default', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      const assigneeInput = screen.getByTestId('assignee-input') as HTMLInputElement
      expect(assigneeInput.value).toBe('')
    })
  })

  describe('Form Field Labels', () => {
    it('should display required indicators for mandatory fields', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      // Check for required indicators (asterisks)
      const requiredIndicators = screen.getAllByText('*')
      expect(requiredIndicators.length).toBeGreaterThan(0)
    })

    it('should have form field labels visible', () => {
      render(<AddIncidentForm onSubmit={mockOnSubmit} />)

      expect(screen.getByText('Short Description')).toBeInTheDocument()
      expect(screen.getByText('Description')).toBeInTheDocument()
      expect(screen.getByText('Urgency')).toBeInTheDocument()
      expect(screen.getByText('Impact')).toBeInTheDocument()
      expect(screen.getByText('Priority')).toBeInTheDocument()
    })
  })
})
