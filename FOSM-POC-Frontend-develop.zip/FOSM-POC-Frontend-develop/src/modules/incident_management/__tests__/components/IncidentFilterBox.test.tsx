/**
 * IncidentFilterBox Component Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { IncidentFilterBox } from '../../components/filters/IncidentFilterBox'
import { IncidentFilters } from '@/types/incidents'

// Mock the dropdown components
vi.mock('@/components/shared/dropdowns/AssignedGroupCombobox', () => ({
  AssignedGroupCombobox: ({ value, onChange }: any) => (
    <div data-testid="assigned-group-combobox">
      <input
        data-testid="assigned-group-input"
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Select group"
      />
    </div>
  ),
}))

vi.mock('@/components/shared/dropdowns/AssigneeCombobox', () => ({
  AssigneeCombobox: ({ value, onChange }: any) => (
    <div data-testid="assignee-combobox">
      <input
        data-testid="assignee-input"
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Select assignee"
      />
    </div>
  ),
}))

vi.mock('@/components/shared/dropdowns/RequesterCombobox', () => ({
  RequesterCombobox: ({ value, onChange }: any) => (
    <div data-testid="requester-combobox">
      <input
        data-testid="requester-input"
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Select requester"
      />
    </div>
  ),
}))

describe('IncidentFilterBox', () => {
  const mockOnChange = vi.fn()
  const mockOnReset = vi.fn()

  const defaultFilters: IncidentFilters = {
    search: null,
    priority: null,
    status: null,
    assignedGroup: null,
    assignedTo: null,
    reportedBy: null,
  }

  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('should render the component', () => {
    render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={false}
      />
    )

    expect(screen.getByText('Search')).toBeInTheDocument()
  })

  it('should render search input', () => {
    render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={false}
      />
    )

    const searchInput = screen.getByPlaceholderText(/search by incident/i)
    expect(searchInput).toBeInTheDocument()
  })

  it('should render priority selector', () => {
    render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={false}
      />
    )

    // Check that component renders without errors
    expect(screen.getByText('Search')).toBeInTheDocument()
  })

  it('should render status filter', () => {
    render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={false}
      />
    )

    // Component should render without errors
    expect(screen.getByText('Search')).toBeInTheDocument()
  })

  it('should render assigned group combobox', () => {
    render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={false}
      />
    )

    expect(screen.getByTestId('assigned-group-combobox')).toBeInTheDocument()
  })

  it('should render assignee combobox', () => {
    render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={false}
      />
    )

    expect(screen.getByTestId('assignee-combobox')).toBeInTheDocument()
  })

  it('should render requester combobox', () => {
    render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={false}
      />
    )

    expect(screen.getByTestId('requester-combobox')).toBeInTheDocument()
  })

  it('should call onChange when search input changes', async () => {
    const user = userEvent.setup()

    render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={false}
      />
    )

    const searchInput = screen.getByPlaceholderText(/search by incident/i)
    await user.type(searchInput, 'test')

    // Wait for debounce
    await waitFor(() => {
      expect(mockOnChange).toHaveBeenCalledWith({ search: 'test' })
    }, { timeout: 500 })
  })

  it('should debounce search input', async () => {
    const user = userEvent.setup()
    
    render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={false}
      />
    )

    const searchInput = screen.getByPlaceholderText(/search by incident/i) as HTMLInputElement
    
    // Type multiple characters quickly
    await user.type(searchInput, 'test', { delay: 50 })

    // onChange should be called after debounce, not for every keystroke
    expect(mockOnChange.mock.calls.length).toBeLessThan(4)
  })

  it('should accept priority filter prop', () => {
    const filtersWithPriority: IncidentFilters = {
      ...defaultFilters,
      priority: 'P1',
    }

    const { rerender } = render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={false}
      />
    )

    // Verify component can re-render with different filters
    rerender(
      <IncidentFilterBox
        filters={filtersWithPriority}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={true}
      />
    )

    // Component should render without errors
    expect(screen.getByText('Search')).toBeInTheDocument()
  })

  it('should accept status filter prop', () => {
    const filtersWithStatus: IncidentFilters = {
      ...defaultFilters,
      status: 'open',
    }

    const { rerender } = render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={false}
      />
    )

    // Verify component can re-render with different filters
    rerender(
      <IncidentFilterBox
        filters={filtersWithStatus}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={true}
      />
    )

    // Component should render without errors
    expect(screen.getByText('Search')).toBeInTheDocument()
  })

  it('should have reset button when hasActiveFilters is true', () => {
    render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={true}
      />
    )

    const resetButton = screen.getByRole('button', { name: /clear filters|reset/i })
    expect(resetButton).toBeInTheDocument()
  })

  it('should call onReset when reset button is clicked', async () => {
    const user = userEvent.setup()

    render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={true}
      />
    )

    const resetButton = screen.getByRole('button', { name: /clear filters|reset/i })
    await user.click(resetButton)

    expect(mockOnReset).toHaveBeenCalled()
  })

  it('should display current search value', () => {
    const filtersWithSearch: IncidentFilters = {
      ...defaultFilters,
      search: 'critical issue',
    }

    render(
      <IncidentFilterBox
        filters={filtersWithSearch}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={true}
      />
    )

    const searchInput = screen.getByPlaceholderText(/search by incident/i) as HTMLInputElement
    expect(searchInput.value).toBe('critical issue')
  })

  it('should clear search when null is passed', () => {
    const filtersWithoutSearch: IncidentFilters = {
      ...defaultFilters,
      search: null,
    }

    render(
      <IncidentFilterBox
        filters={filtersWithoutSearch}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={false}
      />
    )

    const searchInput = screen.getByPlaceholderText(/search by incident/i) as HTMLInputElement
    expect(searchInput.value).toBe('')
  })

  it('should render all filter fields', () => {
    render(
      <IncidentFilterBox
        filters={defaultFilters}
        onChange={mockOnChange}
        onReset={mockOnReset}
        hasActiveFilters={false}
      />
    )

    // Check for key filter elements
    expect(screen.getByText('Search')).toBeInTheDocument()
    expect(screen.getByText('Priority')).toBeInTheDocument()
    // Other filter labels may vary based on rendering
  })
})
