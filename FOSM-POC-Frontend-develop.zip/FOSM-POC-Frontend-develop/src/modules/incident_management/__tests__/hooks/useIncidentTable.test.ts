/**
 * useIncidentTable Hook Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'
import { renderHook, act } from '@testing-library/react'
import { QueryClientProvider } from '@tanstack/react-query'
import React from 'react'
import { useIncidentTable } from '../../hooks/useIncidentTable'
import { queryClient } from '@/lib/queryClient'
import { IncidentFilters } from '@/types/incidents'

// Mock useAuth hook
vi.mock('@/contexts/AuthContext', () => ({
  useAuth: vi.fn(() => ({
    user: { id: 'user-1', email: 'test@example.com' },
    hasPermission: vi.fn(() => true),
  })),
}))

// Mock useIncidents hook
vi.mock('../../hooks/useIncidents', () => ({
  useIncidents: vi.fn((page, pageSize, filters) => ({
    data: {
      data: [
        {
          id: '1',
          incidentNumber: 'INC-001',
          title: 'Test Incident',
          status: 'open',
          priority: 'P1',
          assignedToName: 'John Doe',
          assignedGroupName: 'IT Support',
          reportedByName: 'Jane Smith',
          configurationItemName: 'Server-01',
          createdDate: '2024-02-01',
        },
      ],
      total: 50,
    },
    isLoading: false,
    error: null,
  })),
}))

const wrapper = ({ children }: { children: React.ReactNode }) =>
  React.createElement(QueryClientProvider, { client: queryClient }, children)

describe('useIncidentTable', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('should return initial values', () => {
    const { result } = renderHook(() => useIncidentTable({}), { wrapper })

    expect(result.current).toEqual(
      expect.objectContaining({
        data: expect.any(Array),
        total: expect.any(Number),
        page: expect.any(Number),
        pageSize: expect.any(Number),
        loading: expect.any(Boolean),
        columns: expect.any(Array),
      })
    )
  })

  it('should have page 1 by default', () => {
    const { result } = renderHook(() => useIncidentTable({}), { wrapper })

    expect(result.current.page).toBe(1)
  })

  it('should have default pageSize of 5', () => {
    const { result } = renderHook(
      () => useIncidentTable({}, { pageSize: 5 }),
      { wrapper }
    )

    expect(result.current.pageSize).toBe(5)
  })

  it('should accept custom pageSize option', () => {
    const { result } = renderHook(
      () => useIncidentTable({}, { pageSize: 10 }),
      { wrapper }
    )

    expect(result.current.pageSize).toBe(10)
  })

  it('should handle pageSize changes', () => {
    const { result } = renderHook(() => useIncidentTable({}), { wrapper })

    expect(result.current.pageSize).toBeGreaterThan(0)
  })

  it('should provide setPage function', () => {
    const { result } = renderHook(() => useIncidentTable({}), { wrapper })

    expect(typeof result.current.setPage).toBe('function')
  })

  it('should provide setPageSize function', () => {
    const { result } = renderHook(() => useIncidentTable({}), { wrapper })

    expect(typeof result.current.setPageSize).toBe('function')
  })

  it('should exclude columns when myIncidentsOnly is true', () => {
    const { result } = renderHook(
      () => useIncidentTable({}, { myIncidentsOnly: true }),
      { wrapper }
    )

    // When myIncidentsOnly is true, hook should be configured correctly
    expect(result.current.columns).toBeDefined()
    expect(Array.isArray(result.current.columns)).toBe(true)
  })

  it('should hide specified columns', () => {
    const { result } = renderHook(
      () => useIncidentTable({}, { hiddenColumns: ['status', 'priority'] }),
      { wrapper }
    )

    const columnKeys = result.current.columns
      .map((col: any) => col.accessorKey || col.id)
      .filter(Boolean)

    expect(columnKeys).not.toContain('status')
    expect(columnKeys).not.toContain('priority')
  })

  it('should convert status filter to string', () => {
    const filters: IncidentFilters = {
      status: 'open',
      priority: null,
      search: null,
      reportedByName: null,
      assignedGroup: null,
      assignedTo: null,
    }

    const { result } = renderHook(() => useIncidentTable(filters), { wrapper })

    expect(result.current).toBeDefined()
  })

  it('should include error from useIncidents hook', () => {
    const { result } = renderHook(() => useIncidentTable({}), { wrapper })

    expect(result.current.error).toBeDefined()
  })

  it('should include loading state from useIncidents hook', () => {
    const { result } = renderHook(() => useIncidentTable({}), { wrapper })

    expect(typeof result.current.loading).toBe('boolean')
  })

  it('should include data from useIncidents hook', () => {
    const { result } = renderHook(() => useIncidentTable({}), { wrapper })

    expect(Array.isArray(result.current.data)).toBe(true)
  })

  it('should include total count from useIncidents hook', () => {
    const { result } = renderHook(() => useIncidentTable({}), { wrapper })

    expect(typeof result.current.total).toBe('number')
  })

  it('should default to pageSize 5 if not specified', () => {
    const { result } = renderHook(() => useIncidentTable({}), { wrapper })

    expect(result.current.pageSize).toBe(5) // Default in hook
  })

  it('should use custom pageSize when provided', () => {
    const { result } = renderHook(
      () => useIncidentTable({}, { pageSize: 20 }),
      { wrapper }
    )

    expect(result.current.pageSize).toBe(20)
  })

  it('should pass myIncidentsOnly=true when specified', () => {
    const { result } = renderHook(
      () => useIncidentTable({}, { myIncidentsOnly: true }),
      { wrapper }
    )

    // Should render without error
    expect(result.current).toBeDefined()
  })
})
