/**
 * useFilters Hook Tests
 */

import { describe, it, expect, beforeEach } from 'vitest'
import { renderHook, act } from '@testing-library/react'
import { useFilters } from '../../hooks/useFilters'

describe('useFilters', () => {
  beforeEach(() => {
    // Reset any state between tests
  })

  it('should initialize with default filters', () => {
    const { result } = renderHook(() => useFilters())

    expect(result.current.filters).toEqual({
      search: null,
      priority: null,
      status: null,
      assignedGroup: null,
      assignedTo: null,
      reportedBy: null,
    })
  })

  it('should initialize with provided initial filters', () => {
    const initialFilters = {
      search: 'test',
      priority: 'P1',
    }

    const { result } = renderHook(() => useFilters(initialFilters))

    expect(result.current.filters).toMatchObject({
      search: 'test',
      priority: 'P1',
      status: null,
    })
  })

  it('should update filters with setFilters', () => {
    const { result } = renderHook(() => useFilters())

    act(() => {
      result.current.setFilters({ search: 'incident' })
    })

    expect(result.current.filters.search).toBe('incident')
  })

  it('should merge new filters with existing filters', () => {
    const { result } = renderHook(() => useFilters())

    act(() => {
      result.current.setFilters({ search: 'test' })
    })

    act(() => {
      result.current.setFilters({ priority: 'P1' })
    })

    expect(result.current.filters).toMatchObject({
      search: 'test',
      priority: 'P1',
    })
  })

  it('should reset filters to default', () => {
    const { result } = renderHook(() => useFilters())

    act(() => {
      result.current.setFilters({
        search: 'test',
        priority: 'P1',
        status: 'open',
      })
    })

    expect(result.current.filters).toMatchObject({
      search: 'test',
      priority: 'P1',
      status: 'open',
    })

    act(() => {
      result.current.resetFilters()
    })

    expect(result.current.filters).toEqual({
      search: null,
      priority: null,
      status: null,
      assignedGroup: null,
      assignedTo: null,
      reportedBy: null,
    })
  })

  it('should return hasActiveFilters as false when no filters are set', () => {
    const { result } = renderHook(() => useFilters())

    expect(result.current.hasActiveFilters).toBe(false)
  })

  it('should return hasActiveFilters as true when search filter is set', () => {
    const { result } = renderHook(() => useFilters())

    act(() => {
      result.current.setFilters({ search: 'test' })
    })

    expect(result.current.hasActiveFilters).toBe(true)
  })

  it('should return hasActiveFilters as true when priority filter is set', () => {
    const { result } = renderHook(() => useFilters())

    act(() => {
      result.current.setFilters({ priority: 'P1' })
    })

    expect(result.current.hasActiveFilters).toBe(true)
  })

  it('should return hasActiveFilters as true when status filter is set', () => {
    const { result } = renderHook(() => useFilters())

    act(() => {
      result.current.setFilters({ status: 'open' })
    })

    expect(result.current.hasActiveFilters).toBe(true)
  })

  it('should return hasActiveFilters as true when reportedBy filter is set', () => {
    const { result } = renderHook(() => useFilters())

    act(() => {
      result.current.setFilters({ reportedBy: 'user-123' })
    })

    expect(result.current.hasActiveFilters).toBe(true)
  })

  it('should return hasActiveFilters as true when assignedGroup filter is set', () => {
    const { result } = renderHook(() => useFilters())

    act(() => {
      result.current.setFilters({ assignedGroup: 'IT Support' })
    })

    expect(result.current.hasActiveFilters).toBe(true)
  })

  it('should return hasActiveFilters as true when assignedTo filter is set', () => {
    const { result } = renderHook(() => useFilters())

    act(() => {
      result.current.setFilters({ assignedTo: 'John Doe' })
    })

    expect(result.current.hasActiveFilters).toBe(true)
  })

  it('should return hasActiveFilters as false when filter is cleared', () => {
    const { result } = renderHook(() => useFilters())

    act(() => {
      result.current.setFilters({ search: 'test' })
    })

    expect(result.current.hasActiveFilters).toBe(true)

    act(() => {
      result.current.setFilters({ search: null })
    })

    expect(result.current.hasActiveFilters).toBe(false)
  })

  it('should handle multiple filter updates', () => {
    const { result } = renderHook(() => useFilters())

    act(() => {
      result.current.setFilters({
        search: 'critical',
        priority: 'P1',
        status: 'open',
      })
    })

    expect(result.current.filters).toMatchObject({
      search: 'critical',
      priority: 'P1',
      status: 'open',
    })
    expect(result.current.hasActiveFilters).toBe(true)
  })

  it('should not count empty string as active filter', () => {
    const { result } = renderHook(() => useFilters())

    act(() => {
      result.current.setFilters({ search: '' } as any)
    })

    expect(result.current.hasActiveFilters).toBe(false)
  })

  it('should handle setting filters to null explicitly', () => {
    const { result } = renderHook(() => useFilters({ search: 'test' }))

    expect(result.current.hasActiveFilters).toBe(true)

    act(() => {
      result.current.setFilters({ search: null })
    })

    expect(result.current.filters.search).toBe(null)
    expect(result.current.hasActiveFilters).toBe(false)
  })
})
