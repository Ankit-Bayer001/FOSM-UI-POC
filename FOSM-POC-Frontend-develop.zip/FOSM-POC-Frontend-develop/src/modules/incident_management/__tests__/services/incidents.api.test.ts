/**
 * Incidents API Tests
 */

import { describe, it, expect, beforeEach } from 'vitest'
import { incidentsApi } from '../../services/incidents.api'
import { mockAllIncidentsData } from '@/mockData'

describe('Incidents API', () => {
  let testIncidentId: string

  beforeEach(() => {
    // Get a valid incident ID from mock data
    if (mockAllIncidentsData.length > 0) {
      testIncidentId = mockAllIncidentsData[0].id
    }
  })

  describe('getAll', () => {
    it('should fetch incidents with default parameters', async () => {
      const response = await incidentsApi.getAll()

      expect(response).toHaveProperty('data')
      expect(response).toHaveProperty('page')
      expect(response).toHaveProperty('pageSize')
      expect(response).toHaveProperty('total')
      expect(Array.isArray(response.data)).toBe(true)
    })

    it('should fetch incidents with custom page and pageSize', async () => {
      const response = await incidentsApi.getAll(2, 10)

      expect(response.page).toBe(2)
      expect(response.pageSize).toBe(10)
    })

    it('should fetch incidents with status filter', async () => {
      const response = await incidentsApi.getAll(1, 20, { status: 'open' })

      expect(response).toHaveProperty('data')
      expect(Array.isArray(response.data)).toBe(true)
    })

    it('should fetch incidents with priority filter', async () => {
      const response = await incidentsApi.getAll(1, 20, { priority: 'P1' })

      expect(response).toHaveProperty('data')
      expect(Array.isArray(response.data)).toBe(true)
    })

    it('should fetch incidents with search filter', async () => {
      const response = await incidentsApi.getAll(1, 20, { search: 'test' })

      expect(response).toHaveProperty('data')
      expect(Array.isArray(response.data)).toBe(true)
    })

    it('should fetch incidents with multiple filters', async () => {
      const response = await incidentsApi.getAll(1, 20, {
        status: 'open',
        priority: 'P1',
        search: 'server',
      })

      expect(response).toHaveProperty('data')
      expect(Array.isArray(response.data)).toBe(true)
    })

    it('should return paginated response', async () => {
      const response = await incidentsApi.getAll(1, 10)

      expect(response).toHaveProperty('data')
      expect(response).toHaveProperty('page', 1)
      expect(response).toHaveProperty('pageSize', 10)
      expect(response).toHaveProperty('total')
      expect(typeof response.total).toBe('number')
    })
  })

  describe('getById', () => {
    it('should fetch a single incident by ID', async () => {
      const incident = await incidentsApi.getById(testIncidentId)

      expect(incident).toHaveProperty('id')
      expect(incident).toHaveProperty('incidentNumber')
      expect(incident).toHaveProperty('title')
      expect(incident).toHaveProperty('status')
    })

    it('should throw error for non-existent incident', async () => {
      try {
        await incidentsApi.getById('non-existent-uuid-12345')
        expect.fail('Should have thrown an error')
      } catch (error) {
        expect(error).toBeDefined()
      }
    })
  })

  describe('create', () => {
    it('should create a new incident', async () => {
      const newIncident = {
        title: 'New Incident',
        description: 'Test incident',
        status: 'open',
        priority: 'P2',
      }

      const created = await incidentsApi.create(newIncident)

      expect(created).toHaveProperty('id')
      expect(created).toHaveProperty('incidentNumber')
      expect(created.title).toBe('New Incident')
    })

    it('should assign an incidentNumber on create', async () => {
      const newIncident = {
        title: 'Test',
        status: 'open',
      }

      const created = await incidentsApi.create(newIncident)

      expect(created.incidentNumber).toBeDefined()
      expect(created.incidentNumber).toMatch(/^INC-/)
    })

    it('should set createdDate on create', async () => {
      const newIncident = {
        title: 'Test',
        status: 'open',
      }

      const created = await incidentsApi.create(newIncident)

      expect(created.createdDate).toBeDefined()
    })
  })

  describe('update', () => {
    it('should update an incident', async () => {
      const updates = {
        title: 'Updated Title',
      }

      const updated = await incidentsApi.update(testIncidentId, updates)

      expect(updated).toHaveProperty('id', testIncidentId)
      expect(updated.title).toBe('Updated Title')
    })

    it('should preserve unchanged fields', async () => {
      const updates = {
        title: 'Another Update',
      }

      const updated = await incidentsApi.update(testIncidentId, updates)

      expect(updated.title).toBe('Another Update')
      expect(updated).toHaveProperty('priority')
      expect(updated).toHaveProperty('status')
    })

    it('should throw error for non-existent incident', async () => {
      try {
        await incidentsApi.update('non-existent-uuid-12345', { title: 'Test' })
        expect.fail('Should have thrown an error')
      } catch (error) {
        expect(error).toBeDefined()
      }
    })
  })
})
