/**
 * Incidents API Module
 */

import { Incident, PaginatedResponse } from '@/types';
import { fetchWithAuth } from '@/lib/api';

export const incidentsApi = {
  async getAll(
    page = 1,
    pageSize = 20,
    filters?: { 
      status?: string
      priority?: string
      search?: string
      reportedBy?: string
      assignedGroup?: string
      assignedTo?: string
      userId?: string
    },
    sortBy = 'createdDate',
    sortOrder = 'desc'
  ): Promise<PaginatedResponse<Incident>> {
    const paramsObj: Record<string, string> = {
      page: page.toString(),
      pageSize: pageSize.toString(),
      sortBy,
      sortOrder,
    };

    // Add filter parameters only if they have values
    if (filters?.status) paramsObj.status = filters.status;
    if (filters?.priority) paramsObj.priority = filters.priority;
    if (filters?.search) paramsObj.search = filters.search;
    if (filters?.reportedBy) paramsObj.reportedBy = filters.reportedBy;
    if (filters?.assignedGroup) paramsObj.assignedGroup = filters.assignedGroup;
    if (filters?.assignedTo) paramsObj.assignedTo = filters.assignedTo;
    if (filters?.userId) paramsObj.userId = filters.userId;

    const params = new URLSearchParams(paramsObj);
    return fetchWithAuth(`/incidents?${params}`);
  },

  async getById(id: string): Promise<Incident> {
    return fetchWithAuth(`/incidents/${id}`);
  },

  async create(incident: Partial<Incident>): Promise<Incident> {
    return fetchWithAuth('/incidents', {
      method: 'POST',
      body: JSON.stringify(incident),
    });
  },

  async update(id: string, incident: Partial<Incident>): Promise<Incident> {
    return fetchWithAuth(`/incidents/${id}`, {
      method: 'PUT',
      body: JSON.stringify(incident),
    });
  },

  async resolve(id: string, resolutionNotes: string): Promise<Incident> {
    return fetchWithAuth(`/incidents/${id}/resolve`, {
      method: 'POST',
      body: JSON.stringify({ resolutionNotes }),
    });
  },

  async reassign(id: string, assignedTo: string): Promise<Incident> {
    return fetchWithAuth(`/incidents/${id}/reassign`, {
      method: 'POST',
      body: JSON.stringify({ assignedTo }),
    });
  },

  async addComment(id: string, content: string): Promise<void> {
    return fetchWithAuth(`/incidents/${id}/comments`, {
      method: 'POST',
      body: JSON.stringify({ content }),
    });
  },
};
