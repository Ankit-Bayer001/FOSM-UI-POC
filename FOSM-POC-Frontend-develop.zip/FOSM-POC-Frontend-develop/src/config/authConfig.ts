import { Configuration, PopupRequest } from "@azure/msal-browser";

export const msalConfig: Configuration = {
  auth: {
    // clientId: import.meta.env.VITE_ENTRA_CLIENT_ID,
    // authority: `https://login.microsoftonline.com/${import.meta.env.VITE_ENTRA_TENANT_ID}`,
    // redirectUri: import.meta.env.VITE_REDIRECT_URI || "http://localhost:3000",
    clientId: '14db9c99-ad75-458c-8071-acd4b0e49dbd',
    authority: `https://login.microsoftonline.com/fcb2b37b-5da0-466b-9b83-0014b67a7c78`,
    redirectUri: import.meta.env.VITE_REDIRECT_URI || "https://green-sky-071775c03.6.azurestaticapps.net/",
  },
  cache: {
    cacheLocation: "sessionStorage",
    storeAuthStateInCookie: false,
  },
};

export const loginRequest: PopupRequest = {
  scopes: ["User.Read", "email", "profile", "openid"]
};

export const graphConfig = {
  graphMeEndpoint: "https://graph.microsoft.com/v1.0/me"
};
