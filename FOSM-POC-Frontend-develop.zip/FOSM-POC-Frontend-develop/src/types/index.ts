// User & Authentication Types
export interface User {
  id: string;
  email: string;
  displayName: string;
  firstName: string;
  lastName: string;
  avatarUrl?: string;
  department?: string;
  jobTitle?: string;
  isActive: boolean;
  createdAt: string;
  lastLoginAt?: string;
}

export interface Group {
  id: string;
  name: string;
  description: string;
  members: string[]; // User IDs
  createdAt: string;
  updatedAt: string;
}

export interface Role {
  id: string;
  name: string;
  description: string;
  permissions: Permission[];
  createdAt: string;
}

export interface Permission {
  id: string;
  resource: string;
  action: 'create' | 'read' | 'update' | 'delete' | 'approve';
}

export interface UserRole {
  userId: string;
  roleId: string;
  assignedAt: string;
  assignedBy: string;
}

export interface GroupRole {
  groupId: string;
  roleId: string;
  assignedAt: string;
  assignedBy: string;
}

// Change Management Types
export type ChangeStatus = 
  | 'draft'
  | 'pending_approval'
  | 'approved'
  | 'in_progress'
  | 'completed'
  | 'rejected'
  | 'cancelled';

export type ChangePriority = 'low' | 'medium' | 'high' | 'critical';

export type ChangeType = 'standard' | 'normal' | 'emergency';

export type ChangeCategory = 
  | 'infrastructure'
  | 'application'
  | 'database'
  | 'network'
  | 'security'
  | 'other';

export interface ChangeTicket {
  id: string;
  ticketNumber: string;
  title: string;
  description: string;
  type: ChangeType;
  category: ChangeCategory;
  priority: ChangePriority;
  status: ChangeStatus;
  requesterId: string;
  assigneeId?: string;
  approvers: ChangeApproval[];
  impactAssessment: string;
  riskLevel: 'low' | 'medium' | 'high';
  rollbackPlan: string;
  scheduledStartDate?: string;
  scheduledEndDate?: string;
  actualStartDate?: string;
  actualEndDate?: string;
  affectedSystems: string[];
  attachments: Attachment[];
  comments: Comment[];
  auditLog: AuditEntry[];
  createdAt: string;
  updatedAt: string;
}

export interface ChangeApproval {
  approverId: string;
  status: 'pending' | 'approved' | 'rejected';
  comments?: string;
  decidedAt?: string;
}

export interface Attachment {
  id: string;
  name: string;
  url: string;
  size: number;
  uploadedBy: string;
  uploadedAt: string;
}

export interface Comment {
  id: string;
  content: string;
  authorId: string;
  createdAt: string;
  updatedAt?: string;
}

export interface AuditEntry {
  id: string;
  action: string;
  field?: string;
  oldValue?: string;
  newValue?: string;
  performedBy: string;
  performedAt: string;
}

// API Response Types
export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message?: string;
  errors?: string[];
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

// Auth Context Types
export interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  userRoles: Role[];
  userPermissions: Permission[];
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  hasPermission: (resource: string, action: Permission['action']) => boolean;
  hasRole: (roleName: string) => boolean;
}
