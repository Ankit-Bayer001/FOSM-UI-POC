/**
 * Form-specific Types
 */

export type CreateIncidentFormValues = {
  number?: string;
  caller?: string;
  configurationItem?: string;
  shortDescription: string;
  description: string;
  urgency: 'Low' | 'Medium' | 'High';
  impact: 'Low' | 'Medium' | 'High';
  priority?: string;
  assignmentGroup?: string | any;
  assignedTo?: string | any;
  assignedGroups?: string; // Extracted group ID
  assignedGroupName?: string; // Extracted group name
  assignedToName?: string; // Extracted user display name
  state?: string;
  additionalDetails?: string;
  attachments?: any[];
};
