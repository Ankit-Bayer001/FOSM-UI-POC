/**
 * Authentication Types
 */

import type { User, Role, Permission } from './common';

export type AuthContextType = {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  userRoles: Role[];
  userPermissions: Permission[];
  login: (email: string, password: string) => Promise<void>;
  loginWithEntra: () => Promise<void>;
  logout: () => Promise<void>;
  hasPermission: (resource: string, action: Permission['action']) => boolean;
  hasRole: (roleName: string) => boolean;
};
