/**
 * Common Types - User, Group, Role, and Permission types
 */

export type User = {
  id: string;
  email: string;
  displayName: string;
  firstName: string;
  lastName: string;
  avatarUrl?: string;
  department?: string;
  jobTitle?: string;
  isActive: boolean;
  createdAt: string;
  lastLoginAt?: string;
};

export type Group = {
  id: string;
  name: string;
  description: string;
  members: string[]; // User IDs
  createdAt: string;
  updatedAt: string;
};

export type Role = {
  id: string;
  name: string;
  description: string;
  permissions: Permission[];
  createdAt: string;
};

export type Permission = {
  id: string;
  resource: string;
  action: 'create' | 'read' | 'update' | 'delete' | 'approve';
};

export type UserRole = {
  userId: string;
  roleId: string;
  assignedAt: string;
  assignedBy: string;
};

export type GroupRole = {
  groupId: string;
  roleId: string;
  assignedAt: string;
  assignedBy: string;
};
