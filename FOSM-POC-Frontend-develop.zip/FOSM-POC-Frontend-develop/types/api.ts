/**
 * API Response and Data Transfer Types
 */

export type ApiResponse<T> = {
  data: T;
  success: boolean;
  message?: string;
  errors?: string[];
};

export type PaginatedResponse<T> = {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
};

export type ApiError = {
  code: string;
  message: string;
  details?: Record<string, unknown>;
};
