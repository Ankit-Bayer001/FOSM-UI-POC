/**
 * Incident Management Types
 */

export type IncidentFilters = {
  search: string | null;
  priority: string | null;
  status: number | null;
  assignedGroup: string | null;
  assignedTo?: string | null;
  reportedBy?: string | null;
};

export type Incident = {
  id: string;
  incidentNumber: string;
  title: string;
  description: string;
  priority: string;
  status: number;
  category: number;
  reportedBy: string;
  reportedByName: string;
  assignedTo: string | null;
  assignedToName: string | null;
  assignedGroup: string;
  assignedGroupName?: string;
  configurationItemName?: string;
  impact: string;
  urgency: string;
  createdDate: string;
  resolvedDate: string | null;
  closedDate: string | null;
  resolution: string | null;
};

export type BaseIncident = Incident & {
  createdAt?: string;
};

export type MyIncident = {
  id: string;
  incidentNo: string;
  state: string;
  issueDescription: string;
  priority: string;
  urgency: string;
  assignedGroup: string;
  caller: string;
  configurationItem?: string;
  assignedTo?: string;
};
