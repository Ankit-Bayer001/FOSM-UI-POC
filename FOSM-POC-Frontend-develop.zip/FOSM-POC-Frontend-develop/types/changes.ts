/**
 * Change Management Types
 */

export type ChangeStatus = 
  | 'draft'
  | 'pending_approval'
  | 'approved'
  | 'in_progress'
  | 'completed'
  | 'rejected'
  | 'cancelled';

export type ChangePriority = 'low' | 'medium' | 'high' | 'critical';

export type ChangeType = 'standard' | 'normal' | 'emergency';

export type ChangeCategory = 
  | 'infrastructure'
  | 'application'
  | 'database'
  | 'network'
  | 'security'
  | 'other';

export type Attachment = {
  id: string;
  name: string;
  url: string;
  size: number;
  uploadedBy: string;
  uploadedAt: string;
};

export type Comment = {
  id: string;
  content: string;
  authorId: string;
  createdAt: string;
  updatedAt?: string;
};

export type AuditEntry = {
  id: string;
  action: string;
  field?: string;
  oldValue?: string;
  newValue?: string;
  performedBy: string;
  performedAt: string;
};

export type ChangeApproval = {
  approverId: string;
  status: 'pending' | 'approved' | 'rejected';
  comments?: string;
  decidedAt?: string;
};

export type ChangeTicket = {
  id: string;
  ticketNumber: string;
  title: string;
  description: string;
  type: ChangeType;
  category: ChangeCategory;
  priority: ChangePriority;
  status: ChangeStatus;
  requesterId: string;
  assigneeId?: string;
  approvers: ChangeApproval[];
  impactAssessment: string;
  riskLevel: 'low' | 'medium' | 'high';
  rollbackPlan: string;
  scheduledStartDate?: string;
  scheduledEndDate?: string;
  actualStartDate?: string;
  actualEndDate?: string;
  affectedSystems: string[];
  attachments: Attachment[];
  comments: Comment[];
  auditLog: AuditEntry[];
  createdAt: string;
  updatedAt: string;
};
