import { useState } from 'react';
import { CMDBLayout } from '@/components/widgets/cmdb/CMDBLayout';
import { DriftAlertCard } from '@/components/widgets/cmdb/DriftAlertCard';
import { driftAlerts } from '@/data/mockCmdbData';
import { AlertTriangle, CheckCircle, Eye, XCircle, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DriftAlert } from '@/types/cmdb';

export default function DriftDetectionPage() {
  const [alerts, setAlerts] = useState<DriftAlert[]>(driftAlerts);

  const openAlerts = alerts.filter(a => a.status === 'open');
  const acknowledgedAlerts = alerts.filter(a => a.status === 'acknowledged');
  const resolvedAlerts = alerts.filter(a => a.status === 'resolved' || a.status === 'false_positive');

  const handleAcknowledge = (id: string) => {
    setAlerts(prev =>
      prev.map(a => (a.id === id ? { ...a, status: 'acknowledged' as const } : a))
    );
  };

  const handleResolve = (id: string) => {
    setAlerts(prev =>
      prev.map(a => (a.id === id ? { ...a, status: 'resolved' as const, resolvedAt: new Date() } : a))
    );
  };

  const handleDismiss = (id: string) => {
    setAlerts(prev =>
      prev.map(a => (a.id === id ? { ...a, status: 'false_positive' as const, resolvedAt: new Date() } : a))
    );
  };

  return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <AlertTriangle className="h-6 w-6" />
              CI Drift Detection
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              Identify and resolve conflicting CI attribute values across sources
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="card-elevated p-4 border-l-4 border-l-status-critical">
            <p className="text-2xl font-bold">{openAlerts.length}</p>
            <p className="text-sm text-muted-foreground">Open Alerts</p>
          </div>
          <div className="card-elevated p-4 border-l-4 border-l-status-warning">
            <p className="text-2xl font-bold">{acknowledgedAlerts.length}</p>
            <p className="text-sm text-muted-foreground">Acknowledged</p>
          </div>
          <div className="card-elevated p-4 border-l-4 border-l-status-healthy">
            <p className="text-2xl font-bold">{resolvedAlerts.length}</p>
            <p className="text-sm text-muted-foreground">Resolved</p>
          </div>
        </div>

        {/* Info Banner (CI-06) */}
        <div className="card-elevated p-4 bg-muted/30 border-l-4 border-l-accent">
          <h3 className="font-medium text-sm">How Drift Detection Works</h3>
          <p className="text-sm text-muted-foreground mt-1">
            When the same CI is reported by multiple sources with different attribute values,
            a drift alert is generated. Review each alert to determine the correct value and
            update the authoritative source accordingly.
          </p>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="open" className="space-y-4">
          <TabsList>
            <TabsTrigger value="open" className="gap-2">
              <AlertTriangle className="h-4 w-4" />
              Open ({openAlerts.length})
            </TabsTrigger>
            <TabsTrigger value="acknowledged" className="gap-2">
              <Eye className="h-4 w-4" />
              Acknowledged ({acknowledgedAlerts.length})
            </TabsTrigger>
            <TabsTrigger value="resolved" className="gap-2">
              <CheckCircle className="h-4 w-4" />
              Resolved ({resolvedAlerts.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="open" className="space-y-4">
            {openAlerts.length > 0 ? (
              openAlerts.map((alert) => (
                <DriftAlertCard
                  key={alert.id}
                  alert={alert}
                  onAcknowledge={() => handleAcknowledge(alert.id)}
                  onResolve={() => handleResolve(alert.id)}
                  onDismiss={() => handleDismiss(alert.id)}
                />
              ))
            ) : (
              <div className="card-elevated p-8 text-center">
                <CheckCircle className="h-12 w-12 text-status-healthy mx-auto mb-3" />
                <p className="font-medium">No open drift alerts</p>
                <p className="text-sm text-muted-foreground mt-1">
                  All CI attributes are in sync across sources
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="acknowledged" className="space-y-4">
            {acknowledgedAlerts.length > 0 ? (
              acknowledgedAlerts.map((alert) => (
                <DriftAlertCard
                  key={alert.id}
                  alert={alert}
                  onResolve={() => handleResolve(alert.id)}
                  onDismiss={() => handleDismiss(alert.id)}
                />
              ))
            ) : (
              <div className="card-elevated p-8 text-center text-muted-foreground">
                No acknowledged alerts
              </div>
            )}
          </TabsContent>

          <TabsContent value="resolved" className="space-y-4">
            {resolvedAlerts.length > 0 ? (
              resolvedAlerts.map((alert) => (
                <DriftAlertCard key={alert.id} alert={alert} />
              ))
            ) : (
              <div className="card-elevated p-8 text-center text-muted-foreground">
                No resolved alerts
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
  );
}
