import { useState, useMemo } from 'react';
import { ConfigurationItem, CISearchFilters, CIClass, CIStatus } from '@/types/cmdb';

export function useCISearch(items: ConfigurationItem[]) {
  const [filters, setFilters] = useState<CISearchFilters>({});

  const filteredItems = useMemo(() => {
    return items.filter(item => {
      // Text search
      if (filters.query) {
        const query = filters.query.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesDescription = item.description?.toLowerCase().includes(query) || false;
        const matchesOwner = item.owner?.toLowerCase().includes(query) || false;
        const matchesTeam = item.team?.toLowerCase().includes(query) || false;
        if (!matchesName && !matchesDescription && !matchesOwner && !matchesTeam) {
          return false;
        }
      }

      // Class filter
      if (filters.classes && filters.classes.length > 0) {
        if (!filters.classes.includes(item.class)) {
          return false;
        }
      }

      // Status filter
      if (filters.statuses && filters.statuses.length > 0) {
        if (!filters.statuses.includes(item.status)) {
          return false;
        }
      }

      // Environment filter
      if (filters.environments && filters.environments.length > 0) {
        if (!filters.environments.includes(item.environment)) {
          return false;
        }
      }

      // Source filter
      if (filters.sources && filters.sources.length > 0) {
        if (!filters.sources.includes(item.source)) {
          return false;
        }
      }

      return true;
    });
  }, [items, filters]);

  const updateFilter = <K extends keyof CISearchFilters>(
    key: K,
    value: CISearchFilters[K]
  ) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({});
  };

  const toggleClassFilter = (ciClass: CIClass) => {
    const current = filters.classes || [];
    const newClasses = current.includes(ciClass)
      ? current.filter(c => c !== ciClass)
      : [...current, ciClass];
    updateFilter('classes', newClasses.length > 0 ? newClasses : undefined);
  };

  const toggleStatusFilter = (status: CIStatus) => {
    const current = filters.statuses || [];
    const newStatuses = current.includes(status)
      ? current.filter(s => s !== status)
      : [...current, status];
    updateFilter('statuses', newStatuses.length > 0 ? newStatuses : undefined);
  };

  return {
    filters,
    filteredItems,
    updateFilter,
    clearFilters,
    toggleClassFilter,
    toggleStatusFilter,
    hasActiveFilters: Object.values(filters).some(v => v !== undefined && (Array.isArray(v) ? v.length > 0 : true)),
  };
}
