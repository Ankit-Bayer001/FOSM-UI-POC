import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Search } from "lucide-react"

interface FiltersWidgetProps {
  searchTerm: string
  onSearchChange: (value: string) => void

  priorityFilter: string
  onPriorityChange: (value: string) => void

  stateFilter: string
  onStateChange: (value: string) => void

  caller?: string
  onCallerChange?: (value: string) => void

  assignedGroup?: string
  onAssignedGroupChange?: (value: string) => void
}

export const FiltersWidget = ({
  searchTerm,
  onSearchChange,
  priorityFilter,
  onPriorityChange,
  stateFilter,
  onStateChange,
  caller,
  onCallerChange,
  assignedGroup,
  onAssignedGroupChange,
}: FiltersWidgetProps) => {
  return (
    <div className="flex flex-wrap gap-4 items-end">

      {/* Search */}
      <div className="flex flex-col gap-1 flex-1 min-w-[160px]">
        <Label htmlFor="search">Search</Label>
        <div className="relative">
          <Input
            id="search"
            placeholder="Search"
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pr-10"
          />
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
        </div>
      </div>

      {/* Caller */}
      <div className="flex flex-col gap-1 w-[260px]">
        <Label htmlFor="caller">Caller</Label>
        <Input
          id="caller"
          value={caller}
          onChange={(e) => onCallerChange?.(e.target.value)}
          placeholder="Caller"
        />
      </div>

      {/* Priority */}
      <div className="flex flex-col gap-1 w-[180px]">
        <Label htmlFor="priority">Priority</Label>
        <Select value={priorityFilter} onValueChange={onPriorityChange}>
          <SelectTrigger id="priority">
            <SelectValue placeholder="Please Select" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Priorities</SelectItem>
            <SelectItem value="low">Low</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* State */}
      <div className="flex flex-col gap-1 w-[180px]">
        <Label htmlFor="state">State</Label>
        <Select value={stateFilter} onValueChange={onStateChange}>
          <SelectTrigger id="state">
            <SelectValue placeholder="Please Select" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All States</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Assigned Group */}
      <div className="flex flex-col gap-1 w-[260px]">
        <Label htmlFor="assignedGroup">Assigned Group</Label>
        <Input
          id="assignedGroup"
          value={assignedGroup}
          onChange={(e) => onAssignedGroupChange?.(e.target.value)}
          placeholder="Assigned Group"
        />
      </div>
    </div>
  )
}
