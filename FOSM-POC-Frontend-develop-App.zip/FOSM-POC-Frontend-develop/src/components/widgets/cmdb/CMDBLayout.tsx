import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Database,
  LayoutDashboard,
  Server,
  GitBranch,
  Plug,
  GitMerge,
  AlertTriangle,
  Search,
  FileText,
  Shield,
  Settings,
  Menu,
  X,
  ChevronLeft,
  ChevronDown,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface NavItem {
  label: string;
  icon: typeof Database;
  path?: string;
  badge?: number;
  children?: NavItem[];
}

const navItems: NavItem[] = [
  {
    label: 'CMDB',
    icon: LayoutDashboard,
    children: [
      { label: 'Dashboard', icon: LayoutDashboard, path: '/' },
      { label: 'Configuration Items', icon: Server, path: '/cis' },
      { label: 'Relationships', icon: GitBranch, path: '/relationships' },
      { label: 'Integrations', icon: Plug, path: '/integrations' },
      { label: 'Reconciliation', icon: GitMerge, path: '/reconciliation', badge: 2 },
      { label: 'Drift Detection', icon: AlertTriangle, path: '/drift', badge: 3 },
      { label: 'Search', icon: Search, path: '/search' },
      { label: 'Audit Log', icon: FileText, path: '/audit' },
      { label: 'CI Classes', icon: Settings, path: '/classes' },
      { label: 'Governance', icon: Shield, path: '/governance' },
    ],
  },
];

interface CMDBLayoutProps {
  children: React.ReactNode;
}

export function CMDBLayout({ children }: CMDBLayoutProps) {
  const location = useLocation();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [expandedItems, setExpandedItems] = useState<string[]>(['CMDB Dashboard']);

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Header */}
      <header className="lg:hidden fixed top-0 left-0 right-0 h-14 bg-sidebar border-b border-sidebar-border z-50 flex items-center px-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setMobileMenuOpen(true)}
          className="text-sidebar-foreground"
        >
          <Menu className="h-5 w-5" />
        </Button>
        <div className="flex items-center gap-2 ml-3">
          <Database className="h-5 w-5 text-sidebar-primary" />
          <span className="font-semibold text-sidebar-foreground">CMDB</span>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-50"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 left-0 h-screen bg-sidebar border-r border-sidebar-border z-50 transition-all duration-300',
          sidebarCollapsed ? 'w-16' : 'w-64',
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Logo */}
        <div className="h-14 flex items-center justify-between px-4 border-b border-sidebar-border">
          <div className={cn('flex items-center gap-2', sidebarCollapsed && 'lg:justify-center')}>
            <Database className="h-6 w-6 text-sidebar-primary shrink-0" />
            {!sidebarCollapsed && (
              <span className="font-semibold text-sidebar-foreground">CMDB</span>
            )}
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => {
              setMobileMenuOpen(false);
              setSidebarCollapsed(!sidebarCollapsed);
            }}
            className="text-sidebar-foreground hidden lg:flex"
          >
            <ChevronLeft
              className={cn(
                'h-4 w-4 transition-transform',
                sidebarCollapsed && 'rotate-180'
              )}
            />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setMobileMenuOpen(false)}
            className="text-sidebar-foreground lg:hidden"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="p-2 space-y-1">
          {navItems.map((item) => {
            const isExpanded = expandedItems.includes(item.label);
            const hasChildren = item.children && item.children.length > 0;

            return (
              <div key={item.label}>
                {/* Parent Item */}
                <div
                  onClick={() => {
                    if (hasChildren) {
                      setExpandedItems((prev) =>
                        prev.includes(item.label)
                          ? prev.filter((l) => l !== item.label)
                          : [...prev, item.label]
                      );
                    } else if (item.path) {
                      setMobileMenuOpen(false);
                    }
                  }}
                  className={cn(
                    'sidebar-nav-item cursor-pointer',
                    item.path && isActive(item.path) && 'active',
                    sidebarCollapsed && 'lg:justify-center lg:px-2'
                  )}
                >
                  <item.icon className="h-4 w-4 shrink-0" />
                  {!sidebarCollapsed && (
                    <>
                      <span className="flex-1">{item.label}</span>
                      {item.badge && (
                        <span className="px-1.5 py-0.5 text-xs bg-sidebar-primary text-sidebar-primary-foreground rounded-full">
                          {item.badge}
                        </span>
                      )}
                      {hasChildren && (
                        <ChevronDown
                          className={cn(
                            'h-4 w-4 transition-transform',
                            isExpanded && 'rotate-180'
                          )}
                        />
                      )}
                    </>
                  )}
                </div>

                {/* Child Items */}
                {hasChildren && isExpanded && !sidebarCollapsed && (
                  <div className="space-y-1 mt-1 ml-2 border-l border-sidebar-border">
                    {item.children.map((child) => (
                      <Link
                        key={child.path}
                        to={child.path!}
                        onClick={() => setMobileMenuOpen(false)}
                        className={cn(
                          'sidebar-nav-item pl-4',
                          isActive(child.path!) && 'active'
                        )}
                      >
                        <child.icon className="h-4 w-4 shrink-0" />
                        <span className="flex-1 text-sm">{child.label}</span>
                        {child.badge && (
                          <span className="px-1.5 py-0.5 text-xs bg-sidebar-primary text-sidebar-primary-foreground rounded-full">
                            {child.badge}
                          </span>
                        )}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Auto-Discovery Disabled Notice (CI-09) */}
        {!sidebarCollapsed && (
          <div className="absolute bottom-4 left-2 right-2">
            <div className="p-3 rounded-lg bg-sidebar-accent text-xs">
              <div className="flex items-center gap-2 text-sidebar-foreground/70">
                <Shield className="h-4 w-4" />
                <span>Auto-Discovery Disabled</span>
              </div>
              <p className="text-sidebar-foreground/50 mt-1 text-[10px]">
                CIs managed via approved integrations only
              </p>
            </div>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <main
        className={cn(
          'min-h-screen pt-14 lg:pt-0 transition-all duration-300',
          sidebarCollapsed ? 'lg:pl-16' : 'lg:pl-64'
        )}
      >
        <div className="p-4 lg:p-6 max-w-7xl mx-auto">{children}</div>
      </main>
    </div>
  );
}
