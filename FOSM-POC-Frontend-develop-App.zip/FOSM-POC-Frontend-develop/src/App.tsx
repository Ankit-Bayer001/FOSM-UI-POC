import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { AppLayout } from "@/components/layout/AppLayout";

// Pages
import { LoginPage } from "@/pages/LoginPage";
import { DashboardPage } from "@/pages/DashboardPage";
import { ChangeListPage } from "@/pages/changes/ChangeListPage";
import { CreateChangePage } from "@/pages/changes/CreateChangePage";
import { ChangeDetailPage } from "@/pages/changes/ChangeDetailPage";
import {AllIncidentsPage} from "@/pages/incidents/AllIncidentsPage";
import { UsersPage } from "@/pages/admin/UsersPage";
import { GroupsPage } from "@/pages/admin/GroupsPage";
import { RolesPage } from "@/pages/admin/RolesPage";
import { UnauthorizedPage } from "@/pages/UnauthorizedPage";
import NotFound from "./pages/NotFound";
import CMDBDashboard from "./pages/cmdb/CMDBDashboard";
import CIListPage from "./pages/cmdb/CIListPage";
import CIClassesPage from "./pages/cmdb/CIClassesPage";
import IntegrationsPage from "./pages/cmdb/IntegrationsPage";
import ReconciliationPage from "./pages/cmdb/ReconciliationPage";
import DriftDetectionPage from "./pages/cmdb/DriftDetectionPage";
import AuditLogPage from "./pages/cmdb/AuditLogPage";
import SearchPage from "./pages/cmdb/SearchPage";
import RelationshipsPage from "./pages/cmdb/RelationshipsPage";
import GovernancePage from "./pages/cmdb/GovernancePage";

const queryClient = new QueryClient();

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              {/* Public Routes */}
              <Route path="/login" element={<LoginPage />} />
              <Route path="/unauthorized" element={<UnauthorizedPage />} />

              {/* Protected Routes */}
              <Route path="/" element={<Navigate to="/dashboard" replace />} />

              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    <AppLayout>
                      <DashboardPage />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />

              {/* Change Management Routes */}
              <Route
                path="/changes"
                element={
                  <ProtectedRoute
                    requiredPermission={{
                      resource: "change_tickets",
                      action: "read",
                    }}
                  >
                    <AppLayout>
                      <ChangeListPage />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
               <Route
                path="/incidents"
                element={
                  <ProtectedRoute
                    requiredPermission={{
                      resource: "change_tickets",
                      action: "read",
                    }}
                  >
                    <AppLayout>
                      <AllIncidentsPage />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/changes/new"
                element={
                  <ProtectedRoute
                    requiredPermission={{
                      resource: "change_tickets",
                      action: "create",
                    }}
                  >
                    <AppLayout>
                      <CreateChangePage />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/changes/my"
                element={
                  <ProtectedRoute
                    requiredPermission={{
                      resource: "change_tickets",
                      action: "read",
                    }}
                  >
                    <AppLayout>
                      <ChangeListPage />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/changes/pending"
                element={
                  <ProtectedRoute
                    requiredPermission={{
                      resource: "change_tickets",
                      action: "read",
                    }}
                  >
                    <AppLayout>
                      <ChangeListPage />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/changes/:id"
                element={
                  <ProtectedRoute
                    requiredPermission={{
                      resource: "change_tickets",
                      action: "read",
                    }}
                  >
                    <AppLayout>
                      <ChangeDetailPage />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/changes/:id/edit"
                element={
                  <ProtectedRoute
                    requiredPermission={{
                      resource: "change_tickets",
                      action: "update",
                    }}
                  >
                    <AppLayout>
                      <CreateChangePage />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />

              <Route path="/cmdb">
                <Route
                  index
                  element={
                    <ProtectedRoute
                      requiredPermission={{
                        resource: "change_tickets",
                        action: "update",
                      }}
                    >
                      <AppLayout>
                        <CMDBDashboard />
                      </AppLayout>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="cis"
                  element={
                    <ProtectedRoute
                      requiredPermission={{
                        resource: "change_tickets",
                        action: "update",
                      }}
                    >
                      <AppLayout>
                        <CIListPage />
                      </AppLayout>
                    </ProtectedRoute>
                  }
                />

                <Route
                  path="relationships"
                  element={
                    <ProtectedRoute
                      requiredPermission={{
                        resource: "change_tickets",
                        action: "update",
                      }}
                    >
                      <AppLayout>
                        <RelationshipsPage />
                      </AppLayout>
                    </ProtectedRoute>
                  }
                />

                <Route
                  path="integrations"
                  element={
                    <ProtectedRoute
                      requiredPermission={{
                        resource: "change_tickets",
                        action: "update",
                      }}
                    >
                      <AppLayout>
                        <IntegrationsPage />
                      </AppLayout>
                    </ProtectedRoute>
                  }
                />

                <Route
                  path="reconciliation"
                  element={
                    <ProtectedRoute
                      requiredPermission={{
                        resource: "change_tickets",
                        action: "update",
                      }}
                    >
                      <AppLayout>
                        <ReconciliationPage />
                      </AppLayout>
                    </ProtectedRoute>
                  }
                />

                <Route
                  path="drift"
                  element={
                    <ProtectedRoute
                      requiredPermission={{
                        resource: "change_tickets",
                        action: "update",
                      }}
                    >
                      <AppLayout>
                        <DriftDetectionPage />
                      </AppLayout>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="search"
                  element={
                    <ProtectedRoute
                      requiredPermission={{
                        resource: "change_tickets",
                        action: "update",
                      }}
                    >
                      <AppLayout>
                        <SearchPage />
                      </AppLayout>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="audit"
                  element={
                    <ProtectedRoute
                      requiredPermission={{
                        resource: "change_tickets",
                        action: "update",
                      }}
                    >
                      <AppLayout>
                        <AuditLogPage />
                      </AppLayout>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="classes"
                  element={
                    <ProtectedRoute
                      requiredPermission={{
                        resource: "change_tickets",
                        action: "update",
                      }}
                    >
                      <AppLayout>
                        <CIClassesPage />
                      </AppLayout>
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="governance"
                  element={
                    <ProtectedRoute
                      requiredPermission={{
                        resource: "change_tickets",
                        action: "update",
                      }}
                    >
                      <AppLayout>
                        <GovernancePage />
                      </AppLayout>
                    </ProtectedRoute>
                  }
                />
                {/*<Route path="classes" element={<CIClassesPage />} />
                <Route path="integrations" element={<IntegrationsPage />} />
                <Route path="reconciliation" element={<ReconciliationPage />} />
                <Route path="drift" element={<DriftDetectionPage />} />
                <Route path="audit" element={<AuditLogPage />} />
                <Route path="search" element={<SearchPage />} />
                <Route path="relationships" element={<RelationshipsPage />} />
                <Route path="governance" element={<GovernancePage />} /> */}
              </Route>

              <Route path="*" element={<NotFound />} />
              {/* Admin Routes */}
              <Route
                path="/admin/users"
                element={
                  <ProtectedRoute
                    requiredPermission={{ resource: "users", action: "read" }}
                  >
                    <AppLayout>
                      <UsersPage />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/groups"
                element={
                  <ProtectedRoute
                    requiredPermission={{ resource: "groups", action: "read" }}
                  >
                    <AppLayout>
                      <GroupsPage />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/roles"
                element={
                  <ProtectedRoute
                    requiredPermission={{ resource: "roles", action: "read" }}
                  >
                    <AppLayout>
                      <RolesPage />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />

              {/* Catch-all */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
