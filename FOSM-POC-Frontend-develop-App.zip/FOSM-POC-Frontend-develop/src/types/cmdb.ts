// CMDB Type Definitions

export type CIClass = 
  | 'server'
  | 'application'
  | 'database'
  | 'network'
  | 'storage'
  | 'service';

export type CIStatus = 
  | 'active'
  | 'inactive'
  | 'maintenance'
  | 'decommissioned'
  | 'planned';

export type RelationshipType = 
  | 'depends_on'
  | 'hosts'
  | 'connected_to'
  | 'part_of'
  | 'runs_on'
  | 'uses';

export type DriftSeverity = 
  | 'low'
  | 'medium'
  | 'high'
  | 'critical';

export type IntegrationStatus = 
  | 'connected'
  | 'disconnected'
  | 'syncing'
  | 'error';

export type AuditAction = 
  | 'create'
  | 'update'
  | 'delete'
  | 'relationship_added'
  | 'relationship_removed'
  | 'reconciliation';

// CI Class Definition (CI-01)
export interface CIClassDefinition {
  id: string;
  name: string;
  class: CIClass;
  description: string;
  icon: string;
  attributes: CIAttributeDefinition[];
  createdAt: Date;
  updatedAt: Date;
}

export interface CIAttributeDefinition {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'date' | 'enum';
  required: boolean;
  enumValues?: string[];
  description?: string;
}

// Configuration Item (CI-03)
export interface ConfigurationItem {
  id: string;
  name: string;
  class: CIClass;
  status: CIStatus;
  description?: string;
  attributes: Record<string, unknown>;
  source: string;
  sourceId?: string;
  environment: 'production' | 'staging' | 'development' | 'test';
  owner?: string;
  team?: string;
  location?: string;
  createdAt: Date;
  updatedAt: Date;
  lastSyncedAt?: Date;
}

// CI Relationships (CI-02)
export interface CIRelationship {
  id: string;
  sourceId: string;
  targetId: string;
  type: RelationshipType;
  description?: string;
  createdAt: Date;
  createdBy: string;
}

// Integration Sources (CI-04)
export interface IntegrationSource {
  id: string;
  name: string;
  type: 'azure' | 'aws' | 'servicenow' | 'custom';
  status: IntegrationStatus;
  endpoint?: string;
  lastSyncAt?: Date;
  nextSyncAt?: Date;
  ciCount: number;
  errorMessage?: string;
  config: Record<string, unknown>;
}

// De-duplication Rule (CI-05)
export interface ReconciliationRule {
  id: string;
  name: string;
  description: string;
  matchFields: string[];
  priority: number;
  autoMerge: boolean;
  enabled: boolean;
}

export interface DuplicateCandidate {
  id: string;
  ciA: ConfigurationItem;
  ciB: ConfigurationItem;
  matchScore: number;
  matchedFields: string[];
  status: 'pending' | 'merged' | 'dismissed';
  suggestedAction?: string;
}

// Drift Detection (CI-06)
export interface DriftAlert {
  id: string;
  ciId: string;
  ciName: string;
  attribute: string;
  expectedValue: unknown;
  actualValue: unknown;
  source: string;
  severity: DriftSeverity;
  detectedAt: Date;
  resolvedAt?: Date;
  status: 'open' | 'acknowledged' | 'resolved' | 'false_positive';
}

// Audit Log (CI-08)
export interface AuditLogEntry {
  id: string;
  timestamp: Date;
  action: AuditAction;
  ciId: string;
  ciName: string;
  userId: string;
  userName: string;
  changes?: {
    field: string;
    oldValue: unknown;
    newValue: unknown;
  }[];
  source: 'manual' | 'integration' | 'reconciliation';
  ipAddress?: string;
}

// Dashboard metrics
export interface CMDBMetrics {
  totalCIs: number;
  activeIntegrations: number;
  pendingReconciliations: number;
  openDriftAlerts: number;
  cisByClass: Record<CIClass, number>;
  cisByStatus: Record<CIStatus, number>;
  recentChanges: number;
  syncHealth: 'healthy' | 'degraded' | 'critical';
}

// Search and filtering
export interface CISearchFilters {
  query?: string;
  classes?: CIClass[];
  statuses?: CIStatus[];
  environments?: string[];
  sources?: string[];
  dateRange?: {
    start: Date;
    end: Date;
  };
}
