import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { User, Role, Permission, AuthContextType } from '@/types';
import { mockUsers, mockRoles, mockUserRoles } from '@/data/mockData';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userRoles, setUserRoles] = useState<Role[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Derive permissions from roles
  const userPermissions = userRoles.flatMap(role => role.permissions);

  // Check for existing session on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('itsm_user');
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
        loadUserRoles(parsedUser.id);
      } catch (e) {
        localStorage.removeItem('itsm_user');
      }
    }
    setIsLoading(false);
  }, []);

  const loadUserRoles = (userId: string) => {
    // In production, this would call your .NET API
    const userRoleAssignments = mockUserRoles.filter(ur => ur.userId === userId);
    const roles = mockRoles.filter(r => 
      userRoleAssignments.some(ur => ur.roleId === r.id)
    );
    setUserRoles(roles);
  };

  const login = useCallback(async (email: string, password: string) => {
    setIsLoading(true);
    
    // Simulate API call - replace with actual Entra/API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const foundUser = mockUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    
    if (!foundUser) {
      setIsLoading(false);
      throw new Error('Invalid credentials');
    }

    setUser(foundUser);
    loadUserRoles(foundUser.id);
    localStorage.setItem('itsm_user', JSON.stringify(foundUser));
    setIsLoading(false);
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setUserRoles([]);
    localStorage.removeItem('itsm_user');
    // In production, also clear Entra session
  }, []);

  const hasPermission = useCallback((resource: string, action: Permission['action']): boolean => {
    return userPermissions.some(
      p => p.resource === resource && p.action === action
    );
  }, [userPermissions]);

  const hasRole = useCallback((roleName: string): boolean => {
    return userRoles.some(r => r.name.toLowerCase() === roleName.toLowerCase());
  }, [userRoles]);

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    userRoles,
    userPermissions,
    login,
    logout,
    hasPermission,
    hasRole,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
